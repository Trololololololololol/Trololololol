using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class Geode : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 21;
            item.maxStack = 99;
            item.value = Terraria.Item.sellPrice(0, 1, 25, 0);
            item.rare = 7;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Gemstone Cluster");
      Tooltip.SetDefault("");
    }

    }
}
