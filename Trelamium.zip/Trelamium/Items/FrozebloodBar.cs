using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using System.Collections.Generic;

namespace Trelamium.Items
{
    public class FrozebloodBar : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 24;
            item.value = Terraria.Item.sellPrice(0, 4, 0, 0);
            item.maxStack = 999;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Frostblood Bar");
      Tooltip.SetDefault("");
    }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine line2 in list)
            {
                if (line2.mod == "Terraria" && line2.Name == "ItemName")
                {
                    line2.overrideColor = new Color(155, 0, 78);
                }
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("SoulOfCright"), 3);
            recipe.AddIngredient(ItemID.Ichor, 15);
            recipe.AddIngredient(ItemID.LunarBar, 8);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this, 15);
            recipe.AddRecipe();
        }
    }
}
		
