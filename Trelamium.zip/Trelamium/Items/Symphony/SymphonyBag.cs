using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Symphony
{
    public class SymphonyBag : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Treasure Bag");
            Tooltip.SetDefault("Right Click to open");
        }
        public override void SetDefaults()
        {
            item.maxStack = 999;
            item.consumable = true;
            item.width = 32;
            item.height = 32;
            item.rare = -12;
            bossBagNPC = mod.NPCType("RinTheMage");
            item.expert = true;
        }
        public override bool CanRightClick()
        {
            return true;
        }

        public override void OpenBossBag(Player player)
        {
            int choice = Main.rand.Next(7);
            if (choice == 0)
            {
                player.QuickSpawnItem(mod.ItemType("TidalBreaker"));      
            }
            if (choice == 1)
            {
                player.QuickSpawnItem(mod.ItemType("Riptide"));
            }
            if (choice == 2)
            {
                player.QuickSpawnItem(mod.ItemType("BladeOfPoseidon"));
            }
            if (choice == 3)
            {
                player.QuickSpawnItem(mod.ItemType("AquamarineYoyo"));
            }
            if (choice == 4)
            {
                player.QuickSpawnItem(mod.ItemType("TridentOfIllusion"));
            }
            if (choice == 5)
            {
                player.QuickSpawnItem(mod.ItemType("TheKrakensTentacles"));
            }
            if (choice == 6)
            {
                player.QuickSpawnItem(mod.ItemType("SeaNymphStaff"));
            }
            player.QuickSpawnItem(mod.ItemType("RingOfAzure"));
        }
    }
}
