using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Symphony
{
    public class PearlOfEnhancement : ModItem
	{
        public override void SetDefaults()
        {

            item.width = 52;
            item.height = 50;
            item.maxStack = 20;

            item.rare = 2;
            item.useAnimation = 45;
            item.useTime = 45;
            item.useStyle = 4;
            item.UseSound = SoundID.Item44;
            item.consumable = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Pearl of Enhancement");
      Tooltip.SetDefault("Starts the Symphony!");
    }

		public override bool CanUseItem(Player player)
		{
            return player.ZoneBeach && !NPC.AnyNPCs(mod.NPCType("AquariaSiren")) && !NPC.AnyNPCs(mod.NPCType("NeptoriaSiren")) && !NPC.AnyNPCs(mod.NPCType("RinTheMage"));
		}

        public override bool UseItem(Player player)
        {
            Main.NewText("The Symphony has started!!", Color.SkyBlue.R, Color.SkyBlue.G, Color.SkyBlue.B);
            NPC.SpawnOnPlayer(player.whoAmI, mod.NPCType("KrakenMini"));
            NPC.SpawnOnPlayer(player.whoAmI, mod.NPCType("RinTheMage"));
            NPC.SpawnOnPlayer(player.whoAmI, mod.NPCType("Nept"));
            Main.PlaySound(SoundID.Roar, player.position, 0);
            return true;
        }
		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Coral, 3);
            recipe.AddIngredient(null, ("SoundPrism"), 12);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
