using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Symphony
{
    public class StarfishShuriken : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 37;
            item.thrown = true;
            item.noMelee = false;
            item.width = 32;
            item.height = 32;
            item.useTime = 18;
            item.crit = 8;
            item.useAnimation = 18;
            item.useStyle = 1;      
            item.knockBack = 3;
            item.value = Terraria.Item.buyPrice(0, 0, 12, 0);
            item.rare = 3;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("StarfishShurikenProjectile");
            item.shootSpeed = 20f;
            item.useTurn = true;
            item.maxStack = 999;
            item.consumable = true;
            item.noUseGraphic = true;
                       
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Starfish Shuriken");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null,("AzureElement"), 1);
            recipe.AddIngredient(ItemID.Starfish);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this, 33);
            recipe.AddRecipe();
        }
    }
}
