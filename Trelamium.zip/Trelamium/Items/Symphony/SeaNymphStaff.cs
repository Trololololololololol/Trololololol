using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Symphony
{
    public class SeaNymphStaff : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 20;
            item.summon = true;
            item.mana = 12;
            item.width = 50;
            item.height = 50;

            item.useTime = 26;
            item.useAnimation = 26;
            item.crit = 22;
            item.useStyle = 1;
            item.noMelee = true;
            item.knockBack = 5;
            item.value = Terraria.Item.buyPrice(0, 12, 0, 0);
            item.rare = 3;
            item.UseSound = SoundID.Item81;
            item.shoot = mod.ProjectileType("SeaNymphMinion");
            item.shootSpeed = 7f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Sea Nymph Staff");
      Tooltip.SetDefault("Summons a Sea Nymph to fight for you.");
    }

    }
}
