using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Symphony
{
    public class TridentOfIllusion : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 30;

            item.melee = true;
            item.width = 64;
            item.height = 64;
            item.scale = 1.5f;
            item.maxStack = 1;
            item.useTime = 13;
            item.useAnimation = 13;
            item.knockBack = 4f;
            item.UseSound = SoundID.Item1;
            item.noMelee = true;
            item.noUseGraphic = true;
            item.useTurn = true;
            item.useStyle = 5;
            item.value = Item.sellPrice(0, 5, 0, 0);
            item.rare = 3;
            item.shoot = mod.ProjectileType("TridentOfIllusionProjectile");
            item.shootSpeed = 7f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Trident Of Illusion");
      Tooltip.SetDefault("Creates a Bubble on thrust");
    }

   }
}
