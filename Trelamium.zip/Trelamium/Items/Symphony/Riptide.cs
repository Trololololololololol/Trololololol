using Terraria;
using System;
using Terraria.ID;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Terraria.ModLoader;

namespace Trelamium.Items.Symphony
{
    public class Riptide : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 30;
            item.noMelee = true;
            item.ranged = true;
            item.width = 30;
            item.height = 56;
            item.useTime = 25;
            item.useAnimation = 25;
            item.useStyle = 5;

            item.shoot = 3;
            item.useAmmo = AmmoID.Arrow;
            item.knockBack = 7;
            item.value = Terraria.Item.sellPrice(0, 12, 50, 0);
            item.rare = 3;
            item.UseSound = SoundID.Item84;
            item.autoReuse = false;
            item.shootSpeed = 18f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Riptide");
      Tooltip.SetDefault("Occasionally fires a typhoon bubble that will create a Tyhpoon\nShoots 3 arrows at a time");
    }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            for (int i = 0; i < 3; i++) // Will shoot 3 arrows
            {
                float SpeedX = speedX + (float)Main.rand.Next(-60, 61) * 0.05f;
                float SpeedY = speedY + (float)Main.rand.Next(-60, 61) * 0.05f;
                switch (Main.rand.Next(7))
                {
                    case 1: type = mod.ProjectileType("TyphoonBubble"); break;
                    default: break;
                }
                Projectile.NewProjectile(position.X, position.Y, SpeedX, SpeedY, type, (int)((double)damage), knockBack, player.whoAmI, 0.0f, 0.0f);
            }
            return false;
        }
    }
}
