using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Symphony
{
    public class TidalBreaker : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 32;                   
            item.melee = true;
            item.width = 30;
            item.height = 30;

            item.useTime = 20;
            item.useAnimation = 20;
            item.useStyle = 3;
            item.noMelee = false;
            item.knockBack = 5f;    
            item.value = Terraria.Item.buyPrice(0, 10, 0, 0);
            item.rare = 3;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("SeaweedHead");
            item.shootSpeed = 11f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Tidal Breaker");
      Tooltip.SetDefault("Releases a wave of seaweed");
    }

    }
}

