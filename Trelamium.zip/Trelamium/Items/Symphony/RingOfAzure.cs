using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Symphony
{
    public class RingOfAzure : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 58;
            item.height = 52;

            item.value = Terraria.Item.buyPrice(0, 8, 0, 0);
            item.rare = 3;
            item.accessory = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ring Of Azure");
      Tooltip.SetDefault("When you are in a liquid damage is increased by 20%");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            {
                if (player.wet == true || player.honeyWet == true || player.lavaWet == true)
                {
                    player.rangedDamage = 0.2f;
                    player.minionDamage = 0.2f;
                    player.magicDamage = 0.2f;
                    player.meleeDamage = 0.2f;
                    player.thrownDamage = 0.2f;
                }
            }
        }
    }
}
