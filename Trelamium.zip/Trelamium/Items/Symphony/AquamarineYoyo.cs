using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Symphony
{
    public class AquamarineYoyo : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 38;
            item.melee = true;
            item.useTime = 22;
            item.useAnimation = 22;
            item.useStyle = 5;
            item.channel = true;
            item.knockBack = 2f;
            item.value = Terraria.Item.buyPrice(0, 4, 25, 0);
            item.rare = 3;
            item.autoReuse = false;
            item.shoot = mod.ProjectileType("AquamarineProjectile");
            item.noUseGraphic = true;
            item.noMelee = true;
            item.UseSound = SoundID.Item1;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aquamarine");
      Tooltip.SetDefault("");
    }

    }
}
