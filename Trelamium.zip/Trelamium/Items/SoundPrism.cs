﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class SoundPrism : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 14;
            item.height = 28;
            item.maxStack = 99;
            item.value = Terraria.Item.sellPrice(0, 0, 10, 0);
            item.rare = 3;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Sound Prism");
      Tooltip.SetDefault("");
    }

    }
}
