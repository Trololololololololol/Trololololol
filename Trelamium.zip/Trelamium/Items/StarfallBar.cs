using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class StarfallBar : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 24;
            item.maxStack = 99;

            item.value = Terraria.Item.sellPrice(0, 0, 45, 0);
            item.rare = 1;
            item.consumable = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Starfall Bar");
      Tooltip.SetDefault("Crafted from the Rage of the fallen Angels.");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.IronBar, 1);
            recipe.AddIngredient(ItemID.FallenStar, 3);
            recipe.AddTile(TileID.SkyMill);
            recipe.SetResult(this, 2);
            recipe.AddRecipe();
        }
    }
}
