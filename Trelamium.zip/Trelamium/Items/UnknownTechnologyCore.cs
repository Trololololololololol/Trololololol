using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class UnknownTechologyCore : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 28;
            item.height = 26;
            item.value = Terraria.Item.buyPrice(0, 12, 0, 0);
            item.rare = 11;
            item.maxStack = 99;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Unknown Technology Core");
      Tooltip.SetDefault("");
    }

    }
}
