using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class PieceOfFlesh : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 24;
            item.maxStack = 99;
            item.value = Terraria.Item.sellPrice(0, 0, 8, 0);
            item.rare = 2;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Piece of Flesh");
      Tooltip.SetDefault("");
    }

    }
}
