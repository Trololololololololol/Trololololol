using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using Terraria.DataStructures;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class TurquoiseEnergy : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 96;
            item.height = 36;
            item.maxStack = 999;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Turquoise Energy");
      Tooltip.SetDefault("");
      Main.RegisterItemAnimation(item.type, new DrawAnimationVertical(7, 4));
      ItemID.Sets.AnimatesAsSoul[item.type] = true;
      ItemID.Sets.ItemIconPulse[item.type] = true;
      ItemID.Sets.ItemNoGravity[item.type] = true;
    }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine line2 in list)
            {
                if (line2.mod == "Terraria" && line2.Name == "ItemName")
                {
                    line2.overrideColor = new Color(155, 0, 78);
                }
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "HeavyBlueMetal", 10);
            recipe.AddIngredient(ItemID.FragmentVortex, 4);
            recipe.AddIngredient(ItemID.FragmentStardust, 4);
            recipe.AddIngredient(ItemID.FragmentNebula, 4);
            recipe.AddIngredient(ItemID.FragmentSolar, 4);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this, 8);
            recipe.AddRecipe();
        }
    }
}
		
