﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AquamarineHammer : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 7;
            item.melee = true;
            item.width = 34;
            item.height = 34;
            item.useTime = 28;
            item.useAnimation = 51;
            item.hammer = 50;
            item.useStyle = 1;
            item.knockBack = 5;
            item.value = Terraria.Item.sellPrice(0, 0, 25, 0);
            item.rare = 3;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aquamarine Hammer");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Aquamarine"), 7);
            recipe.AddTile(null, ("AquaAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
