﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BlueMagnum : ModItem
    {

        public override void SetDefaults()
        {

            item.damage = 18;
            item.ranged = true;
            item.width = 40;
            item.height = 24;
            item.useTime = 22;
            item.useAnimation = 22;
            item.useStyle = 5;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 2.75f;
            item.value = 100000;
            item.rare = 5;
            item.UseSound = SoundID.Item41;
            item.autoReuse = true;
            item.shootSpeed = 14f;
            item.useAmmo = AmmoID.Bullet;
            item.shoot = 10;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Blue Magnum");
            Tooltip.SetDefault("");
        }
    }
}
