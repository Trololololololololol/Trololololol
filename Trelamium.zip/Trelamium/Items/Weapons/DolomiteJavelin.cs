using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class DolomiteJavelin : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 28;           //this is the item damage
            item.thrown = true;             //this make the item do throwing damage
            item.noMelee = true;
            item.width = 40;
            item.height = 40;
            item.useTime = 20;       //this is how fast you use the item
            item.useAnimation = 20;   //this is how fast the animation when the item is used
            item.useStyle = 1;      
            item.knockBack = 3;
            item.value = Terraria.Item.sellPrice(0, 0, 3, 25);
            item.rare = 2;
            item.UseSound = SoundID.Item1; //item.UseSound = SoundID.Item1;   //The sound played when using your Weapon
            item.autoReuse = true;       //this make the item auto reuse
            item.shoot = mod.ProjectileType("DolomiteJavelinP");
            item.shootSpeed = 9f;
            item.consumable = true;
            item.useTurn = true;
            item.maxStack = 999;
            item.noUseGraphic = true;          
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dolomite Javelin");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Dolomite"), 1);
            recipe.AddIngredient(ItemID.Javelin, 35);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this, 35);
            recipe.AddRecipe();
        }
    }
}
