﻿using Terraria;
using System;
using Terraria.ID;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BoneCrossbow : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 16;
            item.ranged = true;
            item.width = 52;
            item.height = 32;
            item.useTime = 17;
            item.useAnimation = 16;
            item.useStyle = 5;

            item.noMelee = true;
            item.knockBack = 4;
            item.value = Terraria.Item.buyPrice(0, 2, 25, 0);
            item.rare = 3;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shoot = 10;
            item.shoot = ProjectileID.BoneArrow;
            item.shootSpeed = 10f;
            item.useAmmo = AmmoID.Arrow;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Bone Crossbow");
      Tooltip.SetDefault("'Shoots Bone Arrows'");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Lens", 2);
            recipe.AddIngredient(null, "Teeth", 6);
            recipe.AddIngredient(null, "RippedRug", 17);
            recipe.AddTile(null, ("CryingBloodAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
