﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
namespace Trelamium.Items.Weapons
{
    public class CosmicSpear : ModItem
    {
        public override void SetDefaults()
        {

		item.width = 44;  //The width of the .png file in pixels divided by 2.
		item.damage = 160;  //Keep this reasonable please.
		item.melee = true;  //Dictates whether this is a melee-class weapon.
		item.noMelee = true;

		item.useTurn = true;
		item.noUseGraphic = true;
		item.useAnimation = 45;
		item.useStyle = 4;
		item.useTime = 45;
		item.knockBack = 5.5f;  //Ranges from 1 to 9.
		item.UseSound = SoundID.Item1;
		item.autoReuse = false;  //Dictates whether the weapon can be "auto-fired".
		item.height = 44;  //The height of the .png file in pixels divided by 2.
		item.maxStack = 1;
		item.value = 385000;  //Value is calculated in copper coins.
		item.rare = 7;  //Ranges from 1 to 11.
		item.shoot = mod.ProjectileType("CosmicSpearP");
		item.shootSpeed = 5f;
	}

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Supernova Lance");
      Tooltip.SetDefault("The power of the cosmos rests within.");
    }


	public override void AddRecipes()
	{
		ModRecipe recipe = new ModRecipe(mod);
		recipe.AddIngredient(ItemID.FragmentSolar, 15);
		recipe.AddIngredient(ItemID.Obsidian, 10);  
		recipe.AddIngredient(ItemID.Hellstone, 15);
		recipe.AddIngredient(null, "CosmicEssence", 10);
        recipe.AddTile(TileID.LunarCraftingStation);
        recipe.SetResult(this);
        recipe.AddRecipe();
	}
}}
