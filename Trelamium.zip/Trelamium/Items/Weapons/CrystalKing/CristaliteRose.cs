﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.CrystalKing
{
    public class CristaliteRose : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 111;
            item.magic = true;                   //this make the item do magic damage
            item.width = 46;
            item.height = 46;
            item.useTime = 39;
            item.useAnimation = 39;
            item.useStyle = 5;
            Item.staff[item.type] = true;  //this is how the item is holded      Item.staff[item.type] = true; //this makes the useStyle animate as a staff instead of as a gun
            item.noMelee = true;
            item.knockBack = 2;
            item.value = Terraria.Item.buyPrice(0, 63, 30, 0);
            item.rare = 9;
            item.mana = 26;             //mana use
            item.UseSound = SoundID.Item9;            //this is the sound when you use the item
            item.autoReuse = false;
            item.shoot = mod.ProjectileType("Crystal4");   //this make the item shoot your projectile
            item.shootSpeed = 23f;    //projectile speed when shoot
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Cristalite Rose");
      Tooltip.SetDefault("");
    }

        //  -----------------------------------------------Even Arc style: Multiple Projectile, Even Spread ---------------------------------------------------------
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 4; // This defines how many projectiles to shot
            float rotation = MathHelper.ToRadians(5);
            position += Vector2.Normalize(new Vector2(speedX, speedY)) * 1f; //this defines the distance of the projectiles form the player when the projectile spawns
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .6f; // This defines the projectile roatation and speed. .4f == projectile speed
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Crystal", 24);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
