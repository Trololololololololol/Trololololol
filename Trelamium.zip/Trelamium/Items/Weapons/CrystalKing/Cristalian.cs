﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.CrystalKing
{
    public class Cristalian : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 435;
            item.ranged = true;
            item.width = 34;
            item.height = 70;
            item.useTime = 18;

            item.useAnimation = 18;
            item.useStyle = 5;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 1.5f;
            item.value = 11005000;
            item.rare = 10;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shootSpeed = 53f;
            item.shoot = mod.ProjectileType("CristalianP");
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Cristalian");
      Tooltip.SetDefault("All fired arrows are transfromed into Nebula arrows!");
    }

    }
}
