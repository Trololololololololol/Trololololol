﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.CrystalKing
{
    public class CristaliteQuartzBlade : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 460;
            item.melee = true;
            item.width = 42;
            item.height = 42;
            item.useTime = 18;
            item.useAnimation = 18;
            item.useStyle = 1;
            item.knockBack = 5;
            item.value = Terraria.Item.buyPrice(0, 57, 23, 0);
            item.rare = 6;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
            item.shootSpeed = 30f;//Weather your Weapon will be used again after use while holding down, if false you will need to click again after use to use it again.
            item.shoot = ProjectileID.CrystalStorm;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Cristalite Blade");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Crystal"), 18);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
