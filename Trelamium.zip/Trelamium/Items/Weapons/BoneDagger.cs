﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BoneDagger : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 16;
            item.melee = true;
            item.width = 32;

            item.height = 32;
            item.useTime = 14;
            item.useAnimation = 14;
            item.useStyle = 3;
            item.knockBack = 3;
            item.value = Terraria.Item.sellPrice(0, 2, 23, 0);
            item.rare = 2;
            item.UseSound = SoundID.Item1;
            item.autoReuse = false;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Bone dagger");
      Tooltip.SetDefault("'A fast dagger'");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Lens", 3);
            recipe.AddIngredient(null, "Teeth", 3);
            recipe.AddIngredient(null, "RippedRug", 12);
            recipe.AddTile(null, ("CryingBloodAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
