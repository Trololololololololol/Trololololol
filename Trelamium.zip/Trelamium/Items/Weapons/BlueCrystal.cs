using Terraria;
using System;
using Terraria.ID;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BlueCrystal : ModItem
    {

        public override void SetDefaults()
        {

            item.damage = 52;
            item.noMelee = true;
            item.ranged = true;
            item.width = 22;
            item.height = 46;

            item.useTime = 23;
            item.useAnimation = 23;
            item.useStyle = 5;
            item.shoot = 3;
            item.useAmmo = AmmoID.Arrow;
            item.knockBack = 1;
            item.value = Terraria.Item.buyPrice(0, 22, 0, 0);
            item.rare = 4;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shootSpeed = 19f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Blue Crystal");
      Tooltip.SetDefault("'Transforms arrows into blue waves'");
    }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            Projectile.NewProjectile(position.X, position.Y, speedX, speedY, mod.ProjectileType("BlueWave"), damage, knockBack, player.whoAmI, 0f, 0f); //This is spawning a projectile of type FrostburnArrow using the original stats
            return false; //Makes sure to not fire the original projectile
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "HeavyBlueMetal", 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
