﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AncientSwordV2 : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 34;
            item.melee = true;
            item.width = 56;

            item.height = 56;
            item.useTime = 39;
            item.useAnimation =39;
            item.useStyle = 1;
            item.knockBack = 5;
            item.value = Terraria.Item.sellPrice(0, 5, 23, 0);
            item.rare = 5;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ancient Greatsword");
      Tooltip.SetDefault("Ancient Sickles appear on enemy hits!");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddRecipeGroup("Boss2Stuff", 24);
            recipe.AddIngredient(null, ("FadedSteel"), 14);
            recipe.AddIngredient(null, ("AncientBlade"));
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            if (Main.rand.Next(3) == 0)
            {

                int p = Projectile.NewProjectile(Main.MouseWorld.X + 50, Main.MouseWorld.Y, -.001f, 0, mod.ProjectileType("AncientSickle2"), item.damage, item.knockBack, item.owner);
            }
            else

            {
                if (Main.rand.Next(3) == 0)
                {
                    int q = Projectile.NewProjectile(Main.MouseWorld.X - 50, Main.MouseWorld.Y, .001f, 0, mod.ProjectileType("AncientSickle2"), item.damage, item.knockBack, item.owner);
                }
            }
        }
    }
}
