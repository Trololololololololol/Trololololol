﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items;

namespace Trelamium.Items.Weapons
{
    public class AquamarinePickaxe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 10;
            item.melee = true;
            item.width = 34;
            item.height = 34;
            item.useTime = 10;
            item.useAnimation = 21;
            item.useTurn = true;
            item.pick = 55;
            item.useStyle = 1;
            item.knockBack = 1;
            item.value = 25000;
            item.rare = 2;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aquamarine Pickaxe");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Aquamarine"), 9);
            recipe.AddTile(null, ("AquaAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
