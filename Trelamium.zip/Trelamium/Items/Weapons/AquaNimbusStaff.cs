﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AquaNimbusStaff : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 14;
            item.summon = true;
            item.mana = 10;
            item.width = 34;
            item.height = 34;
            item.useTime = 25;
            item.useAnimation = 25;
            item.useStyle = 1;

            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 0f;
            item.value = 40000;
            item.rare = 2;
            item.UseSound = SoundID.Item66;
            item.shoot = mod.ProjectileType("AquamarineNimbus");
            item.shootSpeed = 16f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aquatic Rain Staff");
      Tooltip.SetDefault("Fires a crying nimbus.\nHe cries from happiness");
    }


        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            int i = Main.myPlayer;
            float num72 = item.shootSpeed;
            int num73 = damage;
            float num74 = knockBack;
            num74 = player.GetWeaponKnockback(item, num74);
            player.itemTime = item.useTime;
            Vector2 vector2 = player.RotatedRelativePoint(player.MountedCenter, true);
            Vector2 value = Vector2.UnitX.RotatedBy((double)player.fullRotation, default(Vector2));
            Vector2 vector3 = Main.MouseWorld - vector2;
            float num78 = (float)Main.mouseX + Main.screenPosition.X - vector2.X;
            float num79 = (float)Main.mouseY + Main.screenPosition.Y - vector2.Y;
            if (player.gravDir == -1f)
            {
                num79 = Main.screenPosition.Y + (float)Main.screenHeight - (float)Main.mouseY - vector2.Y;
            }
            float num80 = (float)Math.Sqrt((double)(num78 * num78 + num79 * num79));
            float num81 = num80;
            if ((float.IsNaN(num78) && float.IsNaN(num79)) || (num78 == 0f && num79 == 0f))
            {
                num78 = (float)player.direction;
                num79 = 0f;
                num80 = num72;
            }
            else
            {
                num80 = num72 / num80;
            }
            num78 *= num80;
            num79 *= num80;
            int num154 = Projectile.NewProjectile(vector2.X, vector2.Y, num78, num79, mod.ProjectileType("AquamarineNimbusCloud"), num73, num74, i, 0f, 0f);
            Main.projectile[num154].ai[0] = (float)Main.mouseX + Main.screenPosition.X;
            Main.projectile[num154].ai[1] = (float)Main.mouseY + Main.screenPosition.Y;
            return false;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Aquamarine"), 11);
            recipe.AddTile(null, ("AquaAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
