﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items;

namespace Trelamium.Items.Weapons.DarkWING
{
    public class Deathbringer : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 50;
            item.ranged = true;
            item.width = 14;
            item.height = 30;
            item.useTime = 26;
            item.useAnimation = 26;
            item.useStyle = 5;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 3.5f;
            item.value = 15000;
            item.rare = 10;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shoot = 14;
            item.shootSpeed = 38f;
            item.useAmmo = 40;
        }
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            type = mod.ProjectileType("Deathbringer");  //to shoot a modded Projectile Replace that with this: type = mod.ProjectileType("ModdedProjectile")
            return base.Shoot(player, ref position, ref speedX, ref speedY, ref type, ref damage, ref knockBack);
        }
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Deathbringer");
            Tooltip.SetDefault("Upon shooting an enemy, Dark flames consume them");
        }
    }
}
