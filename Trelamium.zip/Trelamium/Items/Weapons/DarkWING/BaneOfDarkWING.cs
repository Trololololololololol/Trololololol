using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.DarkWING
{
    public class BaneOfDarkWING : ModItem
    {
        public override void SetDefaults()
        {
            item.damage = 80;
            item.melee = true;
            item.rare = 10;
            item.width = 64;
            item.height = 64;
            item.value = Item.sellPrice(0, 50, 0, 0);
            item.useTime = 10;   //How fast the Weapon is used.
            item.useAnimation = 10;     //How long the Weapon is used for.
            item.channel = true;
            item.useStyle = 100;    //The way your Weapon will be used, 1 is the regular sword swing for example
            item.knockBack = 8f;    //The knockback stat of your Weapon.� � � � � � � � � 
            item.shoot = mod.ProjectileType("BaneOfDarkWINGP");  //This defines what type of projectile this weapon will shoot � 
            item.shootSpeed = 13f;
            item.noUseGraphic = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Bane Of DarkWING");
            Tooltip.SetDefault("Rapidly fires dark flames");
        }
    }
}
