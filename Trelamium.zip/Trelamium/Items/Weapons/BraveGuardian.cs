using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BraveGuardian : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 42;
            item.melee = true;
            item.width = 64;
            item.height = 64;
            item.useTime = 23;
            item.useAnimation = 23;
            item.useStyle = 1;
            item.knockBack = 5;
            item.value = Terraria.Item.sellPrice(0, 12, 0, 0);
            item.rare = 5;
            item.shoot = ProjectileID.Meteor2;
            item.shootSpeed = 40f;
            item.UseSound = SoundID.Item84;
            item.autoReuse = false;
            item.useTurn = true;
        }   

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Brave Guardian");
      Tooltip.SetDefault("");
    }

          public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
          {
              int numberProjectiles = 4 + Main.rand.Next(1);
              for (int i = 0; i < numberProjectiles; i++)
              {
                  Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(30));
                  Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
              }
              return false;
          }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("BladeGuard"));
            recipe.AddIngredient(null,("HelleorSword"));
            recipe.AddIngredient(ItemID.SoulofLight, 12);
            recipe.AddIngredient(ItemID.SoulofNight, 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
