using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class DestructiveLightning : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 200;
            item.thrown = true;
            item.noMelee = true;
            item.width = 42;
            item.height = 42;
            item.useTime = 6;
            item.useAnimation = 6;
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = Terraria.Item.buyPrice(0, 30, 0, 0);
            item.rare = 10;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("DestructiveLightningP"); 
            item.shootSpeed = 23f;
            item.useTurn = true;
            item.maxStack = 1;
            item.consumable = false;
            item.noUseGraphic = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Destructive Lightning");
      Tooltip.SetDefault("");
    }

    }
}
