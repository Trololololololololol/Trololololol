﻿using Terraria;
using System;
using Terraria.ID;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BloodSun : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 29;
            item.magic = true;
            item.mana = 21;
            item.width = 64;
            item.height = 64;
            item.useTime = 34;
            item.useAnimation = 34;
            item.useStyle = 5;
            Item.staff[item.type] = true;


            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 3.25f;
            item.value = 20000;
            item.rare = 3;
            item.UseSound = SoundID.Item72;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("BloodRay");
            item.shootSpeed = 11f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Bloody Ray");
      Tooltip.SetDefault("A staff of pain'\nCreates a bone beam");
    }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Lens", 2);
            recipe.AddIngredient(null, "Teeth", 6);
            recipe.AddIngredient(null, "RippedRug", 17);
            recipe.AddIngredient(null, "AncientBloodStone");
            recipe.AddTile(null, ("CryingBloodAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
