using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AshuramaruKatana : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 45;

            item.melee = true;
            item.width = 58;
            item.height = 58;
            item.useTime = 16;
            item.useAnimation = 16;
            item.useStyle = 1;
            item.knockBack = 50f;
            item.value = Terraria.Item.buyPrice(0, 17, 0, 0);
            item.rare = 7;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ashuramaru's Katana");
      Tooltip.SetDefault("Protector of tegu's!");
    }

    }
}
