﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BloomJavelin : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 80;
            item.melee = true;
            item.width = 52;
            item.height = 58;
            item.noUseGraphic = true;
            item.noMelee = true;
            item.useTime = 15;
            item.useAnimation = 15;
            item.useStyle = 5;
            item.useTurn = true;
            item.knockBack = 8.5f;
            item.value = Terraria.Item.buyPrice(0, 12, 0, 0);
            item.rare = 8;
            item.UseSound = SoundID.Item1;
            item.shoot = mod.ProjectileType("PetalLanceP");
            item.scale = 1.1f;
            item.shootSpeed = 6.5f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Bloom Lance");
      Tooltip.SetDefault("");
    }

        public override void UseStyle(Player player)
        {
            if (player.altFunctionUse == 2)
            {
                item.noUseGraphic = false;
                float backX = 0f;
                float downY = 0f;
                float cosRot = (float)Math.Cos(player.itemRotation);
                float sinRot = (float)Math.Sin(player.itemRotation);
                player.itemLocation.X = player.itemLocation.X - (backX * cosRot * player.direction) - (downY * sinRot * player.gravDir);
                player.itemLocation.Y = player.itemLocation.Y - (backX * sinRot * player.direction) + (downY * cosRot * player.gravDir);
            }
            else
            {
                item.noUseGraphic = true;
            }

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("PlanteraSkin"), 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
