using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BladeOfTheWave : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 26;
            item.melee = true;
            item.width = 50;
            item.height = 50;
            item.useTime = 30;
            item.crit = 25;
            item.useAnimation = 30;
            item.useStyle = 1;
            item.noMelee = false;
            item.knockBack = 2;
            item.value = Terraria.Item.buyPrice(0, 6, 0, 0);
            item.rare = 2;
            item.shootSpeed = 55f;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Blade Of Waves");
            Tooltip.SetDefault("");
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "SeaEssence", 7);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}