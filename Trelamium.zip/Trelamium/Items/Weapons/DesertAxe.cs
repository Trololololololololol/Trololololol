﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items;
namespace Trelamium.Items.Weapons
{
    public class DesertAxe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 63;
            item.melee = true;
            item.width = 32;
            item.height = 32;
            item.useTime = 6;
            item.useAnimation = 19;
            item.useTurn = true;
            item.axe = 30;
            item.useStyle = 1;
            item.knockBack = 4;
            item.value = 15000;
            item.rare = 2;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Desert Horn Axe");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "SunSpiritBracing", 11);
            recipe.AddIngredient(null, "WarClaw", 12);
            recipe.AddTile(null, "DesertAltarTile");
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
