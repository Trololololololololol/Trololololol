using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class DesertMultiTool : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 34;
            item.melee = true;
            item.width = 64;
            item.height = 64;
            item.useTime = 11;
            item.useAnimation = 11;
            item.pick = 160;
            item.axe = 40;
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = Terraria.Item.sellPrice(0, 15, 0, 0);
            item.rare = 0;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Desert Pick-Axe");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {

            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddRecipeGroup("AdamantiteBars", 10);
            recipe.AddIngredient(ItemID.AncientBattleArmorMaterial, 3);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
