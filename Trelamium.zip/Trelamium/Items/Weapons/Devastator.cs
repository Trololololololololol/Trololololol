﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
namespace Trelamium.Items.Weapons
{
    public class Devastator : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 32;  //The width of the .png file in pixels divided by 2.
            item.damage = 114;  //Keep this reasonable please.
            item.melee = true;  //Dictates whether this is a melee-class weapon.
            item.useAnimation = 26;
            item.useStyle = 1;
            item.useTime = 26;
            item.useTurn = true;
            item.knockBack = 2;  //Ranges from 1 to 9.
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;  //Dictates whether the weapon can be "auto-fired".
            item.height = 32;  //The height of the .png file in pixels divided by 2.
            item.maxStack = 1;

            item.value = 2400000;  //Value is calculated in copper coins.
            item.rare = 10;  //Ranges from 1 to 11.
            item.shoot = mod.ProjectileType("DevastatorP");

            item.shootSpeed = 20f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Devastator");
      Tooltip.SetDefault("The blade of devils.");
    }


        public override bool Shoot(Player player, ref Microsoft.Xna.Framework.Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            int num6 = Main.rand.Next(1, 3);
            for (int index = 0; index < num6; ++index)
            {
                float num7 = speedX;
                float num8 = speedY;
                float SpeedX = speedX + (float)Main.rand.Next(-40, 41) * 0.05f;
                float SpeedY = speedY + (float)Main.rand.Next(-40, 41) * 0.05f;
                Projectile.NewProjectile(position.X, position.Y, SpeedX, SpeedY, type, (int)((double)damage * 0.5), knockBack, player.whoAmI, 0.0f, 0.0f);
            }
            return false;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.BrokenHeroSword);

            recipe.AddIngredient(null, "AncientSwordV2");
            recipe.AddIngredient(ItemID.BeetleHusk, 10);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
