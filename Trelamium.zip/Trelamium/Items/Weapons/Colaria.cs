﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class Colaria : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 25;
            item.melee = true;
            item.width = 42;
            item.height = 42;
            item.useTime = 18;
            item.useAnimation = 18;
            item.useStyle = 1;
            item.knockBack = 5;
            item.value = Terraria.Item.sellPrice(0, 2, 10, 0);
            item.rare = 8;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Colaria");
            Tooltip.SetDefault("'A rare claymore'\nInflicts several debuffs");
        }
        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            target.AddBuff(BuffID.OnFire, 500);
            target.AddBuff(BuffID.Frostburn, 500);
            target.AddBuff(BuffID.Ichor, 500);
            target.AddBuff(BuffID.Wet, 500);
            target.AddBuff(BuffID.ShadowFlame, 500);
        }
    }
}
