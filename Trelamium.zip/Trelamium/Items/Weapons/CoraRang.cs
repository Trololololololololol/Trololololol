﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class CoraRang : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 21;
            item.thrown = true;
            item.width = 56;
            item.height = 56;
            item.useTime = 28;
            item.useAnimation = 28;
            item.noUseGraphic = true;
            item.useStyle = 1;
            item.knockBack = 3;
            item.value = Terraria.Item.buyPrice(0, 0, 35, 0);
            item.rare = 3;
            item.shootSpeed = 10f;
            item.shoot = mod.ProjectileType("CoraRang");
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Cora-Rang");
            Tooltip.SetDefault("'Sharp'");
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "FusedMetal", 12);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}