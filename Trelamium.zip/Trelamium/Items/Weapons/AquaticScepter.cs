using Terraria;
using System;
using Terraria.ID;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AquaticScepter : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 43;
            item.magic = true;
            item.width = 38;
            item.height = 18;
            item.useTime = 1;
            item.useAnimation = 13;
            item.useStyle = 5;

            item.noMelee = true;
            item.knockBack = 4;
            item.value = Terraria.Item.buyPrice(0, 8, 25, 0);
            item.rare = 5;
            item.UseSound = SoundID.Item21;
            item.autoReuse = true;
            item.shoot = 10;
            item.shoot = ProjectileID.WaterStream;
            item.shootSpeed = 16f;
            item.mana = 6;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aquatic Scepter");
      Tooltip.SetDefault("'Shoots 3 deadly streams of water'");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.AquaScepter, 1);
            recipe.AddIngredient(ItemID.WaterBucket, 3);
            recipe.AddIngredient(ItemID.SoulofLight, 16);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            int numberProjectiles = 3 + Main.rand.Next(1);
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(30));
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }
        public override bool ConsumeAmmo(Player player)
        {
            return Main.rand.NextFloat() > .38f;
        }
    }
}
