using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BloomBlade : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 75;
            item.melee = true;
            item.width = 56;
            item.height = 56;
            item.useTime = 24;
            item.useAnimation = 24;
            item.useStyle = 1;
            item.crit = 28;
            item.noMelee = false;
            item.knockBack = 6.5f;
            item.value = Terraria.Item.buyPrice(0, 18, 0, 0);
            item.rare = 8;
            item.UseSound = SoundID.Item1;
            item.shoot = ProjectileID.FlowerPetal;
            item.shootSpeed = 10f;
            item.autoReuse = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Bloom Blade");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("PlanteraSkin"), 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
