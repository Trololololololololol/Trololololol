﻿using Terraria;
using System;
using Terraria.ID;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AzureCrystalLament : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 45;
            item.magic = true;
            item.mana = 17;
            item.width = 48;
            item.height = 48;
            item.useTime = 28;
            item.useAnimation = 28;
            item.useStyle = 5;
            Item.staff[item.type] = true;


            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 3.25f;
            item.value = 120000;
            item.rare = 5;
            item.UseSound = SoundID.Item72;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("AzureLamentRay");
            item.shootSpeed = 11f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Azure Crystal Lament");
      Tooltip.SetDefault("Azure powers bless you'\nCasts a bright azure ray");
    }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "AzureElement", 10);
            recipe.AddIngredient(null, "Aquamarine", 15);
            recipe.AddIngredient(null, "Agate", 15);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
