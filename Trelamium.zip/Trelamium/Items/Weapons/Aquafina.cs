using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class Aquafina : BrutalItem
    {
        public bool laser;

        public override void SetDefaults()
        {

            item.damage = 29;
            
            item.width = 50;
            item.height = 57;
            item.useTime = 23;
            item.useAnimation = 23;
            item.crit = 16;
            item.useStyle = 1;
            item.knockBack = 5;
            item.value = Terraria.Item.buyPrice(0, 0, 23, 0);
            item.rare = 1;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
            item.scale = 1.25f;
        }    

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aquafina");
      Tooltip.SetDefault("'The Ocean Judges You'\nKilling Enemies restores health");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Coral, 6);
            recipe.AddIngredient(null, ("FusedMetal"), 5);
            recipe.AddIngredient(ItemID.Seashell, 3);
            recipe.AddIngredient(null, ("FadedSteel"), 14);
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            if (Main.rand.Next(3) == 0)

            {
                player.statLife += 2;
                
            }
            if (target.life <= 0)
            {
                player.statLife += 10;
                player.HealEffect(10);
            }

        }
    }
}
