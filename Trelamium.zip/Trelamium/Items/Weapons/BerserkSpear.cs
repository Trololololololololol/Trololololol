﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BerserkSpear : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 82;

            item.melee = true;
            item.width = 48;
            item.height = 48;
            item.scale = 2f;
            item.maxStack = 1;
            item.useTime = 21;
            item.useAnimation = 21;
            item.knockBack = 4f;
            item.UseSound = SoundID.Item1;
            item.noMelee = true;
            item.noUseGraphic = true;
            item.useTurn = true;
            item.useStyle = 5;
            item.value = Item.sellPrice(0, 11, 0, 0);
            item.rare = 8;
            item.shoot = mod.ProjectileType("BerserkSpearP");
            item.shootSpeed = 11f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Prime Lance");
      Tooltip.SetDefault("Primal beams appear on hit.");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "PrimeSteel", 14);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
