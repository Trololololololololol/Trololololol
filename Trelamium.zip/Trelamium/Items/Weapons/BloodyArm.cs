﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BloodyArm : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 21;
            item.melee = true;
            item.width = 34;

            item.height = 34;
            item.useTime = 21;
            item.useAnimation = 21;
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = Terraria.Item.sellPrice(0, 4, 23, 0);
            item.rare = 3;
            item.UseSound = SoundID.Item1;
            item.autoReuse = false;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Decayed Zombie Arm");
      Tooltip.SetDefault("'No one would take this handy help'");
    }

    }
}
