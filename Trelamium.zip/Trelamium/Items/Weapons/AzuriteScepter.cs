using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AzuriteScepter : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 8;
            item.summon = true;
            item.mana = 12;
            item.width = 50;
            item.height = 50;

            item.useTime = 26;
            item.useAnimation = 26;
            item.crit = 22;
            item.useStyle = 1;
            item.noMelee = true;
            item.knockBack = 5;
            item.value = Terraria.Item.buyPrice(0, 12, 0, 0);
            item.rare = 5;
            item.UseSound = SoundID.Item81;
            item.shoot = mod.ProjectileType("AzuriteNymph");
            item.shootSpeed = 7f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Azurite Scepter");
      Tooltip.SetDefault("Summons a Azure Nymph to fight for you.");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Agate", 8);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
