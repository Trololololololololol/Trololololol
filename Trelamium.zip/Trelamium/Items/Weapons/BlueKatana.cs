﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BlueKatana : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 14;
            item.melee = true;
            item.width = 50;
            item.height = 50;
            item.useTime = 30;
            item.crit = 25;
            item.useAnimation = 30;
            item.useStyle = 1;
            item.noMelee = false;
            item.knockBack = 2;
            item.value = Terraria.Item.buyPrice(0, 3, 0, 0);
            item.rare = 2;
       
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Blue Katana");
            Tooltip.SetDefault("");
        }
    }
}