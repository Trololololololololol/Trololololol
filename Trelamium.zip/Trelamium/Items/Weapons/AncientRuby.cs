﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AncientRuby : BrutalItem
    {
        public override void SetDefaults()
        {

            item.width = 32;  //The width of the .png file in pixels divided by 2.
            item.damage = 9;  //Keep this reasonable please.

            item.useAnimation = 19;
            item.useTime = 19;  //Ranges from 1 to 55. 
            item.useTurn = true;
            item.useStyle = 3;
            item.rare = 3;
            item.scale = 1.25f;
            item.crit += 8;
            item.knockBack = 3.5f;  //Ranges from 1 to 9.
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;  //Dictates whether the weapon can be "auto-fired".
            item.height = 48;  //The height of the .png file in pixels divided by 2.
            item.maxStack = 1;

            item.value = 210000;  //Value is calculated in copper coins.
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Ancient Ruby Rapier");
            Tooltip.SetDefault("Upon hitting an enemy, a small amount of health will be restored.");
        }




        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Ruby, 5);
            recipe.AddIngredient(ItemID.WoodenSword);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }



        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            if (Main.rand.Next(3) == 0)

            {
                player.statLife += 3;
                player.HealEffect(3);
            }
        }
    }
}