﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AncientBlade : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 21;
            item.melee = true;
            item.width = 40;

            item.height = 40;
            item.useTime = 41;
            item.useAnimation = 41;
            item.useStyle = 1;
            item.knockBack = 5;
            item.value = Terraria.Item.sellPrice(0, 4, 23, 0);
            item.rare = 4;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ancient Sword");
      Tooltip.SetDefault("Ancient Sickles appear on enemy hits!");
    }

        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            if (Main.rand.Next(4) == 0)
            {

                int p = Projectile.NewProjectile(Main.MouseWorld.X + 100, Main.MouseWorld.Y, -.001f, 0, mod.ProjectileType("AncientSickle2"), item.damage, item.knockBack, item.owner);
            }
            else

            {
                if (Main.rand.Next(3) == 0)
                {
                    int q = Projectile.NewProjectile(Main.MouseWorld.X - 100, Main.MouseWorld.Y, .001f, 0, mod.ProjectileType("AncientSickle2"), item.damage, item.knockBack, item.owner);
                }
            }
        }
    }
}
