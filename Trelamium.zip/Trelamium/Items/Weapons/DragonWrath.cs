using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
	public class DragonWrath : ModItem
	{
		public override void SetDefaults()
		{

			item.damage = 53;
			item.magic = true;
			item.mana = 14;
			item.width = 64;
			item.height = 64;
			item.useTime = 14;
			item.useAnimation = 14;
			item.useStyle = 5;
            Item.staff[item.type] = true;
			item.noMelee = true;
			item.knockBack = 5;
            item.value = Terraria.Item.buyPrice(0, 6, 30, 0);
			item.rare = 2;
			item.UseSound = SoundID.Item20;
			item.autoReuse = true;
			item.shoot = 700;
			item.shootSpeed = 16f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dragon wrath");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("DB"), 20);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
