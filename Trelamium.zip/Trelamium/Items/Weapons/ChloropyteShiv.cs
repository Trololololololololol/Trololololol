using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class ChloropyteShiv : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 66;
            item.thrown = true;
            item.noMelee = false;
            item.width = 14;
            item.height = 36;
            item.useTime = 9;
            item.crit = 35;
            item.useAnimation = 9;
            item.useStyle = 1;      
            item.knockBack = 9;

            item.value = Terraria.Item.buyPrice(0, 8, 0, 0);
            item.rare = 7;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("ChloropyteShivP");
            item.shootSpeed = 28f;
            item.useTurn = true;
            item.maxStack = 1;
            item.consumable = false;
            item.noUseGraphic = true;
                       
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Chlorophyte Chunai");
      Tooltip.SetDefault("'Can bounce on tiles'");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.ChlorophyteBar, 18);
            recipe.AddIngredient(ItemID.ShadowFlameKnife);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
