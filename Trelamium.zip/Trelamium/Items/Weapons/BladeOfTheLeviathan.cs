using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BladeOfTheLeviathan : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 80;
            item.melee = true;
            item.width = 60;
            item.height = 60;
            item.useTime = 20;
            item.crit = 18;
            item.useAnimation = 20;
            item.useStyle = 1;
            item.noMelee = false;
            item.knockBack = 7.5f;
            item.value = Terraria.Item.buyPrice(0, 12, 0, 0);
            item.rare = 7;
            item.shoot = mod.ProjectileType("SeaWave");
            item.shootSpeed = 15f;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Blade Of The Leviathan");
            Tooltip.SetDefault("");
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "BladeOfTheWave");
            recipe.AddIngredient(null, "AzureElement", 6);
            recipe.AddIngredient(null, "SeaEssence", 8);
            recipe.AddIngredient(ItemID.BrokenHeroSword);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}