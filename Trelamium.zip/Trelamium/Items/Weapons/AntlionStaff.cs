using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AntlionStaff : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 10;
            item.summon = true;
            item.mana = 8;
            item.width = 60;
            item.height = 60;

            item.useTime = 26;
            item.useAnimation = 26;
            item.crit = 10;
            item.useStyle = 1;
            item.noMelee = true;
            item.knockBack = 5;
            item.value = Terraria.Item.buyPrice(0, 2, 0, 0);
            item.rare = 0;
            item.UseSound = SoundID.Item81;
            item.shoot = mod.ProjectileType("AntlionMinion");
            item.shootSpeed = 7f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Antlion Staff");
      Tooltip.SetDefault("Summons a Antlion swarmer to fight for you.");
    }

    }
}
