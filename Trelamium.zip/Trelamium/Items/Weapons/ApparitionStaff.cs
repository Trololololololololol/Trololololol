using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class ApparitionStaff : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 36;
            item.summon = true;
            item.mana = 12;
            item.width = 50;
            item.height = 50;

            item.useTime = 26;
            item.useAnimation = 26;
            item.crit = 22;
            item.useStyle = 1;
            item.noMelee = true;
            item.knockBack = 5;
            item.value = Terraria.Item.buyPrice(0, 12, 0, 0);
            item.rare = 5;
            item.UseSound = SoundID.Item81;
            item.shoot = mod.ProjectileType("ApparitionMinion");
            item.shootSpeed = 7f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Apparition Staff");
      Tooltip.SetDefault("Summons a shadowflame apparition to fight for you.");
    }

    }
}
