﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AlexandriteStaff : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 17;
            item.magic = true;

            item.width = 32;
            item.height = 32;
            item.useTime = 35;
            item.useAnimation = 35;
            item.crit = 7;
            item.useStyle = 5;
            item.mana = 5;
            Item.staff[item.type] = true;
            item.noMelee = true;
            item.knockBack = 3;
            item.value = Terraria.Item.buyPrice(0, 1, 50, 0);
            item.rare = 2;
            item.shootSpeed = 12f;
            item.shoot = ProjectileID.EmeraldBolt;
            item.UseSound = SoundID.Item43;
            item.autoReuse = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Alexandrite Staff");
            Tooltip.SetDefault("");
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("GreenMoss"), 8);
            recipe.AddTile(TileID.LivingLoom);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
