using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AlexandriteSummonStaff : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 20;
            item.summon = true;
            item.mana = 7;
            item.width = 46;
            item.height = 46;

            item.useTime = 26;
            item.useAnimation = 26;
            item.crit = 8;
            item.useStyle = 1;
            item.noMelee = true;
            item.knockBack = 8;
            item.value = Terraria.Item.buyPrice(0, 12, 0, 0);
            item.rare = 2;
            item.UseSound = SoundID.Item76;
            item.shoot = mod.ProjectileType("MossBallMinion");
            item.shootSpeed = 7f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Moss Ball Staff");
      Tooltip.SetDefault("Summons a Floating Mossball to fight for you.");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("GreenMoss"), 8);
            recipe.AddTile(TileID.LivingLoom);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
