﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BerserkBusterKnive : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 63;            //Sword damage
            item.thrown = true;            //if it's melee
            item.width = 30;              //Sword width
            item.height = 30;             //Sword height
            item.useTime = 25;          //how fast 
            item.useAnimation = 25;
            item.useStyle = 1;        //Style is how this item is used, 1 is the style of the sword
            item.knockBack = 4;      //Sword knockback
            item.value = Terraria.Item.buyPrice(0, 5, 0, 0);
            item.rare = 8;
            item.UseSound = SoundID.Item1;
            item.autoReuse = false;
            item.shoot = mod.ProjectileType("BerserkBeam");
            item.shootSpeed = 19f;
            item.useTurn = true;
            item.noUseGraphic = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Prime Dagger");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "PrimeSteel", 13);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
