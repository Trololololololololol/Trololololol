﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BuriedCutlass : BrutalItem
    {
        public override void SetDefaults()
        {

            item.width = 32;  //The width of the .png file in pixels divided by 2.
            item.damage = 23;  //Keep this reasonable please.
            item.useAnimation = 23;
            item.useTime = 19;  //Ranges from 1 to 55. 
            item.useTurn = true;
            item.useStyle = 1;
            item.rare = 5;
            item.scale = 1.25f;
            item.crit += 5;
            item.knockBack = 1.5f;  //Ranges from 1 to 9.
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;  //Dictates whether the weapon can be "auto-fired".
            item.height = 48;  //The height of the .png file in pixels divided by 2.
            item.maxStack = 1;

            item.value = 210000;  //Value is calculated in copper coins.
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Buried Blade");
      Tooltip.SetDefault("Upon hitting an enemy, a small amount of health will be restored.\nUpon killing an enemy, a bigger amount of health will be restored");
    }




        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Amber, 5);
            recipe.AddIngredient(ItemID.WoodenSword);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }


        
        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            if (Main.rand.Next(3) == 0)

            {
                player.statLife += 3;
                player.HealEffect(3);
            }
            if (target.life <= 0)
            {
                player.statLife += 15;
                player.HealEffect(15);
            }

        }

    }
}
