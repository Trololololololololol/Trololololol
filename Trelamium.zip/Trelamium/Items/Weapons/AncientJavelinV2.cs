﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AncientJavelinV2 : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 28;           //this is the item damage
            item.thrown = true;             //this make the item do throwing damage
            item.noMelee = true;
            item.width = 34;
            item.height = 34;
            item.useTime = 31;       //this is how fast you use the item
            item.useAnimation = 31;   //this is how fast the animation when the item is used
            item.useStyle = 1;
            item.knockBack = 3;
            item.value = 41510;
            item.rare = 5;
            //this is the item delay
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;       //this make the item auto reuse
            item.shoot = mod.ProjectileType("AncientJavelinPV2");  //javelin projectile
            item.shootSpeed = 12f;     //projectile speed
            item.useTurn = true;
            item.maxStack = 1;       //this is the max stack of this item //this make the item consumable when used
            item.noUseGraphic = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ancient Lance");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddRecipeGroup("Boss2Stuff", 30);
            recipe.AddIngredient(null, ("FadedSteel"), 12);
            recipe.AddIngredient(null, ("AncientJavelin"));
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
