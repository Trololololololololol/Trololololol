﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AncientHammer : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 31;
            item.melee = true;
            item.width = 36;

            item.height = 36;
            item.useTime = 48;
            item.useAnimation = 48;
            item.useStyle = 1;
            item.knockBack = 5;
            item.value = Terraria.Item.sellPrice(0, 4, 23, 0);
            item.rare = 4;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ancient Hammer");
      Tooltip.SetDefault("Not a tool, but still a hammer!");
    }


        
    }
}
