﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AncientHammerV2 : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 46;
            item.melee = true;
            item.width = 72;

            item.height = 72;
            item.useTime = 51;
            item.useAnimation = 51;
            item.useStyle = 1;
            item.knockBack = 5;
            item.value = Terraria.Item.sellPrice(0, 6, 23, 0);
            item.rare = 6;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ancient Great Hammer");
      Tooltip.SetDefault("Not a tool, but still a hammer!");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddRecipeGroup("Boss2Stuff", 30);
            recipe.AddIngredient(null, ("FadedSteel"), 14);
            recipe.AddIngredient(null, ("AncientHammer"));
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
