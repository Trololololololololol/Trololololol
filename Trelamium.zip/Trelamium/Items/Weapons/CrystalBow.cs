using Terraria;
using System;
using Terraria.ID;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class CrystalBow : ModItem
    {

        public override void SetDefaults()
        {

            item.damage = 40;
            item.noMelee = true;
            item.ranged = true;
            item.width = 18;
            item.height = 50;
            item.useTime = 25;
            item.useAnimation = 25;
            item.useStyle = 5;
            item.shoot = 3;
            item.useAmmo = 1;
            item.knockBack = 1;
            item.value = Terraria.Item.sellPrice(0, 1, 0, 0);
            item.rare = 6;
            item.UseSound = SoundID.Item5;
            item.autoReuse = false;
            item.shootSpeed = 10f;
            item.useAmmo = AmmoID.Arrow;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Crystal Bow");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.CrystalShard, 24);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
