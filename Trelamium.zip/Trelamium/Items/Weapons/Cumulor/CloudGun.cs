using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items;

namespace Trelamium.Items.Weapons.Cumulor
{
    public class CloudGun : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 17;
            item.ranged = true;
            item.width = 52;
            item.height = 18;
            item.useTime = 20;
            item.useAnimation = 20;
            item.useStyle = 5;
            item.knockBack = 2.5f;
            item.value = Terraria.Item.buyPrice(0, 8, 0, 0);
            item.rare = 2;
            item.UseSound = SoundID.Item11;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("CumulorCloudFriendly");
            item.shootSpeed = 8f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Stratus Rifle");
      Tooltip.SetDefault("");
    }

    }
}
