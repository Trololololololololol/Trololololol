using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.Cumulor
{
    public class Altostratus : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 28;                      
            item.magic = true;
            item.width = 24;
            item.height = 28;

            item.useTime = 23;
            item.useAnimation = 23;
            item.useStyle = 5;
            item.noMelee = true;
            item.knockBack = 7;    
            item.value = Terraria.Item.buyPrice(0, 3, 45, 0);
            item.rare = 2;
            item.mana = 14;
            item.UseSound = SoundID.Item20;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("CumulorCloudFriendly");
            item.shootSpeed = 16f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Altostratus");
      Tooltip.SetDefault("Releases a a Royal cloud");
    }

    }
}
