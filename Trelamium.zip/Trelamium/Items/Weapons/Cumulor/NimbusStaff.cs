using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.Cumulor
{
    public class NimbusStaff : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 24;
            item.summon = true;
            item.mana = 12;
            item.width = 50;
            item.height = 50;

            item.useTime = 26;
            item.useAnimation = 26;
            item.crit = 14;
            item.useStyle = 1;
            item.noMelee = true;
            item.knockBack = 6;
            item.value = Terraria.Item.buyPrice(0, 7, 0, 0);
            item.rare = 2;
            item.UseSound = SoundID.Item81;
            item.shoot = mod.ProjectileType("RoyalCloudMinion");
            item.shootSpeed = 7f;
            item.buffTime = 3600;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Royal Nimbus Staff");
      Tooltip.SetDefault("Summons a Royal Nimbus to fight for you.");
    }

    }
}
