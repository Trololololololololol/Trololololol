using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class CogThrow : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 47;           //this is the item damage
            item.thrown = true;             //this make the item do throwing damage
            item.noMelee = true;
            item.width = 22;
            item.height = 26;
            item.useTime = 14;       //this is how fast you use the item
            item.useAnimation = 14;   //this is how fast the animation when the item is used
            item.useStyle = 1;      
            item.knockBack = 3;
            item.crit = 30;
            item.value = Terraria.Item.buyPrice(0, 0, 12, 0);
            item.rare = 1;
            item.consumable = true;
            item.UseSound = SoundID.Item1; //item.UseSound = SoundID.Item1;   //The sound played when using your Weapon
            item.autoReuse = true;       //this make the item auto reuse
            item.shoot = mod.ProjectileType("CogThrowP");  //javelin projectile
            item.shootSpeed = 9f;     //projectile speed
            item.useTurn = true;
            item.maxStack = 999;       //this is the max stack of this item
            item.noUseGraphic = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Throwing Cog");
      Tooltip.SetDefault("");
    }

    }
}
