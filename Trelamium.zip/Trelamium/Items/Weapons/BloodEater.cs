using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
 
namespace Trelamium.Items.Weapons
{
    public class BloodEater : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 40;            
            item.thrown = true;
            item.width = 64;
            item.height = 64;
            item.useTime = 13;
            item.useAnimation = 13;
            item.crit = 7;
            item.noUseGraphic = true;
            item.useStyle = 1;
            item.knockBack = 3;
            item.value = Terraria.Item.buyPrice(0, 12, 50, 0);
            item.rare = 6;
            item.shootSpeed = 12f;
            item.shoot = mod.ProjectileType ("BloodEaterP");
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Blood Eater");
      Tooltip.SetDefault("");
    }

       
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "PieceOfFlesh", 11);
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
