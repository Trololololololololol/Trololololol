﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items;

namespace Trelamium.Items.Weapons
{
    public class AquamarineBow : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 22;
            item.ranged = true;
            item.width = 16;
            item.height = 30;
            item.useTime = 29;
            item.useAnimation = 29;
            item.useStyle = 5;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 3.5f;
            item.value = 15000;
            item.rare = 4;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shoot = 14; //idk why but all the guns in the vanilla source have this
            item.shootSpeed = 14f;
            item.useAmmo = 40;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Aquamarine Bow");
            Tooltip.SetDefault("");
        }
    }
}