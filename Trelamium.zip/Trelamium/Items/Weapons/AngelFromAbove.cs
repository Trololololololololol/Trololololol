﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class AngelFromAbove : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 52;
            item.ranged = true;
            item.width = 30;
            item.height = 64;
            item.useTime = 29;

            item.useAnimation = 29;
            item.useStyle = 5;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 1.5f;
            item.value = 151111;
            item.rare = 8;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shootSpeed = 53f;
            item.shoot = mod.ProjectileType("HectoagonArrow");
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Angel from above");
      Tooltip.SetDefault("The Angel Of Darkness.");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "AncientBow");
            recipe.AddIngredient(null, "EctoDiamondBow");
            recipe.AddIngredient(null, "FadedBow");
            recipe.AddIngredient(null, "WaterBow");
            recipe.AddIngredient(ItemID.MoltenFury);
            recipe.AddIngredient(ItemID.BeesKnees);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
