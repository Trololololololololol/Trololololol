﻿using Terraria;
using System;
using Terraria.ID;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.DreadfulReaper
{
    public class DarkBow : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 541;
            item.ranged = true;
            item.width = 28;
            item.height = 46;
            item.useTime = 16;
            item.useAnimation = 16;
            item.useStyle = 5;

            item.noMelee = true;
            item.knockBack = 4;
            item.value = Terraria.Item.buyPrice(4, 2, 50, 0);
            item.rare = -12;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shoot = 10;
            item.shoot = mod.ProjectileType("DreadfulArrow2"); //idk why but all the guns in the vanilla source have this
            item.shootSpeed = 10f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Darkness Breaker");
      Tooltip.SetDefault("'Shreads through enemies'");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "DreadScale", 17);
            recipe.AddIngredient(null, "TrelamiumCore", 6);
            recipe.AddIngredient(ItemID.PulseBow);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
