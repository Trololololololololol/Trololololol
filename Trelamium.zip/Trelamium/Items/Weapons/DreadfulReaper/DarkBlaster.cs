﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.DreadfulReaper
{
    public class DarkBlaster : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 200;
            item.ranged = true;
            item.width = 76;
            item.height = 22;

            item.useTime = 3;
            item.useAnimation = 7;
            item.useStyle = 5;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 1f;
            item.value = 55000000;
            item.rare = -12;
            item.UseSound = SoundID.Item92;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("Dread"); //idk why but all the guns in the vanilla source have this
            item.shootSpeed = 18f;
        }



    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Corrupted Starblast");
      Tooltip.SetDefault("Rapidly fires Dread bullets.\nDoes not requie ammo");
    }


        public override bool Shoot(Player player, ref Microsoft.Xna.Framework.Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float SpeedX = speedX + (float)Main.rand.Next(-20, 21) * 0.05f;
            float SpeedY = speedY + (float)Main.rand.Next(-20, 21) * 0.05f;
            if (Main.rand.Next(5) == 0)
            {
                Projectile.NewProjectile(position.X, position.Y, SpeedX, SpeedY, mod.ProjectileType("Dread"), (int)((double)damage * 0.6f), knockBack, player.whoAmI, 0.0f, 0.0f);
                Projectile.NewProjectile(position.X, position.Y, SpeedX, SpeedY, mod.ProjectileType("Dread"), (int)((double)damage * 0.6f), knockBack, player.whoAmI, 0.0f, 0.0f);
                Projectile.NewProjectile(position.X, position.Y, SpeedX, SpeedY, mod.ProjectileType("Dread"), (int)((double)damage * 0.6f), knockBack, player.whoAmI, 0.0f, 0.0f);
            }
            else
            {
                Projectile.NewProjectile(position.X, position.Y, SpeedX, SpeedY, mod.ProjectileType("Dread"), (int)((double)damage * 0.6f), knockBack, player.whoAmI, 0.0f, 0.0f);
                Projectile.NewProjectile(position.X, position.Y, SpeedX, SpeedY, mod.ProjectileType("Dread"), (int)((double)damage * 0.6f), knockBack, player.whoAmI, 0.0f, 0.0f);
                Projectile.NewProjectile(position.X, position.Y, SpeedX, SpeedY, mod.ProjectileType("Dread"), (int)((double)damage * 0.6f), knockBack, player.whoAmI, 0.0f, 0.0f);
            }
            return false;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "PrismaticWhaleOfTheGalaxy");
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.AddIngredient(null, "DreadScale", 20);
            recipe.AddIngredient(null, "TrelamiumCore", 5);
            recipe.AddIngredient(null, "CrystalCrusher");
            recipe.AddIngredient(ItemID.LunarBar, 5);
            recipe.AddIngredient(ItemID.SDMG);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
