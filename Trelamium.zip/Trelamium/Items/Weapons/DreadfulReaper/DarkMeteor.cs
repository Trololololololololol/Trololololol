﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.DreadfulReaper
{
    public class DarkMeteor : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 350;
            item.magic = true;
            item.width = 44;
            item.height = 42;

            item.useTime = 20;
            item.useAnimation = 20;
            item.useStyle = 5;
            Item.staff[item.type] = true;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 1f;
            item.value = 5500000;
            item.rare = -12;
            item.UseSound = SoundID.Item116;
            item.autoReuse = true;
            item.mana = 30;
            item.shoot = mod.ProjectileType("DarkMeteorP1"); //idk why but all the guns in the vanilla source have this
            item.shootSpeed = 18f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dread Blast Staff");
      Tooltip.SetDefault("Fires Dread Asteroids From The Sky");
    }


        public override bool Shoot(Player player, ref Microsoft.Xna.Framework.Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            switch (Main.rand.Next(3))
            {
                case 0: type = mod.ProjectileType("DarkMeteorP1"); break;
                case 1: type = mod.ProjectileType("DarkMeteorP2"); break;
                case 2: type = mod.ProjectileType("DarkMeteorP3"); break;
            }

            int numberProjectiles = 8 + Main.rand.Next(1);
            for (int index = 0; index < numberProjectiles; ++index)
            {
                Vector2 vector2_1 = new Vector2((float)((double)player.position.X + (double)player.width * 0.5 + (double)(Main.rand.Next(201) * -player.direction) + ((double)Main.mouseX + (double)Main.screenPosition.X - (double)player.position.X)), (float)((double)player.position.Y + (double)player.height * 0.5 - 600.0));   //this defines the projectile width, direction and position
                vector2_1.X = (float)(((double)vector2_1.X + (double)player.Center.X) / 2.0) + (float)Main.rand.Next(-200, 201);
                vector2_1.Y -= (float)(100 * index);
                float num12 = (float)Main.mouseX + Main.screenPosition.X - vector2_1.X;
                float num13 = (float)Main.mouseY + Main.screenPosition.Y - vector2_1.Y;
                if ((double)num13 < 0.0) num13 *= -1f;
                if ((double)num13 < 20.0) num13 = 20f;
                float num14 = (float)Math.Sqrt((double)num12 * (double)num12 + (double)num13 * (double)num13);
                float num15 = item.shootSpeed / num14;
                float num16 = num12 * num15;
                float num17 = num13 * num15;
                float SpeedX = num16 + (float)Main.rand.Next(-40, 41) * 0.02f;
                float SpeedY = num17 + (float)Main.rand.Next(-40, 41) * 0.02f;
                Projectile.NewProjectile(vector2_1.X, vector2_1.Y, SpeedX, SpeedY, type, damage, knockBack, Main.myPlayer, 0.0f, (float)Main.rand.Next(1));

       
            }
            return false;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "DreadScale", 14);
            recipe.AddIngredient(null, "TrelamiumCore", 5);
            recipe.AddIngredient(ItemID.MeteorStaff);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
