﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.DreadfulReaper
{
    [AutoloadEquip(EquipType.Shield, EquipType.Balloon)]
    public class DevilTrade : ModItem
    {


        public override void SetDefaults()
        {


            item.width = 36;
            item.height = 32;
            item.value = 5000000;
            item.rare = -12;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Devil Trade");
      Tooltip.SetDefault("Increases your critical strike change by 25%, movement speed by 40%, and damage by 15%\n'The Devil Takes Your Health Away\n'Agreeing To This Without 200 Health isn't a good idea''");
    }


        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.lifeRegen = -3;
            player.moveSpeed += 40f;
            player.rangedDamage += 0.15f;
            player.meleeDamage += 0.15f;
            player.minionDamage += 0.15f;
            player.magicDamage += 0.15f;
            player.thrownDamage += 0.15f;
            player.meleeCrit += 25;
            player.rangedCrit += 25;
            player.magicCrit += 25;
            player.thrownCrit += 25;
            player.statLifeMax2 -= 200;
        }

    }
}
