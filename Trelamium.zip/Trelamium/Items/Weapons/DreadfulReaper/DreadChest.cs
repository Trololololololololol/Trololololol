﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Weapons.DreadfulReaper
{
    [AutoloadEquip(EquipType.Body)]
    public class DreadChest : ModItem
    {


        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 18;

            item.value = 11010;
            item.rare = -12;
            item.defense = 27; //51
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dread Breastplate");
      Tooltip.SetDefault("20% increased ranged critical strike chance\nIncreases your movement speed by 10%\n'The Reaper Energy Surrounds You'");
    }


        public override void UpdateEquip(Player player)
        {
            player.rangedCrit += 20;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "DreadScale", 12);
            recipe.AddIngredient(null, "TrelamiumCore", 5);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
