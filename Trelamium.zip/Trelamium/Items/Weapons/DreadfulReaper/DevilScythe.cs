﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameContent;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.Graphics.Shaders;
using Terraria.ModLoader;
namespace Trelamium.Items.Weapons.DreadfulReaper
{
    public class DevilScythe : ModProjectile
    {
        public override void SetDefaults()
        {
            projectile.CloneDefaults(ProjectileID.DemonScythe);
            projectile.timeLeft = 50;
            aiType = ProjectileID.DemonScythe;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Dread");
        }

        public override bool PreKill(int timeLeft)
        {
            projectile.type = ProjectileID.DemonScythe;
            return true;
        }

        
    }
}
