﻿using Terraria;
using System;
using Terraria.ID;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.DreadfulReaper
{
    public class DarkCrossbow : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 392;
            item.ranged = true;
            item.width = 56;
            item.height = 24;
            item.useTime = 8;
            item.useAnimation = 8;
            item.useStyle = 5;

            item.noMelee = true;
            item.knockBack = 4;
            item.value = Terraria.Item.buyPrice(4, 2, 50, 0);
            item.rare = -12;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shoot = 10;
            item.shoot = mod.ProjectileType("DreadfulArrow2"); //idk why but all the guns in the vanilla source have this
            item.shootSpeed = 15f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Darkness Pulser");
      Tooltip.SetDefault("'Pulse Is Strong'");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "DreadScale", 15);
            recipe.AddIngredient(null, "TrelamiumCore", 7);
            recipe.AddIngredient(ItemID.HallowedRepeater);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
