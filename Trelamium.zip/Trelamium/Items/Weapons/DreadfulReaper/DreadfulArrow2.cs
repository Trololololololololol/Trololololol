﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons.DreadfulReaper
{
    public class DreadfulArrow2 : ModProjectile
    {
        public override void SetDefaults()
        {
            projectile.width = 10;  //Set the hitbox width
            projectile.height = 26;  //Set the hitbox height
            projectile.aiStyle = 1; //How the projectile works
            projectile.friendly = true;  //Tells the game whether it is friendly to players/friendly npcs or not
            projectile.hostile = false; //Tells the game whether it is hostile to players or not
            projectile.tileCollide = false; //Tells the game whether or not it can collide with a tile
            projectile.ignoreWater = true; //Tells the game whether or not projectile will be affected by water
            projectile.ranged = true;   //Tells the game whether it is a ranged projectile or not
            projectile.penetrate = 2; //Tells the game how many enemies it can hit before being destroyed
            projectile.timeLeft = 100; //The amount of time the projectile is alive for
            projectile.light = 0.1f; //This defines the projectile light
            aiType = 1; // this is the projectile ai style . 1 is for arrows style
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Dread");
        }




        public override void OnHitNPC(NPC target, int damage, float knockback, bool crit) //When you hit an NPC
        {

            target.AddBuff(BuffID.Confused, 510);    //this adds a buff to the npc hit. 210 it the time of the buff
            {
                projectile.ai[0] += 0.2f;
                projectile.velocity *= 1.5f;
            }
            {
                projectile.ai[1] += 1f;
                if (projectile.ai[1] == 30f)
                {
                    int numProj = 2;
                    float rotation = MathHelper.ToRadians(50);
                    for (int i = 0; i < numProj + 1; i++)
                    {
                        Vector2 perturbedSpeed = new Vector2(projectile.velocity.X, projectile.velocity.Y).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numProj - 1)));
                        Projectile.NewProjectile(projectile.Center.X, projectile.Center.Y, perturbedSpeed.X, perturbedSpeed.Y, mod.ProjectileType("DevastatorP2"), (int)((double)projectile.damage * 0.5f), projectile.knockBack, projectile.owner, 0f, 0f);
                    }


                }
            }
        }
    }
}

    
