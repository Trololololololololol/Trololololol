﻿using Terraria;
using System;
using Terraria.ID;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Terraria.ModLoader;

namespace Trelamium.Items.Weapons
{
    public class BoneBow : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 21;
            item.ranged = true;
            item.width = 26;
            item.height = 64;
            item.useTime = 25;
            item.useAnimation = 25;
            item.useStyle = 5;

            item.noMelee = true;
            item.knockBack = 4;
            item.value = Terraria.Item.buyPrice(0, 2, 50, 0);
            item.rare = 2;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shoot = 10;
            item.shoot = ProjectileID.BoneArrow;
            item.shootSpeed = 10f;
            item.useAmmo = AmmoID.Arrow;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Bone Bow");
      Tooltip.SetDefault("'Shoots Bone Arrows'");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Lens", 3);
            recipe.AddIngredient(null, "Teeth", 4);
            recipe.AddIngredient(null, "RippedRug", 15);
            recipe.AddTile(null, ("CryingBloodAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
