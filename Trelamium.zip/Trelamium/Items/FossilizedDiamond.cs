using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class FossilizedDiamond : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 28;
            item.height = 26;
            item.value = Terraria.Item.buyPrice(0, 1, 0, 0);
            item.rare = 1;
            item.maxStack = 99;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Fossilized Diamond");
      Tooltip.SetDefault("'Gitters with greed'");
    }

        public override void AddRecipes()
        {

            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Geode"), 6);
            recipe.AddTile(null, ("GemBlaster"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
