using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
	public class BossBags : GlobalItem
	{
		public override void OpenVanillaBag(string context, Player player, int arg)
		{
            if (context == "bossBag" && arg == ItemID.EyeOfCthulhuBossBag)
			{
                player.QuickSpawnItem(mod.ItemType("TheEyeBlade"));
			}
            if (context == "bossBag" && arg == ItemID.TwinsBossBag)
			{
                player.QuickSpawnItem(mod.ItemType("TrueEyeBlade"));
			}
		}
	}
}