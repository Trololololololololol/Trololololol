﻿using System.Collections.Generic;
using Terraria.ModLoader;

namespace Trelamium.Items.DeveloperSets
{
    [AutoloadEquip(EquipType.Legs)]
    public class DragonScaleLegs : ModItem
    {
        public override void SetDefaults()
        {



            item.width = 28;
            item.height = 20;
            item.rare = 1;
            item.vanity = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Dragon God Leggings");
            Tooltip.SetDefault("Great for impersonating developers!\n'The leggings of the Reigning Dragon.'");
        }

    }
}
