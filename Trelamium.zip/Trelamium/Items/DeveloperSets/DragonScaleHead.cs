﻿using System.Collections.Generic;
using Terraria.ModLoader;

namespace Trelamium.Items.DeveloperSets
{
    [AutoloadEquip(EquipType.Head)]
    public class DragonScaleHead : ModItem
    {
        public override void SetDefaults()
        {



            item.width = 28;
            item.height = 20;
            item.rare = 1;
            item.vanity = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Dragon God Mask");
            Tooltip.SetDefault("Great for impersonating developers!\n'made from the scales of an ancient erebos dragon'");
        }


        public override bool DrawHead()
        {
            return false;
        }
    }
}
