﻿using System.Collections.Generic;
using Terraria.ModLoader;

namespace Trelamium.Items.DeveloperSets
{
    [AutoloadEquip(EquipType.Body)]
    public class DragonScaleBody : ModItem
    {
        public override void SetDefaults()
        {



            item.width = 28;
            item.height = 20;
            item.rare = 1;
            item.vanity = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Dragon God Breastplate");
            Tooltip.SetDefault("Great for impersonating developers!\n'A interference in the geological matter this Flarium has grown in caused it to turn pink");
        }

    }
}
