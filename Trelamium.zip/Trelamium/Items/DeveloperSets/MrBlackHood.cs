﻿using System.Collections.Generic;
using Terraria.ModLoader;

namespace Trelamium.Items.DeveloperSets
{
    [AutoloadEquip(EquipType.Head)]
    public class MrBlackHood : ModItem
    {
        public override void SetDefaults()
        {



            item.width = 28;
            item.height = 30;
            item.rare = 8;
            item.vanity = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Plankish Mask");
      Tooltip.SetDefault("Great for impersonating Trelamium Devs!");
    }


        public override bool DrawHead()
        {
            return false;
        }
    }
}
