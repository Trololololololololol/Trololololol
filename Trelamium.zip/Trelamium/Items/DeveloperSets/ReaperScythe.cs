﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.DeveloperSets
{
    public class ReaperScythe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 381;
            item.melee = true;
            item.width = 64;

            item.height = 64;
            item.useTime = 28;
            item.useAnimation = 21;
            item.useStyle = 1;
            item.knockBack = 5;
            item.value = Terraria.Item.sellPrice(0, 14, 23, 0);
            item.rare = 4;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
            item.shoot = mod.ProjectileType("SANS2");  //javelin projectile
            item.shootSpeed = 12f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("The cat's Reaper");
      Tooltip.SetDefault("Cat-astrophe!");
    }

        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            if (Main.rand.Next(4) == 0)
            {

                int p = Projectile.NewProjectile(Main.MouseWorld.X + 100, Main.MouseWorld.Y, -.001f, 0, mod.ProjectileType("SANS2"), item.damage, item.knockBack, item.owner);
            }
            else

            {
                if (Main.rand.Next(3) == 0)
                {
                    int q = Projectile.NewProjectile(Main.MouseWorld.X - 100, Main.MouseWorld.Y, .001f, 0, mod.ProjectileType("SANS2"), item.damage, item.knockBack, item.owner);
                }
            }
        }
    }
}
