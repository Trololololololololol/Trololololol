using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.DeveloperSets
{
    public class TheRipper : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 8;
            item.melee = true;
            item.useTime = 22;
            item.useAnimation = 22;
            item.useStyle = 5;
            item.channel = true;
            item.knockBack = 4f;
            item.value = Terraria.Item.buyPrice(0, 13, 0, 0);
            item.rare = 0;
            item.autoReuse = false;
            item.shoot = mod.ProjectileType("RipperP");	         
            item.noUseGraphic = true;
            item.noMelee = true;
            item.UseSound = SoundID.Item1;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Plankish Ripper");
      Tooltip.SetDefault("");
    }

    }
}
