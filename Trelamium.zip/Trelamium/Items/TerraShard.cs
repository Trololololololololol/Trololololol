﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class TerraShard : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 24;
            item.maxStack = 99;
            item.value = Terraria.Item.sellPrice(0, 0, 10, 0);
            item.rare = 5;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Terra Shard");
      Tooltip.SetDefault("");
    }

    }
}
