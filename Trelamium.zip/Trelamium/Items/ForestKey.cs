using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
	public class ForestKey : ModItem
	{
		public override void SetDefaults()
		{

			item.width = 20;
			item.height = 20;
			item.maxStack = 999;
			item.rare = -12;
            item.consumable = false;
		}

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Forest Key");
      Tooltip.SetDefault("'Unlocks Hidden Treasures...'");
    }


	public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(null, "NatureEssence", 20);
            recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
