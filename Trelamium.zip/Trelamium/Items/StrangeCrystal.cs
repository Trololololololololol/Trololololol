﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class StrangeCrystal : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 14;
            item.height = 14;
            item.maxStack = 99;
            item.value = Terraria.Item.sellPrice(0, 0, 1, 0);
            item.rare = 2;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Strange Crystal");
      Tooltip.SetDefault("");
    }

    }
}
