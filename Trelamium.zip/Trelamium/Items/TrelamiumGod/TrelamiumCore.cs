using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace Trelamium.Items.TrelamiumGod
{
    public class TrelamiumCore : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Trelamium Core");
        }
        public override void SetDefaults()
        {
            item.width = 30;
            item.height = 24;
            item.maxStack = 99;
            item.value = Terraria.Item.buyPrice(1, 0, 0, 0);
        }
        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine line2 in list)
            {
                if (line2.mod == "Terraria" && line2.Name == "ItemName")
                {
                    line2.overrideColor = new Color(60, 60, 60);
                }
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("TrelamiumOre"), 3);
            recipe.AddIngredient(null, ("AzureElement"), 4);
            recipe.AddIngredient(null, ("XanthousElement"), 4);
            recipe.AddIngredient(null, ("GeraniumElement"), 4);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}