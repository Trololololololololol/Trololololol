using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    public class HardenedHeart : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 58;
            item.height = 52;

            item.value = Terraria.Item.buyPrice(3, 22, 0, 0);
            item.rare = 3;
            item.accessory = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Hardened Heart");
      Tooltip.SetDefault("Decreases you health by 30 but in trade for 10% increased throwing damage, velocity, and critical strike chance");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        { 
            {
                player.statLifeMax2 -= 30;  
                player.thrownDamage += 0.1f;
                player.thrownVelocity += 0.10f;
                player.thrownCrit += 10;
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Dolomite"), 80);
            recipe.AddIngredient(ItemID.LifeCrystal);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
