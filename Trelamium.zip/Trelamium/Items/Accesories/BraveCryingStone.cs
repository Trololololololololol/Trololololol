﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Balloon)]
    public class BraveCryingStone : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 16;

            item.value = Terraria.Item.sellPrice(0, 5, 0, 0);
            item.rare = 2;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Brave Stone");
      Tooltip.SetDefault("'It emits bravery'\nIncreases movement speed, damage and critical strike chance.");
    }


        public override void UpdateEquip(Player player)
        {
            player.minionDamage += 0.07f;
            player.meleeDamage += 0.07f;
            player.magicDamage += 0.07f;
            player.thrownDamage += 0.07f;
            player.rangedDamage += 0.07f;
            player.accRunSpeed = 4.75f;
            player.moveSpeed += 0.1f;
            player.meleeCrit += 5;
            player.thrownCrit += 5;
            player.rangedCrit += 5;
            player.magicCrit += 5;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddRecipeGroup("EvilBars", 12);
            recipe.AddIngredient(null, "CryingStone");
            recipe.AddRecipeGroup("RottenChunks", 15);
            recipe.AddIngredient(ItemID.HellstoneBar, 17);
            recipe.AddTile(null, ("AquaAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
