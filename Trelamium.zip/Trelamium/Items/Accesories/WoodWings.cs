using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Wings)]
    public class WoodWings : ModItem
    {
		public override void SetDefaults()
		{

			item.width = 28;
			item.height = 40;

			item.value = 10000;
			item.rare = 1;
			item.accessory = true;
		}

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Twig Wings");
      Tooltip.SetDefault("'Nature'");
    }

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			player.wingTimeMax = 40;
		}

        public override void VerticalWingSpeeds(Player player, ref float ascentWhenFalling, ref float ascentWhenRising, ref float maxCanAscendMultiplier, ref float maxAscentMultiplier, ref float constantAscend)
        {
			ascentWhenFalling = 0.50f;
			ascentWhenRising = 0.15f;
			maxCanAscendMultiplier = 1.5f;
			maxAscentMultiplier = 2f;
			constantAscend = 0.250f;
		}


        public override void HorizontalWingSpeeds(Player player, ref float speed, ref float acceleration)
        {
			speed = 3f;
			acceleration *= 0.8f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Wood, 12);
            recipe.AddIngredient(ItemID.Feather, 5);
            recipe.AddIngredient(null, ("GreenMoss"), 14);
            recipe.AddIngredient(null, ("AlluviumBar"), 6);
            recipe.AddTile(TileID.Furnaces);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
