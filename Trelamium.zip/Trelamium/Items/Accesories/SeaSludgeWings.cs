using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Wings)]
    public class SeaSludgeWings : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 28;

            item.value = Terraria.Item.buyPrice(0, 6, 0, 0);
            item.rare = 2;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Sea Sludge Wings");
      Tooltip.SetDefault("Flight Time: 20\nAccesend: 1");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.wingTimeMax = 20;
        }

        public override void VerticalWingSpeeds(Player player, ref float ascentWhenFalling, ref float ascentWhenRising, ref float maxCanAscendMultiplier, ref float maxAscentMultiplier, ref float constantAscend)
        {
            ascentWhenFalling = 0.5f;
            ascentWhenRising = 0.5f;
            maxCanAscendMultiplier = 0.5f;
            maxAscentMultiplier = 0.5f;
            constantAscend = 0.5f;
        }

        public override void HorizontalWingSpeeds(Player player, ref float speed, ref float acceleration)
        {
            speed = 1f;
            acceleration *= 0.35f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "SeaEssence" ,13);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
