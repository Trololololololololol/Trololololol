using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories
{
    public class MagicFeather : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 28;   
            item.height = 28;    


            item.value = Terraria.Item.buyPrice(0, 3, 0, 0); 
            item.rare = 3;             
            item.accessory = true;  

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Magic Feather");
      Tooltip.SetDefault("Enchanted by mythical creatures...\nIncreases total health and mana by 10\nIncreases ranged and magic critical strike chance by 5%.");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
		player.statManaMax2 += 10;
		player.magicCrit += 5;
                                    player.rangedCrit += 5;
                                    player.statLifeMax2 += 10;
                             

        }
        public override void AddRecipes()
        {                                       
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.BandofRegeneration);
            recipe.AddIngredient(ItemID.Feather, 10);
            recipe.AddIngredient(null, "StrangeCrystal", 12);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
