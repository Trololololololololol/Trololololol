﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Balloon)]
    public class ShadowflamePillarStone : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 16;

            item.value = Terraria.Item.sellPrice(0, 5, 0, 0);
            item.rare = 2;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Shadowflame Stone");
      Tooltip.SetDefault("'It emits pure shadowflame'\nIncreases movement speed, damage and critical strike chance.");
    }


        public override void UpdateEquip(Player player)
        {
            int randomDust = Main.rand.Next(2);
            if (randomDust == 0)
            {
                randomDust = 27;
            }
            else
            {
                randomDust = 27;
            }
            player.minionDamage += 0.15f;
            player.meleeDamage += 0.15f;
            player.magicDamage += 0.15f;
            player.thrownDamage += 0.15f;
            player.rangedDamage += 0.15f;
            player.accRunSpeed = 7.75f;
            player.moveSpeed += 0.15f;
            player.meleeCrit += 15;
            player.thrownCrit += 15;
            player.rangedCrit += 15;
            player.magicCrit += 15;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddRecipeGroup("AdamantiteBars", 10);
            recipe.AddIngredient(null, "BraveCryingStone");
            recipe.AddRecipeGroup("RottenChunks", 15);
            recipe.AddIngredient(ItemID.AvengerEmblem);
            recipe.AddTile(null, ("AquaAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
