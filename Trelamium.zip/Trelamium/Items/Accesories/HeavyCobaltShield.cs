﻿using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Shield)]
    public class HeavyCobaltShield : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 28;


            item.value = Terraria.Item.sellPrice(0, 4, 75, 0);
            item.rare = 6;       
            item.accessory = true;
            item.defense = 5;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Heavy Metal Shield");
      Tooltip.SetDefault("Grants immunity to knockback\nWhen player is under 50% of health, you gain 30 defense");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (player.statLife <= (player.statLifeMax2 * 0.50f))
            {
                player.statDefense += 30;
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("HeavyBlueMetal"), 15);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
