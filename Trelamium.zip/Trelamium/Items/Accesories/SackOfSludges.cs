﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories
{
    public class SackOfSludges : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 12;
            item.height = 16;

            item.value = Terraria.Item.buyPrice(0, 1, 0, 0);
            item.rare = 2;
            item.accessory = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Sack Of Sludges");
      Tooltip.SetDefault("Increases Max Life, max mana and damage.");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
            player.statLifeMax2 += 25;
            player.statManaMax2 += 25;
            player.rangedDamage += 0.05f;
            player.meleeDamage += 0.05f;
            player.magicDamage += 0.05f;
            player.thrownDamage += 0.05f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "GreenSludge");
            recipe.AddIngredient(null, "BlueSludge");
            recipe.AddIngredient(null, "RedSludge");
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
