using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Wings)]
    public class TechnoliteWings : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 20;

            item.value = Terraria.Item.buyPrice(0, 26, 0, 0);
            item.rare = 8;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Technolite Wings");
      Tooltip.SetDefault("Flight Time: 160");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.wingTimeMax = 160;
        }

        public override void VerticalWingSpeeds(Player player, ref float ascentWhenFalling, ref float ascentWhenRising, ref float maxCanAscendMultiplier, ref float maxAscentMultiplier, ref float constantAscend)
        {
            ascentWhenFalling = 0.70f;
            ascentWhenRising = 0.07f;
            maxCanAscendMultiplier = 2f;
            maxAscentMultiplier = 1.5f;
            constantAscend = 0.3f;
        }

        public override void HorizontalWingSpeeds(Player player, ref float speed, ref float acceleration)
        {
            speed = 11f;
            acceleration *= 11f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "TechnoliteBar", 14);
            recipe.AddIngredient(ItemID.SoulofFlight, 30);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
