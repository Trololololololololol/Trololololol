using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Body)]
    public class PrawnSuit : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 20;


            item.value = Terraria.Item.sellPrice(0, 5, 0, 0);
            item.rare = 4;
            item.defense = 6;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Meteor Prawn Suit");
      Tooltip.SetDefault("+5% Melee Speed! +7% Melee Damage! works with meteor armor as well\nWorks as armor and accesory");
    }


        public override void UpdateEquip(Player player)
        {
            player.meleeSpeed += 0.1f;
            player.meleeDamage += 0.07f;
        }
        public override void AddRecipes() 
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.MeteorSuit);
            recipe.AddIngredient(ItemID.MeteoriteBar, 15);
            recipe.AddIngredient(ItemID.HellstoneBar, 30);
            recipe.AddTile(TileID.TinkerersWorkbench);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
