﻿using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    public class ManaTalisman : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 30;


            item.value = Terraria.Item.buyPrice(0, 15, 0, 0);
            item.rare = -12;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Mana Talisman");
      Tooltip.SetDefault("Maximum Mana is icreased by 60.\nAll Magic status is increased by 13%.");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.statManaMax2 += 60;
            player.magicDamage += 0.13f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.ManaCrystal, 2);
            recipe.AddIngredient(null, ("MagicCharm"), 1); 
            recipe.AddTile(TileID.TinkerersWorkbench);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
