﻿using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Shield)]
    public class ElementalGuardianShield : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 28;


            item.value = Terraria.Item.sellPrice(5, 4, 75, 0);
            item.rare = -12;
            item.accessory = true;
            item.defense = 30;

        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Elemental Guardian Shield");
            Tooltip.SetDefault("'The defense of the guardian'\nIncreases critical chance slightly\nYou gain a massive health boost\nWhen player is low on health, you gain a massive defense boost");
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (player.statLife <= (player.statLifeMax2 * 0.50f))
            {
                player.meleeCrit += 20;
                player.rangedCrit += 20;
                player.magicCrit += 20;
                player.thrownCrit += 20;
            }
            player.statLifeMax2 += 250;
            if (player.statLife <= (player.statLifeMax2 * 0.15f))
            {
                player.statDefense += 100;
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("DragonShield"));
            recipe.AddIngredient(null, ("SoulOfCright"), 15);
            recipe.AddIngredient(null, ("DreadScale"), 15);
            recipe.AddIngredient(null, ("LunaticShield"));//LunaticShield
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
