using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories
{
    public class DevilFeather : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 28;   
            item.height = 28;    


            item.value = Terraria.Item.buyPrice(0, 3, 0, 0); 
            item.rare = 3;             
            item.accessory = true;  

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Devil Feather");
      Tooltip.SetDefault("Cursed by demons\nDecreases total health and mana by 20\nIncreases ranged and magic critical strike chance by 12%.");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
		player.statManaMax2 -= 20;
		player.magicCrit += 12;
                                    player.rangedCrit += 12;
                                    player.statLifeMax2 -= 20;
                             

        }
        public override void AddRecipes()
        {                                       
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Feather, 5);
            recipe.AddIngredient(ItemID.Hellstone, 10);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
