﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories
{
    public class AncientFlame : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 20;
            item.height = 26;


            item.value = Terraria.Item.buyPrice(0, 7, 0, 0);
            item.rare = 6;
            item.accessory = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ancient Flame");
      Tooltip.SetDefault("+ 2 max minions .\n5% increased minion damage.");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
            player.maxMinions += 2;
            player.minionKB += 1.5f;
            player.minionDamage += 0.05f;
            player.jumpSpeedBoost += 2f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "SkyEagleTalisman");
            recipe.AddIngredient(null, "PharaonBelt");
            recipe.AddIngredient(null, "SummonTrophy");
            recipe.AddIngredient(null, "AncientMedalion");
            recipe.AddIngredient(null, "SoundPrism", 25);
            
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
