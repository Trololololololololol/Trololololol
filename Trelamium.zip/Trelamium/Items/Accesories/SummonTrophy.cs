﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories
{
    public class SummonTrophy : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 30;

            item.value = Terraria.Item.buyPrice(0, 2, 0, 0);
            item.rare = 4;
            item.accessory = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Emerald Trophy");
      Tooltip.SetDefault("+ 1 max minions .");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
            player.maxMinions += 1;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Wood, 10);
            recipe.AddIngredient(ItemID.Emerald, 10);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
