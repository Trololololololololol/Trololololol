using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories
{
    public class DolomiteRing : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 58;
            item.height = 52;


            item.value = Terraria.Item.buyPrice(0, 5, 0, 0); 
            item.rare = 2;   
            item.accessory = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dolomite Ring");
      Tooltip.SetDefault("Grants immunity to knockback\nIncreases your throwing Velocity by 12%");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.noKnockback = true;
            player.thrownVelocity += 100;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Dolomite"), 10);
            recipe.AddIngredient(ItemID.BandofRegeneration);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
