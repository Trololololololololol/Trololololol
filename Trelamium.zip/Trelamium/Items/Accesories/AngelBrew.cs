using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories  
{
    public class AngelBrew : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 34;   
            item.height = 34;    


            item.value = Terraria.Item.buyPrice(0, 7, 0, 0); 
            item.rare = 6;             
            item.accessory = true;  

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Angel Brew");
      Tooltip.SetDefault("The creation of god-like creatures\nIncreases total health and mana by 50\nIncreases most movement stats.\nIncreases ranged and magic critical strike chance by 10%.");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
		player.statManaMax2 += 50;
		player.manaCost *= 0.85f;
		player.magicCrit += 10;
                                    player.rangedCrit += 10;
                                    player.statLifeMax2 += 50;
                                    player.jumpSpeedBoost += 2f;
                                
        }
        public override void AddRecipes()
        {                                       
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "SkyEagleTalisman");
            recipe.AddIngredient(null, "MagicFeather");
            recipe.AddIngredient(null, "DevilFeather");
            recipe.AddIngredient(null, "SoundCore", 20);
            recipe.AddIngredient(null, "SoundPrism", 25);
            recipe.AddTile(null, "SoundConversatorTile");

            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
