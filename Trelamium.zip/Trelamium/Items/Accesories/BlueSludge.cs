﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories
{
    public class BlueSludge : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 12;
            item.height = 16;

            item.value = Terraria.Item.buyPrice(0, 1, 0, 0);
            item.rare = 2;
            item.accessory = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Blue Sludge");
      Tooltip.SetDefault("Increases Max Mana.");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
            player.statManaMax2 += 25;
        }
    }
}
