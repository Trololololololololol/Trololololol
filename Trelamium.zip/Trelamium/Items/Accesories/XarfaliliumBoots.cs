﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using System;

namespace Trelamium.Items.Accesories
{
    public class XarfaliliumBoots : ModItem
    {
        public override void SetDefaults()
        {


            item.width = 36;
            item.height = 32;
            item.value = Terraria.Item.buyPrice(0, 20, 0, 0);
            item.rare = 8;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Xarfalilium Boots");
      Tooltip.SetDefault("Speed of Lucifer himself\nAllows you to walk through lava\nTemporary immunity to lava");
    }


        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.accRunSpeed = 10f;
            player.rocketBoots = 5;
            player.moveSpeed += 0.9f;
            player.ignoreWater = true;
            player.fireWalk = true;
            player.lavaMax += 500;
            player.wingTimeMax += 50;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("XarfaliliumBar"), 13);
            recipe.AddIngredient(ItemID.FrostsparkBoots);
            recipe.AddIngredient(ItemID.SoulofNight, 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
