﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria.DataStructures;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    public class Cursed_Pendant : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 34;
            item.height = 46;
            item.value = 100;
            item.rare = 6;
            item.useAnimation = 30;
            item.useTime = 30;
            item.useStyle = 4;
            item.accessory = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Cursed Pendant");
            Tooltip.SetDefault("Having more than half of your maximum health grants you the 'Corruption Chaos' buff increasing your brutal damage");
            Main.RegisterItemAnimation(item.type, new DrawAnimationVertical(6, 6));
            ItemID.Sets.ItemIconPulse[item.type] = true;
            ItemID.Sets.ItemNoGravity[item.type] = true;
        }
        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
            if (player.statLife >= (player.statLifeMax2 * 0.50f))
            {
                player.AddBuff(mod.BuffType("CorruptionChaos"), 10);
            }
        }

    }
}