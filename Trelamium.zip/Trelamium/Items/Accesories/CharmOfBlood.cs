﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    public class CharmOfBlood : ModItem
    {
        public override void SetDefaults()
        {


            item.width = 28;
            item.height = 32;
            item.value = Terraria.Item.buyPrice(0, 2, 50, 0);
            item.rare = 4;
            item.accessory = true;
            
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Charm Of Blood");
            Tooltip.SetDefault("Increases throwing damage when below 25% health");
        }


        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (player.statLife <= (player.statLifeMax2 * 0.25f))
            {
                player.thrownDamage += 0.15f;
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Lens", 2);
            recipe.AddIngredient(null, "Teeth", 6);
            recipe.AddIngredient(null, "RippedRug", 12);
            recipe.AddTile(null, ("CryingBloodAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
