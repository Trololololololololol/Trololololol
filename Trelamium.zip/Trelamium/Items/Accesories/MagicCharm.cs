using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    public class MagicCharm : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 32;

            item.value = Terraria.Item.buyPrice(0, 2, 0, 0);
            item.rare = 2;
            item.accessory = true;
            item.defense = 2;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Magic Charm");
      Tooltip.SetDefault("Increases your maxium mana by 40.");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
             player.statManaMax2 += 40;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.ManaCrystal, 2);
            recipe.AddIngredient(ItemID.BandofStarpower, 1); 
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
