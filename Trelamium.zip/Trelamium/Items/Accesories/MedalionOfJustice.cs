using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    public class MedalionOfJustice : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 40;
            item.height = 40;

            item.value = Terraria.Item.buyPrice(0, 2, 0, 0);
            item.rare = 8;
            item.accessory = true;
            item.defense = 2;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Medalion of Justice");
      Tooltip.SetDefault("Increases your damage by 18% when below 75% health");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (player.statLife <= (player.statLifeMax2 * 0.75f))
            {
                player.rangedDamage += 0.18f;
                player.meleeDamage += 0.18f;
                player.thrownDamage += 0.18f;
                player.magicDamage += 0.18f;
                player.minionDamage += 0.18f;
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.CobaltShield);
            recipe.AddIngredient(ItemID.HellstoneBar, 15);
            recipe.AddIngredient(null, "ExecutionerMedalion");
            recipe.AddTile(TileID.TinkerersWorkbench);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
