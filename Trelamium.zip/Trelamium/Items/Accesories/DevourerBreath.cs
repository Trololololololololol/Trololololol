﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria.DataStructures;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    public class DevourerBreath : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 34;
            item.height = 46;
            item.value = 10000000;
            item.rare = 10;
            item.useAnimation = 30;
            item.useTime = 30;
            item.useStyle = 4;
            item.accessory = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Devourer Breath");
            Tooltip.SetDefault("Having more than half of your health grants you the 'Cright Chaos' buff increasing brutal damage\nReduces the cooldown of using healing potions");
        }
        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
            if (player.statLife >= (player.statLifeMax2 * 0.50f))
            {
                player.AddBuff(mod.BuffType("CrightChaos"), 10);
            }
            player.pStone = true;
            player.lifeRegen += 3;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.CharmofMyths);
            recipe.AddIngredient(null, "Cursed_Pendant");
            recipe.AddIngredient(null, "SoulOfCright", 35);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}