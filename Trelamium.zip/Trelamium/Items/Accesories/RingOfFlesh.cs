using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    public class RingOfFlesh : ModItem
    {
        public override void SetDefaults()
        {


            item.width = 20;
            item.height = 22;
            item.value = Terraria.Item.buyPrice(0, 12, 0, 0);
            item.rare = 5;
            item.accessory = true;
            item.expert = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Eater Bane Ring");
      Tooltip.SetDefault("When at 50% of your maximum health, you gain a 20% critical strike chance increase\nWhen at 20% of your maximum health, you inflict ichor for melee weapons\nWhen at 50% of your maximum mana, you gain a 10% life regeneration increase");
    }


        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (player.statLife <= (player.statLifeMax2 * 0.5f))
            {
                player.meleeCrit += 20;
                player.thrownCrit += 20;
                player.rangedCrit += 20;
                player.magicCrit += 20;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.2f))
            {
                player.AddBuff(BuffID.WeaponImbueIchor, 2);
            }
            if (player.statLife <= (player.statManaMax2 * 0.5f))
            {
                player.lifeRegen += 5;
            }
        }
    }
}
