using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    public class FuriousStar : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 30;

            item.value = Terraria.Item.sellPrice(0, 1, 50, 0);
            item.rare = 6;       
            item.accessory = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Space Emblem");
      Tooltip.SetDefault("Increases your throwing velocity by 13%");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.thrownVelocity += 0.13f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.FallenStar, 2);
            recipe.AddIngredient(ItemID.Shuriken);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
