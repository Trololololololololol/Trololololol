﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Balloon)]
    public class CryingStone : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 16;

            item.value = Terraria.Item.sellPrice(0, 2, 0, 0);
            item.rare = 2;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Crying Stone");
      Tooltip.SetDefault("'It seems sad'\nIncreases movement speed and damage.");
    }


        public override void UpdateEquip(Player player)
        {
            player.minionDamage += 0.05f;
            player.meleeDamage += 0.05f;
            player.magicDamage += 0.05f;
            player.thrownDamage += 0.05f;
            player.rangedDamage += 0.05f;
            player.accRunSpeed = 2.75f;
            player.moveSpeed += 0.1f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Aquamarine", 21);
            recipe.AddTile(null, ("AquaAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
