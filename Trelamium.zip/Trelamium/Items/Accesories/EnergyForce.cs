using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Balloon)]
    public class EnergyForce : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 26;
            item.height = 26;

            item.value = Terraria.Item.sellPrice(0, 5, 0, 0); 
            item.rare = 3;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Energy Force");
      Tooltip.SetDefault("30% Increased Mining Speed.");
    }


        public override void UpdateEquip(Player player)
        {
            player.pickSpeed += 0.30f;
        }
    }
}
