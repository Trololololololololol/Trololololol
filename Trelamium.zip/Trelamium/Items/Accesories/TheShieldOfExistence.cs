using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories 
{
    [AutoloadEquip(EquipType.Shield)]
    public class TheShieldOfExistence : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 58;
            item.height = 52;


            item.value = Terraria.Item.buyPrice(0, 3, 22, 0);
            item.rare = 8;      
            item.accessory = true;
            item.defense = 8;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Shield Of Existence");
      Tooltip.SetDefault("Grants immunity to knockback!\nIncreases your max heath by 100\nIncreases your melee damage and speed by 20%");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.noKnockback = true;
            player.statLifeMax2 += 100;
            player.meleeSpeed += 0.20f;
            player.meleeDamage += 0.20f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.PaladinsShield);
            recipe.AddIngredient(ItemID.SunStone);
            recipe.AddIngredient(ItemID.ObsidianSkull);
            recipe.AddIngredient(ItemID.FragmentSolar, 20);
            recipe.AddIngredient(null, ("GalaxyCore"), 6);
            recipe.AddIngredient(null, ("RedHotCore"), 6);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
