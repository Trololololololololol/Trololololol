﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    public class MysticalEmblem : ModItem
    {
        public override void SetDefaults()
        {


            item.width = 20;
            item.height = 22;
            item.value = Terraria.Item.buyPrice(0, 35, 0, 0);
            item.rare = 5;
            item.accessory = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Ancient Blood Emblem");
            Tooltip.SetDefault("Increases throwing critical strike chance when below half health");
        }


        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (player.statLife <= (player.statLifeMax2 * 0.5f))
            {
                player.thrownCrit += 20;
            }
        }
    }
}
