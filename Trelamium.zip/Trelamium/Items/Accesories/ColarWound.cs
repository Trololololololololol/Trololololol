﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Waist)]
    public class ColarWound : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 34;
            item.height = 34;


            item.value = Terraria.Item.buyPrice(0, 4, 0, 0);
            item.rare = 6;
            item.accessory = true;

        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Coral Wounds");
            Tooltip.SetDefault("Increases health, mana and critical strike chance slightly");
        }

        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
            player.statManaMax2 += 50;
            player.magicCrit += 10;
            player.rangedCrit += 10;
            player.meleeCrit += 10;
            player.thrownCrit += 10;
            player.statLifeMax2 += 25;
            

        }
    }
}
