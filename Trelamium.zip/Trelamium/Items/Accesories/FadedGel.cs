﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories
{
    public class FadedGel : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 10;
            item.height = 18;
            item.maxStack = 99;
            item.value = Terraria.Item.buyPrice(0, 0, 5, 0);
            item.rare = 2;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Faded Gel");
      Tooltip.SetDefault("");
    }

    }
}
