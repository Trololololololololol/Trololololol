﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Wings)]

    public class MilkyWay : ModItem
    {

        public override void SetDefaults()
        {


            item.width = 36;
            item.height = 32;
            item.value = 5000000;
            item.rare = 8;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Milky way");
      Tooltip.SetDefault("Counts as wings\n'The Bright Of The Universe Rests On You'\nIncreases Damage Dealt Slightly\nYou Run Really Fast!\nGrants The Effects of The Universe\nYou Can Walk On Any Liquid");
    }


        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.accRunSpeed = 15f;
            player.rocketBoots = 1;
            player.moveSpeed += 20f;
            player.iceSkate = true;
            player.waterWalk = true;
            player.fireWalk = true;
            player.wingTimeMax = 100;
        }

        public override void VerticalWingSpeeds(Player player, ref float ascentWhenFalling, ref float ascentWhenRising, ref float maxCanAscendMultiplier, ref float maxAscentMultiplier, ref float constantAscend)
        {
            ascentWhenFalling = 0.5f;
            ascentWhenRising = 0.10f;
            maxCanAscendMultiplier = 1f;
            maxAscentMultiplier = 5f;
            constantAscend = 0.14f;
        }

        public override void HorizontalWingSpeeds(Player player, ref float speed, ref float acceleration)
        {
            speed = 10f;
            acceleration *= 3f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "AeroGlide");
            recipe.AddIngredient(null, "DarkBar", 20);
            recipe.AddIngredient(ItemID.SpectreBar, 10);
            recipe.AddIngredient(ItemID.SoulofFlight, 35);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }


    }
}
