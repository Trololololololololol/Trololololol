using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories
{
    public class SkyEagleTalisman : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 26;   
            item.height = 32;    


            item.value = Terraria.Item.buyPrice(0, 2, 0, 0); 
            item.rare = 2;             
            item.accessory = true;  

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Mythical Eagle Talisman");
      Tooltip.SetDefault("The creation of mythical flying dragons\nIncreases jump speed by 150%\nIncreases ranged and magic critical strike chance by 5%.");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
		player.manaCost *= 0.85f;
		player.magicCrit += 5;
                                    player.rangedCrit += 5;
        	player.jumpSpeedBoost += 1.5f;
                                
        }
        public override void AddRecipes()
        {                                       
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Feather, 3); 
            recipe.AddIngredient(ItemID.FallenStar);
            recipe.AddIngredient(null, "StrangeCrystal", 22);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
