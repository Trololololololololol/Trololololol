﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Wings, EquipType.Back)]
    public class AeroGlide : ModItem
    {

        public override void SetDefaults()
        {


            item.width = 36;
            item.height = 32;
            item.value = 5000000;
            item.rare = 3;
            item.accessory = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aero Glide");
      Tooltip.SetDefault("Counts as wings\n'The Beggining of the Ancient'\nYou Run Like A Hero!\nYou Can Walk On Most liquids");
    }


        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.accRunSpeed = 8f;
            player.rocketBoots = 1;
            player.moveSpeed += 2f;
            player.waterWalk = true;
            player.fireWalk = true;
            player.wingTimeMax = 20;
        }

        public override void VerticalWingSpeeds(Player player, ref float ascentWhenFalling, ref float ascentWhenRising, ref float maxCanAscendMultiplier, ref float maxAscentMultiplier, ref float constantAscend)
        {
            ascentWhenFalling = 0.5f;
            ascentWhenRising = 0.10f;
            maxCanAscendMultiplier = 1f;
            maxAscentMultiplier = 5f;
            constantAscend = 0.14f;
        }

        public override void HorizontalWingSpeeds(Player player, ref float speed, ref float acceleration)
        {
            speed = 4f;
            acceleration *= 1.5f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "SoundPrism", 25);
            recipe.AddIngredient(null, "StrangeCrystal", 20);
            recipe.AddIngredient(ItemID.HermesBoots);
            recipe.AddIngredient(ItemID.WaterWalkingBoots);
            recipe.AddIngredient(ItemID.HellstoneBar, 10);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }


    }
}
