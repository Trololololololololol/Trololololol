﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Accesories
{
    [AutoloadEquip(EquipType.Balloon)]
    public class ColarWoundBalloon : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 28;


            item.value = Terraria.Item.buyPrice(0, 8, 0, 0);
            item.rare = 7;
            item.accessory = true;

        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Coral In A Balloon");
            Tooltip.SetDefault("Increases health, mana, jump height and critical strike chance slightly");
        }

        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
            player.statManaMax2 += 50;
            player.magicCrit += 15;
            player.rangedCrit += 15;
            player.meleeCrit += 15;
            player.thrownCrit += 15;
            player.statLifeMax2 += 30;
            player.jumpSpeedBoost += 2.5f;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("ColarWound"));
            recipe.AddIngredient(null, "CryingStone");
            recipe.AddIngredient(ItemID.ShinyRedBalloon);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
