using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria.DataStructures;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class EnchantcianPrism : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 55;
            item.height = 224;
            item.value = Terraria.Item.sellPrice(0, 0, 5, 0);
            item.rare = -12;
            item.maxStack = 99;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Enchanted Prism");
            Tooltip.SetDefault("");
            Main.RegisterItemAnimation(item.type, new DrawAnimationVertical(6, 4));
            ItemID.Sets.AnimatesAsSoul[item.type] = true;
            ItemID.Sets.ItemIconPulse[item.type] = true;
            ItemID.Sets.ItemNoGravity[item.type] = true;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.ManaCrystal, 2);
            recipe.AddTile(TileID.Furnaces);
            recipe.SetResult(this, 10);
            recipe.AddRecipe();
        }
    }
}
