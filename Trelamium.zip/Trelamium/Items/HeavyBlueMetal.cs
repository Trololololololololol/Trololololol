using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class HeavyBlueMetal : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 24;
            item.maxStack = 99;
            item.value = Terraria.Item.sellPrice(0, 3, 25, 0);   
            item.rare = 7;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Heavy Blue Metal");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.CobaltBar, 6);
            recipe.AddIngredient(ItemID.Sapphire, 3);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}

        
            
        
