using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Azolinth
{
    public class CosmoDestroyer : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 180;
            item.melee = true;
            item.width = 70;
            item.height = 70;
            item.useTime = 20;

            item.useAnimation = 20;
            item.useStyle = 1;
            item.knockBack = 8.5f;
            item.value = Terraria.Item.sellPrice(7, 80, 0, 0);
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = false;
            item.shoot = mod.ProjectileType("ElectricBeam");
            item.shootSpeed = 20f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Cosmo Destroyer");
      Tooltip.SetDefault("Bursts a Colossal beam of electricity");
    }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine line2 in list)
            {
                if (line2.mod == "Terraria" && line2.Name == "ItemName")
                {
                    line2.overrideColor = new Color(155, 0, 78);
                }
            }
        }
        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            target.AddBuff(BuffID.Electrified, 500);
        }
    }
}
