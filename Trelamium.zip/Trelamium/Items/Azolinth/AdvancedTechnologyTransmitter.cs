﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Azolinth
{
    public class AdvancedTechnologyTransmitter : ModItem
	{
		public override void SetDefaults()
		{

			item.width = 32;
			item.height = 32;
			item.maxStack = 20;

			item.useAnimation = 45;
			item.useTime = 45;
			item.useStyle = 4;
			item.UseSound = SoundID.Item44;
			item.consumable = true;
			item.shoot = mod.ProjectileType("AzolinthSpawn");
		}

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Advanced Technology Transmitter");
      Tooltip.SetDefault("Transmits a distress signal to A.Z.O.L.I.N.T.H");
    }

		public override bool CanUseItem(Player player)
		{
            return !NPC.AnyNPCs(mod.NPCType("AzolinthHead"));
		}

		public override void ModifyTooltips(List<TooltipLine> list)
	    {
	        foreach (TooltipLine line2 in list)
	        {
	            if (line2.mod == "Terraria" && line2.Name == "ItemName")
	            {
                    line2.overrideColor = new Color(155, 0, 78);
	            }
	        }
	    }

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.SoulofMight, 8);
			recipe.AddIngredient(null, "TechnoliteBar", 1);
            recipe.AddIngredient(null, "Crystal", 5);
            recipe.AddIngredient(null, "Darksteel", 3);
            recipe.AddIngredient(null, "UnknownTechologyCore");
			recipe.AddTile(TileID.LunarCraftingStation);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
