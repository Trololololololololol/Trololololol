using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Azolinth
{
    public class ShockwaveProjectile : ModProjectile
    {

        public override void SetDefaults()
        {
            projectile.extraUpdates = 0;
            projectile.width = 16;
            projectile.height = 16;
            projectile.aiStyle = 99;
            projectile.friendly = true;
            projectile.penetrate = 9999;
            projectile.melee = true;
            ProjectileID.Sets.YoyosLifeTimeMultiplier[projectile.type] = -1f;
            ProjectileID.Sets.YoyosMaximumRange[projectile.type] = 480f;
            ProjectileID.Sets.YoyosTopSpeed[projectile.type] = 17.7f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Shockwave");
    }

        public override void AI()
        {
            if (Main.rand.Next(8) == 0)
            {
                Projectile.NewProjectile(projectile.Center.X, projectile.Center.Y - 16f, Main.rand.Next(-7, 9) * .25f, Main.rand.Next(-8, -3) * .5f, mod.ProjectileType("TelsaBoltProjectile"), (int)(projectile.damage * .5f), 0, projectile.owner);
            }
        }
    }
}
