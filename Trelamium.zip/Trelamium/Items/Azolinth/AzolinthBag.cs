using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Azolinth
{
    public class AzolinthBag : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Treasure Bag");
            Tooltip.SetDefault("Right Click to open");
        }
        public override void SetDefaults()
        {
            item.maxStack = 999;
            item.consumable = true;
            item.width = 32;
            item.height = 32;
            item.rare = -12;
            bossBagNPC = mod.NPCType("AzolinthHead");
            item.expert = true;
        }
        public override bool CanRightClick()
        {
            return true;
        }

        public override void OpenBossBag(Player player)
        {
            player.TryGettingDevArmor();
            player.TryGettingDevArmor();
            int choice = Main.rand.Next(3);
            if (choice == 0)
            {
                player.QuickSpawnItem(mod.ItemType("Shockwave"));      
            }
            if (choice == 1)
            {
                player.QuickSpawnItem(mod.ItemType("Tesla"));
            }
            if (choice == 2)
            {
                player.QuickSpawnItem(mod.ItemType("CosmoDestroyer"));
            }
            if (Main.rand.Next(10) == 0) //this is the item rarity, so 2 is 1 in 3 chance that the npc will drop the item.
            {
                player.QuickSpawnItem(mod.ItemType("ReaperLegs"));
                player.QuickSpawnItem(mod.ItemType("ReaperHead"));
                player.QuickSpawnItem(mod.ItemType("ReaperWings"));
                player.QuickSpawnItem(mod.ItemType("PleaseRemember"));
                player.QuickSpawnItem(mod.ItemType("ReaperBody"));
                player.QuickSpawnItem(mod.ItemType("ReaperScythe"));
            }
                player.QuickSpawnItem(mod.ItemType("SoulOfCright"), Main.rand.Next(18, 40));
            player.QuickSpawnItem(mod.ItemType("SniperEnergyForce"));
        }
    }
}
