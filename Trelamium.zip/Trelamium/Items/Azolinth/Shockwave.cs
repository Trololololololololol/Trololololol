using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Azolinth
{
    public class Shockwave : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 400;
            item.melee = true;
            item.useTime = 22;
            item.useAnimation = 22;
            item.useStyle = 5;
            item.channel = true;
            item.knockBack = 2f;
            item.value = Terraria.Item.buyPrice(0, 10, 0, 0);
            item.autoReuse = false;
            item.shoot = mod.ProjectileType("ShockwaveProjectile");
            item.noUseGraphic = true;
            item.noMelee = true;
            item.UseSound = SoundID.Item60;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Shockwave");
      Tooltip.SetDefault("");
    }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine line2 in list)
            {
                if (line2.mod == "Terraria" && line2.Name == "ItemName")
                {
                    line2.overrideColor = new Color(155, 0, 78);
                }
            }
        }
    }
}
