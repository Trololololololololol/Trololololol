﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
namespace Trelamium.Items.Azolinth
{
    public class SniperEnergyForce : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 34;
            item.height = 32;

            item.value = Terraria.Item.buyPrice(1, 2, 0, 0);
            item.rare = -12;
            item.accessory = true;
            item.expert = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Sniper Energy Force");
            Tooltip.SetDefault("Increases Ranged damage and critical strike chance by 30%");
        }

        public override void UpdateAccessory(Player player, bool hideVisual)  //this is so when the item is equipped will give this stats to the player
        {
            player.rangedDamage += 0.30f;
            player.rangedCrit += 30;
        }
    }
}