using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Fungor
{
    public class MushyClump : ModItem
	{
        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 24;
            item.maxStack = 20;

            item.rare = 0;
            item.useAnimation = 45;
            item.useTime = 45;
            item.useStyle = 4;
            item.UseSound = SoundID.Item44;
            item.consumable = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Fungal Clump");
      Tooltip.SetDefault("'Summons a golem of shroomtonium...'");
    }

        public override bool CanUseItem(Player player)
        {
            return !NPC.AnyNPCs(mod.NPCType("FungorTheFatherShroom"));
        }

        public override bool UseItem(Player player)
        {
            NPC.SpawnOnPlayer(player.whoAmI, mod.NPCType("FungorTheFatherShroom"));
            Main.PlaySound(SoundID.Roar, player.position, 20);
            return true;
        }
		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Mushroom, 20);
            recipe.AddIngredient(ItemID.Wood, 30);
            recipe.AddIngredient(ItemID.StoneBlock, 18);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
