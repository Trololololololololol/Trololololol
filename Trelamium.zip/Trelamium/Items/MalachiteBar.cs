using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class MalachiteBar : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 96;
            item.height = 36;
            item.value = Terraria.Item.sellPrice(0, 0, 99, 0);
            item.rare = 7;
            item.maxStack = 999;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Malachite Bar");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddRecipeGroup("MythrilBars", 8);
            recipe.AddIngredient(ItemID.ChlorophyteBar, 4);
            recipe.AddIngredient(ItemID.SoulofMight, 4);
            recipe.AddTile(TileID.Autohammer);
            recipe.SetResult(this, 6);
            recipe.AddRecipe();
        }
    }
}
		
