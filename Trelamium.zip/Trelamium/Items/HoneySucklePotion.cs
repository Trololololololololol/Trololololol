using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class HoneySucklePotion : ModItem
    {
        public override void SetDefaults()
        {

            item.UseSound = SoundID.Item3;
            item.useStyle = 2;
            item.useTurn = true;
            item.useAnimation = 17;
            item.useTime = 17;
            item.maxStack = 30;
            item.consumable = true;
            item.width = 20;
            item.height = 28;

            item.value = Terraria.Item.sellPrice(0, 0, 21, 0);           
            item.rare = 0;
            item.buffType = BuffID.Honey;
            item.buffTime = 45100;
            return;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Honeysuckle Potion");
      Tooltip.SetDefault("Increases life regeneration");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Daybloom, 1);
            recipe.AddIngredient(ItemID.Stinger, 1);
            recipe.AddIngredient(ItemID.BottledHoney, 1);
            recipe.AddTile(TileID.Bottles);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
