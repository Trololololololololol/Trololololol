using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class PankHelm : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 26;
            item.height = 18;

            item.value = 10000;
            item.rare = 5;
            item.defense = 6;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Panktonium Headgear");
      Tooltip.SetDefault("8% Increased magic damage.\n8% Increased magic damage.");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("PankChest") && legs.type == mod.ItemType("PankBoots");  //put your Breastplate name and Leggings name
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Increased 13% magic critical strike, regeneration, and damage";
            player.magicDamage += 0.13f;
            player.magicCrit += 13;
            player.manaRegen += 13;
        }
        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.08f;   //20 max mana
        }
        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("PanktoniumBar"), 30);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
