﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class FadedChest : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 24;

            item.value = 21010;
            item.rare = 5;
            item.defense = 5; //51
        }

    public override void SetStaticDefaults()
    {
        DisplayName.SetDefault("Faded Breastplate");
      Tooltip.SetDefault("4% increased critical strike chance!");
    }


        public override void UpdateEquip(Player player)
        {
            player.magicCrit += 4;
            player.rangedCrit += 4;
            player.thrownCrit += 4;
            player.meleeCrit += 4;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("FadedSteel"), 25);
            recipe.AddIngredient(null, ("RedBanner"), 6);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
