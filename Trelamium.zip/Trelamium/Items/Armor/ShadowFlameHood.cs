using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class ShadowFlameHood : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = 10000;
            item.rare = 7;
            item.defense = 10;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Shadowflame Hood");
      Tooltip.SetDefault("10% increased minion knockback\n10% increased minion knockback");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("ShadowFlameChest") && legs.type == mod.ItemType("ShadowFlameBoots");  //put your Breastplate name and Leggings name
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "when under 20% of your Health, your minions do double damage.";
            if (player.statLife <= (player.statLifeMax2 * 0.20f))
            {
                player.minionDamage += 1f;
            }
        }
        public override void UpdateEquip(Player player)
        {
            player.minionKB += 0.10f;
        }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("ShadowFlameEssence"), 12);//you need 1 Wood
            recipe.AddTile(TileID.MythrilAnvil);   //at work bench
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
