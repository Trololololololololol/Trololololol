﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class FadedLegs : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = 11010;
            item.rare = 2;
            item.defense = 4; //51
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Faded Leggings");
      Tooltip.SetDefault("2% increased critical strike chance");
    }


        public override void UpdateEquip(Player player)
        {
            player.magicCrit += 2;
            player.rangedCrit += 2;
            player.thrownCrit += 2;
            player.meleeCrit += 2;

        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("FadedSteel"), 19);
            recipe.AddIngredient(null, ("RedBanner"), 6);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
