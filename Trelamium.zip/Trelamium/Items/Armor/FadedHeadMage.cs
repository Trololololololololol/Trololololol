﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class FadedHeadMage : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = 10000;
            item.defense = 1; //15
            item.rare = 3;
        }

    public override void SetStaticDefaults()
    {
        DisplayName.SetDefault("Faded Worlock Helmet");
      Tooltip.SetDefault("+ 30 mana");
    }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("FadedChest") && legs.type == mod.ItemType("FadedLegs");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Increases magic damage and max mana!";
            player.magicDamage += 0.05f;
            player.statManaMax2 += 30;
        }

        public override void UpdateEquip(Player player)
        {
            player.statManaMax2 += 30;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("FadedSteel"), 19);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
