﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class PrimeFuryLegs : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = 11010;
            item.rare = 8;
            item.defense = 7; //51
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Prime Fury Leggings");
      Tooltip.SetDefault("7% increased melee critical strike chance\n increases movement speed");
    }


        public override void UpdateEquip(Player player)
        {
            player.meleeCrit += 7;
            player.moveSpeed += 0.3f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "PrimeSteel", 15);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
