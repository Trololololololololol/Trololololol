using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class AncientHelm : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 28;
            item.height = 18;

            item.value = 1000;
            item.rare = 3;
            item.defense = 3;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ancient Helmet");
      Tooltip.SetDefault("4% Increased Thrown Critical Strike Chance.");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("AncientChest") && legs.type == mod.ItemType("AncientLegs");  //put your Breastplate name and Leggings name
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Ancient Powers grant you faster health regeneration."; // the armor set bonus
            player.lifeRegen += 6;


        }
        public override void UpdateEquip(Player player)
        {
            player.thrownCrit += 4;
        }
        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Sandstone, 75);
            recipe.AddIngredient(ItemID.HardenedSand, 50); //you need 1 Wood
            recipe.AddTile(TileID.Furnaces);   //at work bench
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
