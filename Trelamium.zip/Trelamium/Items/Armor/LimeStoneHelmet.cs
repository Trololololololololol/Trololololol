using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class LimeStoneHelmet : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 20;
            item.height = 30;



            item.value = 10000;
            item.rare = 8;
            item.defense = 17;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Lime Stone Helmet");
      Tooltip.SetDefault("+5% Increased Melee Damage!.\n+15% Increased Melee Speed!.\nGrants Immunity to cursed Inferno!.");
    }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("BreastplateName") && legs.type == mod.ItemType("LimeStoneLegs");  //put your Breastplate name and Leggings name
        }
        public override void UpdateEquip(Player player)
        {
            player.buffImmune[BuffID.CursedInferno] = true;
            player.meleeDamage += 0.10f; //(thats 10% icreased dMage)
            player.meleeSpeed += 0.15f; //(thats 10% icreased dMage)
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("TechnoliteBar"), 27);
            recipe.AddIngredient(null, ("GeraniumElement"), 8);
            recipe.AddIngredient(ItemID.SoulofNight, 10);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
