﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    public class CristaliteLegs : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = 511010;
            item.rare = 9;
            item.defense = 12; //51
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Cristalite Leggings");
      Tooltip.SetDefault("20% increased magic critical strike chance\n+ one max minion\nIncreases minion damage by 10%");
    }


        public override void UpdateEquip(Player player)
        {
            player.magicCrit += 20;
            player.maxMinions++;
            player.minionDamage += 0.1f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Crystal", 28);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
