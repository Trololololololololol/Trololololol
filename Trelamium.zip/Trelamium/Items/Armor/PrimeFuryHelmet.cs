﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class PrimeFuryHelmet : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 26;
            item.height = 24;

            item.value = 10000;
            item.defense = 9; //15
            item.rare = 8;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Prime Fury Battle Helmet");
      Tooltip.SetDefault("10% increased melee damage and critical strike chance!");
    }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("PrimeFuryChest") && legs.type == mod.ItemType("PrimeFuryLegs");
        }

        public override void ArmorSetShadows(Player player)
        {
            player.armorEffectDrawShadow = true;
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Increased critical strike chance and melee damage!";

            player.meleeDamage += 0.10f;
            player.meleeCrit += 20;
        }

        public override void UpdateEquip(Player player)
        {
            player.meleeDamage += 0.10f;
            player.meleeCrit += 10;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "PrimeSteel", 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
