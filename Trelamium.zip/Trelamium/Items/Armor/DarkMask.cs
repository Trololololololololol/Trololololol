using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class DarkMask : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;
            item.value = Terraria.Item.buyPrice(0, 3, 0, 0);
            item.rare = 2;
            item.defense = 22;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dark Mask");
      Tooltip.SetDefault("");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("DarkPlate") && legs.type == mod.ItemType("DarkGreaves");  //put your Breastplate name and Leggings name
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Dark Power";
            player.AddBuff(BuffID.Wrath, 2);
            player.AddBuff(BuffID.Rage, 2);

        }
        public override void ArmorSetShadows(Player player)
        {
            player.armorEffectDrawShadow = true;
            player.armorEffectDrawOutlines = true;
        }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("DarkBar"), 14);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
