using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class AzureMask : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 32;
            item.height = 20;

            item.value = Terraria.Item.sellPrice(0, 4, 0, 0);
            item.rare = 6;
            item.defense = 12;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Azure Headgear");
      Tooltip.SetDefault("Allows the player to move freely through liqiuds\nAllows the player to move freely through liqiuds");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("AzurePlate") && legs.type == mod.ItemType("AzureBoots");
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "You are guided by the spirit of Azure";
        }
        public override void UpdateEquip(Player player)
        {
            player.lavaImmune = true;
            player.ignoreWater = true;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("AzureElement"), 8);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
