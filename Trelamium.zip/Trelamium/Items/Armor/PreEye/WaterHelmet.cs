﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor.PreEye
{
    [AutoloadEquip(EquipType.Head)]
    public class WaterHelmet : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = 10000;
            item.defense = 4; //15
            item.rare = 2;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Azurite Helmet");
            Tooltip.SetDefault("5% increased melee damage.\nInscreases melee critical strike chance by 2%");
        }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("WaterChest") && legs.type == mod.ItemType("WaterLegs");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Increases melee critical strike chance and max life!";
            player.meleeCrit += 5;
            player.statLifeMax2 += 20;
        }

        public override void UpdateEquip(Player player)
        {
            player.meleeDamage += 0.05f;
            player.meleeCrit += 2;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Agate", 19);
            recipe.AddIngredient(null, "Geode", 3);
            recipe.AddIngredient(ItemID.FallenStar, 1);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
