﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor.PreEye
{
    [AutoloadEquip(EquipType.Body)]
    public class FusedMetalChest : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 18;

            item.value = 11010;
            item.rare = 3;
            item.defense = 5; //51
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Reinforced Metal Chainplate");
            Tooltip.SetDefault("5% increased critical strike chance!\n'Heavy'");
        }


        public override void UpdateEquip(Player player)
        {
            player.magicCrit += 5;
            player.thrownCrit += 5;
            player.meleeCrit += 5;
            player.rangedCrit += 5;
            player.moveSpeed -= 0.03f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "FusedMetal", 15);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
