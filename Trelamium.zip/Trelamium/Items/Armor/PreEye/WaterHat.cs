﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor.PreEye
{
    [AutoloadEquip(EquipType.Head)]
    public class WaterHat : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = 10000;
            item.defense = 2; //15
            item.rare = 3;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Azurite Hat");
      Tooltip.SetDefault("3% increased magic damage.\nMagic critical strikes appear 2% more often!");
    }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("WaterChest") && legs.type == mod.ItemType("WaterLegs");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Increases life regeneration!";
            player.lifeRegen = +3;

        }

        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.03f;
            player.magicCrit += 2;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Agate", 17);
            recipe.AddIngredient(null, "Geode", 3);
            recipe.AddIngredient(ItemID.FallenStar, 1);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
