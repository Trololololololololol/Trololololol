﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor.PreEye
{
    [AutoloadEquip(EquipType.Head)]
    public class FusedMetalHeadgear : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = 10000;
            item.defense = 2; //15
            item.rare = 3;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Reinforced Metal Headgear");
            Tooltip.SetDefault("Increases ranged damage by 5%");
        }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("FusedMetalChest") && legs.type == mod.ItemType("FusedMetalLegs");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "You have 25% chance not to consume ammo, increases ranged damage slightly";
            player.ammoCost75 = true;
        }

        public override void UpdateEquip(Player player)
        {
            player.rangedDamage += 0.05f;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "FusedMetal", 16);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
