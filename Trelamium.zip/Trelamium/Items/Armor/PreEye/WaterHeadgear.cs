﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor.PreEye
{
    [AutoloadEquip(EquipType.Head)]
    public class WaterHeadgear : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = 10000;
            item.defense = 2; //15
            item.rare = 2;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Azurite Headgear");
            Tooltip.SetDefault("Increases ranged damage by 3%");
        }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("WaterChest") && legs.type == mod.ItemType("WaterLegs");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "When under 25% health, you gain a 10% ranged damage buff";
            if (player.statLife <= (player.statLifeMax2 * 0.25f))
            {
                player.rangedDamage += 0.1f;
            }
        }

        public override void UpdateEquip(Player player)
        {
            player.rangedDamage += 0.03f;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Agate", 19);
            recipe.AddIngredient(null, "Geode", 3);
            recipe.AddIngredient(ItemID.FallenStar, 1);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
