﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor.PreEye
{
    [AutoloadEquip(EquipType.Head)]
    public class FusedMetalHat : ModItem
    {


        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = 10000;
            item.defense = 1; //15
            item.rare = 2;
            item.scale = 1f;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Reinforced Metal Hat");
            Tooltip.SetDefault("3% increased summon damage.");
        }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("FusedMetalChest") && legs.type == mod.ItemType("FusedMetalLegs");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Increases minion damage and max minions!";
            player.maxMinions++;
            player.minionDamage += 0.07f;
        }

        public override void UpdateEquip(Player player)
        {
            player.minionDamage += 0.03f;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "FusedMetal", 16);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
