﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor.PreEye
{
    [AutoloadEquip(EquipType.Legs)]
    public class FusedMetalLegs : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = 11010;
            item.rare = 2;
            item.defense = 4; //51
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Reinforced Metal Leggings");
            Tooltip.SetDefault("4% increased critical strike chance");
        }


        public override void UpdateEquip(Player player)
        {
            player.magicCrit += 4;
            player.thrownCrit += 4;
            player.meleeCrit += 4;
            player.rangedCrit += 4;

        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "FusedMetal", 16);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
