using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class BreakerHelm : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;
            item.value = Terraria.Item.buyPrice(0, 3, 0, 0);
            item.rare = 5;
            item.defense = 12;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Breaker Helmet");
      Tooltip.SetDefault("");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("BreakerChest") && legs.type == mod.ItemType("BreakerBoots");
        }
        public override void UpdateArmorSet(Player player)
        {
            MyPlayer modPlayer = player.GetModPlayer<MyPlayer>(mod);
            modPlayer.breakerBuff = true;
            player.setBonus = "Melee weapons lower enemy defesne by 75%";

        }
        public override void ArmorSetShadows(Player player)
        {
            player.armorEffectDrawShadow = true;
            player.armorEffectDrawOutlines = true;
        }
    }
}
