using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class RedHotBoots : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;


            item.value = 10;
            item.rare = 4;
            item.defense = 14;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Red Hot Leggings");
      Tooltip.SetDefault("Scorching the touch.\nGrants immunity to lava");
    }


        public override void UpdateEquip(Player player)
        {
            player.lavaImmune = true;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("RedHotBar"), 22);
            recipe.AddIngredient(null, ("RedHotCore"), 12);
            recipe.AddTile(TileID.Hellforge);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
