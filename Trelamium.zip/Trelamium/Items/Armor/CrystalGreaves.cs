﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
public class CrystalGreaves : ModItem
{

    public override void SetDefaults()
    {

        item.width = 18;
        item.height = 18;


        item.value = Terraria.Item.sellPrice(0, 1, 0, 0);
        item.rare = 6;
        item.defense = 12; //62
    }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Crystal Cuisses");
      Tooltip.SetDefault("10% increased magic critical strike chance.\n'Shimmering with pure light.'");
    }


    public override void UpdateEquip(Player player)
    {
    	player.magicCrit += 10;
    }

    public override void AddRecipes()
    {
        ModRecipe recipe = new ModRecipe(mod);
        recipe.AddIngredient(ItemID.CrystalShard, 22);
        recipe.AddIngredient(ItemID.SoulofLight, 8);
        recipe.AddTile(TileID.MythrilAnvil);
        recipe.SetResult(this);
        recipe.AddRecipe();
    }
}}
