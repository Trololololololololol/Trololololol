﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class CristaliteChest : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 28;

            item.value = 611010;
            item.rare = 9;
            item.defense = 26; //51
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Cristalite Chestplate");
      Tooltip.SetDefault("6% increased magic damage\nIncreases max mana\nIncreases minion damage by 12%\n+ 3 Max minions");
    }


        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.06f;
            player.statManaMax2 += 60;
            player.maxMinions++;
            player.maxMinions++;
            player.maxMinions++;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Crystal", 31);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
