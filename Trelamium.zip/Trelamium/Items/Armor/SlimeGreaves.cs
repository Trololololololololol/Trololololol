using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class SlimeGreaves : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;


            item.value = Terraria.Item.sellPrice(0, 0, 0, 10);
            item.defense = 1;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Slimey Greaves");
      Tooltip.SetDefault("I Bet you can bounce!\nOh wait, nope.");
    }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.WoodGreaves);
            recipe.AddIngredient(ItemID.Gel, 25);
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
