﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class XarfaliliumChest : ModItem
    {


        public override void SetDefaults()
        {

            item.width = 34;
            item.height = 24;


            item.value = Terraria.Item.sellPrice(0, 3, 0, 0);
            item.rare = 7;
            item.defense = 20;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Xarfalilium Robe");
      Tooltip.SetDefault("Darkness slowy consumes you...\n17% Increased ranged Damage, when under 70% of health, you become invisible when staying still");
    }


        public override void UpdateEquip(Player player)
        {
            player.rangedDamage += 0.17f;
            if (player.statLife <= (player.statLifeMax2 * 0.70f))
            {
                player.shroomiteStealth = true;
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("XarfaliliumBar"), 23);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
