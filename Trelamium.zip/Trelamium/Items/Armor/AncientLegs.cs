using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class AncientLegs : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = 10;
            item.rare = 3;
            item.defense = 4;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ancient Greaves");
      Tooltip.SetDefault("8% Increased Thrown Velocity\n8% Increased Thrown Velocity");
    }


        public override void UpdateEquip(Player player)
        {
            player.thrownVelocity += 0.08f;
        }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Sandstone, 50);
            recipe.AddIngredient(ItemID.HardenedSand, 25); //you need 10 Wood
            recipe.AddTile(TileID.Furnaces);   //at work bench
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
