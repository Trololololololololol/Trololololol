using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class EnchantedHelm : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 26;
            item.height = 24;

            item.value = Terraria.Item.buyPrice(0, 0, 10, 0);
            item.rare = 1;
            item.defense = 3;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Enchanted Headgear");
      Tooltip.SetDefault("Increases magic damage by 6%\nIncreases magic damage by 6%");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("EnchantedChest") && legs.type == mod.ItemType("EnchantedBoots");
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "When below 25% of your health you get a mana boost in mana";
            if (player.statLife <= (player.statLifeMax2 * 0.25f))
            {
                player.statManaMax2 += 60;
            }

        }

        public override void ArmorSetShadows(Player player)
        {
            player.armorEffectDrawShadow = true;
            player.armorEffectDrawOutlines = true;
        }

        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.06f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("EnchantcianPrism"), 8);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
