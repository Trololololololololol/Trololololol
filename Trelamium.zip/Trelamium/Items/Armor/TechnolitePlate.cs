﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class TechnolitePlate : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;


            item.value = Terraria.Item.sellPrice(0, 0, 60, 0);   
            item.rare = 8;
            item.defense = 30;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Technolite Breastplate");
      Tooltip.SetDefault("You are filled with energy\n10% increased melee speed, and damage");
    }

        public override void UpdateEquip(Player player)
        {
            player.meleeSpeed += 0.1f;
            player.meleeDamage += 0.1f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("TechnoliteBar"), 20);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
