using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class BreastplateName : ModItem
    {


        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 20;

            item.value = 10;
            item.rare = 8;
            item.defense = 15;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Limestone Chestplate");
      Tooltip.SetDefault("12% increased Damage");
    }


        public override void UpdateEquip(Player player)
        {
            player.meleeDamage += 0.12f;
            player.rangedDamage += 0.12f;
            player.magicDamage += 0.12f;
            player.minionDamage += 0.12f;
            player.rocketDamage += 0.12f;
            player.thrownDamage += 0.12f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("TechnoliteBar"), 18);
            recipe.AddIngredient(null, ("GeraniumElement"), 8);
            recipe.AddIngredient(ItemID.SoulofNight, 5);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
