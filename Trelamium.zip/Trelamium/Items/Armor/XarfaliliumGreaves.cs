using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class XarfaliliumGreaves : ModItem
    {


        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;


            item.value = Terraria.Item.sellPrice(0, 1, 0, 0);
            item.rare = 8;
            item.defense = 12;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Xarfalilium Cuisses");
      Tooltip.SetDefault("You have a 20% not to consume ammo\nDarkness slowy consumes you...");
    }


        public override void UpdateEquip(Player player)
        {
            player.ammoCost80 = true;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("XarfaliliumBar"), 12);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
