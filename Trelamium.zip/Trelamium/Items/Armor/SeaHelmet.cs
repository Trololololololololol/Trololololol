using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
	public class SeaHelmet : ModItem
	{
		public override void SetDefaults()
		{

			item.width = 18;
			item.height = 20;

			item.value = 10000;
			item.rare = 2;
			item.defense = 4;
		}

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Sea Helmet");
      Tooltip.SetDefault("'From the depths of the sea'.");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
		{
			return body.type == mod.ItemType("SeaChestplate") && legs.type == mod.ItemType("SeaPants");
		}
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "10% minion damage increase";
            player.minionDamage += 0.10f;
        }
		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(null, "SeaEssence", 10);
            recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
