using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class FrozebloodHeadgear : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 28;

            item.value = Terraria.Item.sellPrice(0, 0, 23, 0);
            item.rare = 7;
            item.defense = 15;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Frostblood Mask");
      Tooltip.SetDefault("22% increased melee damage\n22% increased melee damage");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("FrozebloodGearplate") && legs.type == mod.ItemType("FrozebloodBoots");
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "29% increased melee damage, critical strike and speed.";
            player.meleeDamage += 0.29f;
            player.meleeSpeed += 0.29f;
            player.meleeCrit += 29;
        }
        public override void UpdateEquip(Player player)
        {
            player.meleeDamage += 0.22f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("FrozebloodBar"), 27);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
