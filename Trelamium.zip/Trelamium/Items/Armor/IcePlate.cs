﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class IcePlate : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 18;

            item.value = Terraria.Item.sellPrice(0, 5, 0, 0);
            item.rare = 9;
            item.defense = 26;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Everfrost Platemail");
      Tooltip.SetDefault("Increases max minions by 3");
    }

        public override void UpdateEquip(Player player)
        {
            player.maxMinions += 3;
        }
    }
}
