using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class XarfaliliumHelm : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 22;


            item.value = 10000;
            item.rare = 4;
            item.defense = 6;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Xarfalilium Gildgear");
      Tooltip.SetDefault("Darkness slowy consumes you...\n8% Increased Ranged critical strike chance.");
    }


        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType("XarfaliliumChest") && legs.type == mod.ItemType("XarfaliliumGreaves");
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "When you are damaged, you have a chance to gain a buff called: Warlord\nWarlord grants a 5 second invincibility, 15% damage increase and 30% increased movement speed";
            if (player.immune)
            {
                if (Main.rand.Next(80) == 0)
                {
                    player.AddBuff(mod.BuffType("WarlordBuff"), 1000);
                }
            }
        }
        public override void UpdateEquip(Player player)
        {
            player.rangedCrit += 8;
        }
        public override void ArmorSetShadows(Player player)
        {
            player.armorEffectDrawShadow = true;
            player.armorEffectDrawOutlines = true;
        }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("XarfaliliumBar"), 18);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
