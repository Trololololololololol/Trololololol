using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class RedHotHelm : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;


            item.value = 10000;
            item.rare = 4;
            item.defense = 22;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Red Hot Helmet");
      Tooltip.SetDefault("Scorching to the touch.\n16% Increased melee critical strike chance.");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("RedHotChest") && legs.type == mod.ItemType("RedHotLeggings");  //put your Breastplate name and Leggings name
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "A barrier of flames will ignite your enemies.";
            player.AddBuff(BuffID.Inferno, 2);
            player.meleeCrit += 16;
        }
        public override void ArmorSetShadows(Player player)
        {
            player.armorEffectDrawShadow = true;
            player.armorEffectDrawOutlines = true;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("RedHotBar"), 30);
            recipe.AddIngredient(null, ("RedHotCore"), 8);
            recipe.AddTile(TileID.Hellforge);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
