using System.Collections.Generic;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
	public class GlacierMask : ModItem
	{
		public override void SetDefaults()
		{

			item.width = 28;
			item.height = 22;
			item.rare = 1;
			item.vanity = true;
		}

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Glacier Mask");
      Tooltip.SetDefault("");
    }


		public override bool DrawHead()
		{
			return false;
		}
	}
}
