using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class MalachiteMask : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 22;

            item.value = Terraria.Item.sellPrice(0, 6, 0, 0);
            item.rare = 9;
            item.defense = 10;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Malachite Mask");
      Tooltip.SetDefault("16% Increased minion Damage.\n16% Increased minion Damage.");
    }


        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType("MalachiteChest") && legs.type == mod.ItemType("MalachiteBoots");
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Minions can inflict multiple buffs depending on your maximum health\nAt 75% your maximum health, minions inflict 'On Fire'\nAt 50% of your maximum health, minions inflict 'Shadowflame'\nAt 25% of your maximum health, minions inflict 'Ichor'";
            if (player.statLife <= (player.statLifeMax2 * 0.75f))
            {
                player.AddBuff(mod.BuffType("Malachite1"), 2);
            }
            if (player.statLife <= (player.statLifeMax2 * 0.5f))
            {
                player.AddBuff(mod.BuffType("Malachite1"), 2);
            }
            if (player.statLife <= (player.statLifeMax2 * 0.25f))
            {
                player.AddBuff(mod.BuffType("Malachite3"), 2);
            }
        }
        public override void UpdateEquip(Player player)
        {
            player.minionDamage += 0.16f;
        }
        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("MalachiteBar"), 13);
            recipe.AddTile(TileID.Autohammer);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
