﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class DarkPlate : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = Terraria.Item.buyPrice(0, 4, 0, 0);
            item.rare = 2;
            item.defense = 28;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dark Platemail");
      Tooltip.SetDefault("Maximum Heath Increased by 100\nMaximum Heath Increased by 100");
    }


        public override void UpdateEquip(Player player)
        {
            player.statLifeMax2 += 100;
        }
        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("DarkBar"), 18);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
