using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class SlimeHelm : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 16;

            item.value = Terraria.Item.sellPrice(0, 0, 0, 18);
            item.defense = 1;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Slimey Helmet");
      Tooltip.SetDefault("Your hair is sticky");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("SlimeChest") && legs.type == mod.ItemType("SlimeGreaves");  //put your Breastplate name and Leggings name
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "slimes are friendly";
            player.npcTypeNoAggro[NPCID.BlueSlime] = true;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.WoodHelmet);
            recipe.AddIngredient(ItemID.Gel, 30);
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
