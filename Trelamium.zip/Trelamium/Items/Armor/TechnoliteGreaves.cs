using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class TechnoliteGreaves : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;


            item.value = Terraria.Item.sellPrice(0, 6, 0, 0);
            item.rare = 8;
            item.defense = 12;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Technolite Greaves");
      Tooltip.SetDefault("You are filled with energy\n13% increased melee speed");
    }


        public override void UpdateEquip(Player player)
        {
            player.meleeSpeed += 0.13f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("TechnoliteBar"), 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
