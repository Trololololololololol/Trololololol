﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class MalachiteChest : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 18;

            item.value = Terraria.Item.sellPrice(0, 6, 0, 0);
            item.rare = 9;
            item.defense = 8;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Malachite Platemail");
      Tooltip.SetDefault("7% Increased minion knockback.\n7% Increased minion knockback.");
    }


        public override void UpdateEquip(Player player)
        {
            player.minionKB += 7;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("MalachiteBar"), 21);
            recipe.AddTile(TileID.Autohammer);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
