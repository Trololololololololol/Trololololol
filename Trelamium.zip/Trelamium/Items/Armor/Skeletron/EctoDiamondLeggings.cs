﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor.Skeletron
{
    [AutoloadEquip(EquipType.Legs)]
    public class EctoDiamondLeggings : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = 11010;
            item.rare = 4;
            item.defense = 6; //51
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ecto Diamond Leggings");
      Tooltip.SetDefault("5% increased melee critical strike chance\ngreatly increases movement speed");
    }


        public override void UpdateEquip(Player player)
        {
            player.meleeCrit += 5;
            player.moveSpeed += 0.2f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "StrangeCrystal", 30);
            recipe.AddIngredient(null, "SoundPrism", 25);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
