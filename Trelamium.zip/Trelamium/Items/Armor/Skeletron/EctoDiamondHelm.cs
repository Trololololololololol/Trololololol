﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor.Skeletron
{
    [AutoloadEquip(EquipType.Head)]
    public class EctoDiamondHelm : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 26;
            item.height = 24;

            item.value = 10000;
            item.defense = 5; //15
            item.rare = 4;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ecto Diamond Helm");
      Tooltip.SetDefault("5% increased melee and critical damage!");
    }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("EctoDiamondChest") && legs.type == mod.ItemType("EctoDiamondLeggings");
        }

        public override void ArmorSetShadows(Player player)
        {
            player.armorEffectDrawShadow = true;
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = " Your heavy armor grants you 10 defense!";
            player.statDefense++;
            player.statDefense++;
            player.statDefense++;
            player.statDefense++;
            player.statDefense++;
            player.statDefense++;
            player.statDefense++;
            player.statDefense++;
            player.statDefense++;
            player.statDefense++;
        }

        public override void UpdateEquip(Player player)
        {
            player.meleeDamage += 0.05f;
            player.meleeCrit += 5;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "StrangeCrystal", 31);
            recipe.AddIngredient(null, "SoundPrism", 25);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
