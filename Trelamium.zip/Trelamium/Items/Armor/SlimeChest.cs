﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class SlimeChest : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 20;

            item.value = Terraria.Item.sellPrice(0, 0, 0, 25);   
            item.defense = 1;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Slimey Chestplate");
      Tooltip.SetDefault("Master of disguise");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.WoodBreastplate);
            recipe.AddIngredient(ItemID.Gel, 40);
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
