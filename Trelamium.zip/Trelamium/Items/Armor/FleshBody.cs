using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
public class FleshBody : ModItem
{

    public override void SetDefaults()
    {

        item.width = 18;
        item.height = 18;

        item.value = 40000;
        item.rare = 7;
        item.defense = 14; //42
    }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Flesh Armor");
      Tooltip.SetDefault("increases throwing damage by 8% and throwing critical strike chance by 5%");
    }


    public override void UpdateEquip(Player player)
    {
        
        player.thrownDamage += 0.08f;
        player.thrownCrit += 5;
    }
         public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "PieceOfFlesh", 18);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
