﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class StarfallChest : ModItem
    {


        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 18;


            item.value = Item.sellPrice(0, 0, 65, 0);
            item.rare = 2;
            item.defense = 10;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Starfall Chestplate");
      Tooltip.SetDefault("Crafted from the Rage of the fallen Angels.\nMaximum Mana Increased by 30.");
    }


        public override void UpdateEquip(Player player)
        {
            player.statManaMax2 += 30;   //20 max mana
        }
        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("StarfallBar"), 22);
            recipe.AddTile(TileID.SkyMill);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
