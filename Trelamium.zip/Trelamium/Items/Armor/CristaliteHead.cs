﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;


namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class CristaliteHead : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = 550000;
            item.rare = 9;
            item.defense = 9; //15
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Cristalite Helm");
      Tooltip.SetDefault("Increases magic damage by 10%\nIncreases max minions by 2");
    }


        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType("CristaliteChest") && legs.type == mod.ItemType("CristaliteLegs");
        }

        public override void ArmorSetShadows(Player player)
        {
            player.armorEffectDrawShadow = true;
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Increases defense and magic damage as health decreases";
            if (player.statLife <= (player.statLifeMax2 * 0.75f))
            {
                player.magicDamage += 0.1f;
                if (player.statLife <= (player.statLifeMax2 * 0.5f))
                {
                    player.magicDamage += 0.2f;
                    player.minionDamage += 0.2f;
                    player.statDefense++;
                    player.statDefense++;
                    player.statDefense++;
                    player.statDefense++;
                    player.statDefense++;
                    if (player.statLife <= (player.statLifeMax2 * 0.2f))
                    {
                        player.minionDamage += 0.3f;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                        player.statDefense++;
                    }
                }
            }
        }

        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.1f;
            player.maxMinions++;
            player.maxMinions++;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Crystal", 26);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
