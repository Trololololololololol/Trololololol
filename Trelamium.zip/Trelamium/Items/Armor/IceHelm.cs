using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class IceHelm : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 22;
            item.value = 0;

            item.rare = 7;
            item.expert = true;
            item.defense = 17;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Everfrost Headgear");
      Tooltip.SetDefault("Increases max health by 100");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("IcePlate") && legs.type == mod.ItemType("IceGreaves");  //put your Breastplate name and Leggings name
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "When at  30% of your health you start to heal, and grants immunity to all cold effects"; // the armor set bonus
            player.buffImmune[BuffID.Frostburn] = true;
            player.buffImmune[BuffID.Frozen] = true;
            player.buffImmune[BuffID.Chilled] = true;
            if (player.statLife <= (player.statLifeMax2 * 0.30f))
            {
                player.ghostHeal = true;
            }

        }
        public override void UpdateEquip(Player player)
        {
            player.statLifeMax2 += 100;
        }
    }
}
