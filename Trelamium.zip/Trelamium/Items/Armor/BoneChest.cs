﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class BoneChest : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 24;

            item.value = 21010;
            item.rare = 3;
            item.defense = 6; //51
        }

    public override void SetStaticDefaults()
    {
        DisplayName.SetDefault("Dreaded Breastplate");
      Tooltip.SetDefault("Increases max mana and minions\n+ 6% Minion damage");
    }


        public override void UpdateEquip(Player player)
        {
            player.statManaMax2 += 25;
            player.minionDamage += 0.06f;
            player.maxMinions++;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Lens", 4);
            recipe.AddIngredient(null, "Teeth", 10);
            recipe.AddIngredient(null, "RippedRug", 21);
            recipe.AddTile(null, ("CryingBloodAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
