using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class FleshHelm : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 28;
            item.height = 30;

            item.value = 50000;
            item.rare = 6;
            item.defense = 13; //42
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Flesh Helmet");
      Tooltip.SetDefault("10% increased thrown damage and 10% thrown critical strike chance!");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("FleshBody") && legs.type == mod.ItemType("FleshLegs");
        }

        public override void ArmorSetShadows(Player player)
        {
            player.armorEffectDrawOutlines = true;
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Thrown Damage increased by 30% when below 50% of your maximum life!";

            if (player.statLife <= (player.statLifeMax2 * 0.50f))
            {
                player.thrownDamage += 0.30f;
            }
        }

        public override void UpdateEquip(Player player)
        {
            player.thrownDamage += 0.10f;
            player.thrownCrit += 10;
        }
        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "PieceOfFlesh", 14);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
