using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class TechnoliteHelm : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;


            item.value = Terraria.Item.sellPrice(0, 5, 0, 0);
            item.rare = 8;
            item.defense = 17;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Technolite VR");
      Tooltip.SetDefault("You are filled with energy\n18% Increased melee damage");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("TechnolitePlate") && legs.type == mod.ItemType("TechnoliteGreaves");
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "When under 45% of your health, Melee speed, and damage is increased by 25%";
            player.magicDamage += 0.12f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("TechnoliteBar"), 17);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
