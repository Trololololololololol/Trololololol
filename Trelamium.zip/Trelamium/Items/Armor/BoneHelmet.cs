﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class BoneHelmet : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = 10000;
            item.defense = 3; //15
            item.rare = 3;
            item.scale = 1.5f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dreaded Helmet");
      Tooltip.SetDefault("Increases minion and magic damage by 6%");
    }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("BoneChest") && legs.type == mod.ItemType("BoneLeggings");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Increases max minions, max mana, and damage";
            player.maxMinions++;
            player.statManaMax2 += 40;
            player.magicDamage += 0.07f;
            player.minionDamage += 0.07f;
        }

        public override void UpdateEquip(Player player)
        {
            player.minionDamage += 0.06f;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Lens", 5);
            recipe.AddIngredient(null, "Teeth", 8);
            recipe.AddIngredient(null, "RippedRug", 16);
            recipe.AddTile(null, ("CryingBloodAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
