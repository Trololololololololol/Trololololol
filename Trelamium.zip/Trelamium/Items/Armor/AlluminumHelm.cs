using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class AlluminumHelm : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 22;

            item.value = Terraria.Item.sellPrice(0, 0, 30, 0);
            item.rare = 1;
            item.defense = 5;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aluminum Visor");
      Tooltip.SetDefault("7% Increased Ranged Damage.");
    }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("AlluminumChest") && legs.type == mod.ItemType("AlluminumBoots");
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Movement speed is increased Greatly";
            player.moveSpeed = 3f;
        }
        public override void UpdateEquip(Player player)
        {
            player.rangedDamage += 0.07f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("AlluminumBar"), 8);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
