using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class FleshLegs : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = 12500;
            item.rare = 7;
            item.defense = 12; //42
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Flesh War Shoes");
      Tooltip.SetDefault("8% increased thrown critical strike chance!");
    }


        public override void UpdateEquip(Player player)
        {
            player.thrownCrit += 5;
            player.moveSpeed += 0.12f;
        }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "PieceOfFlesh", 12);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
