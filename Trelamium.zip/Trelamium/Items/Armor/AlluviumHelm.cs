using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium;
using Trelamium.Items;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class AlluviumHelm : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;


            item.value = 10000;
            item.rare = 3;
            item.defense = 8;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Alluvium Hood");
      Tooltip.SetDefault("It's Literally made from the dirt\n12% Increased Magic damage");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("AlluviumChest") && legs.type == mod.ItemType("AlluviumBoots");
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "You are now One with Nature.";
            player.AddBuff(BuffID.DryadsWard, 2);
        }
        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.12f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("AlluviumBar"), 22);
            recipe.AddTile(TileID.LivingLoom);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
