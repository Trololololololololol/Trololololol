﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class GeraniumChainmail : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 34;
            item.height = 22;

            item.value = Terraria.Item.sellPrice(0, 8, 0, 0);
            item.rare = 6;
            item.defense = 12;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Geranium Chainmail");
      Tooltip.SetDefault("11% increased minion damage");
    }


        public override void UpdateEquip(Player player)
        {
            player.minionDamage += 0.11f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("GeraniumElement"), 12);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
