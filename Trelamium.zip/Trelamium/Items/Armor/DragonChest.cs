﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class DragonChest : ModItem
    {


        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 20;

            item.value = Terraria.Item.buyPrice(0, 0, 50, 0);
            item.rare = 8;
            item.defense = 18;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dragon Platemail");
      Tooltip.SetDefault("Inreases your melee critical strike chance by 12%");
    }


        public override void UpdateEquip(Player player)
        {
            player.meleeCrit += 12;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("DB"), 24);
            recipe.AddTile(TileID.AdamantiteForge);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
