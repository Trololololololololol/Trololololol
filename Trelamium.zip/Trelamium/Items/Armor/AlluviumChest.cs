﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class AlluviumChest : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;


            item.value = Terraria.Item.sellPrice(0, 0, 60, 0);   
            item.rare = 2;
            item.defense = 6;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Alluvium Breastplate");
      Tooltip.SetDefault("It's literally made from the dirt\nMaximum health Increased by 30");
    }


        public override void UpdateEquip(Player player)
        {
            player.statLifeMax2 += 30;
        }
        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("AlluviumBar"), 21);
            recipe.AddTile(TileID.LivingLoom);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
