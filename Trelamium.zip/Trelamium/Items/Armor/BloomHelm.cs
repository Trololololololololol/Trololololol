using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class BloomHelm : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = 10000;
            item.rare = 3;
            item.defense = 8;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Bloom Headgear");
      Tooltip.SetDefault("Maximum minions increased by 3\nMaximum minions increased by 3");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("BloomPlate") && legs.type == mod.ItemType("BloomBoots");
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Flower petals will randomly attack enemies";
        }
        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.22f;
            player.minionDamage += 0.22f;
            player.maxMinions += 3;
            if (player.immune)
            {
                if (Main.rand.Next(6) == 0)
                {
                    for (int l = 0; l < 1; l++)
                    {
                        float x = player.position.X + (float)Main.rand.Next(-400, 400);
                        float y = player.position.Y - (float)Main.rand.Next(500, 800);
                        Vector2 vector = new Vector2(x, y);
                        float num15 = player.position.X + (float)(player.width / 2) - vector.X;
                        float num16 = player.position.Y + (float)(player.height / 2) - vector.Y;
                        num15 += (float)Main.rand.Next(-100, 101);
                        int num17 = 35;
                        float num18 = (float)Math.Sqrt((double)(num15 * num15 + num16 * num16));
                        num18 = (float)num17 / num18;
                        num15 *= num18;
                        num16 *= num18;
                        int num19 = Projectile.NewProjectile(x, y, num15, num16, ProjectileID.FlowerPetal, 30, 5f, player.whoAmI, 0f, 0f);
                        Main.projectile[num19].ai[1] = player.position.Y;
                    }
                }
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("PlanteraSkin"), 18);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
