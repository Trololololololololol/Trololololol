using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class LimeStoneLegs : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 20;
            item.height = 30;


            item.value = 10000;
            item.rare = 8;
            item.defense = 22;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Lime Stone Boots");
      Tooltip.SetDefault("+11% Melee Speed!\n+11% Melee Speed!\nTwins Beware...");
    }


        public override void UpdateEquip(Player player)
        {
            player.buffImmune[BuffID.CursedInferno] = true;
       
            player.meleeSpeed += 0.11f; //(thats 10% icreased dMage)
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("TechnoliteBar"), 22);
            recipe.AddIngredient(null, ("GeraniumElement"), 8);
            recipe.AddIngredient(ItemID.SoulofNight, 8);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
