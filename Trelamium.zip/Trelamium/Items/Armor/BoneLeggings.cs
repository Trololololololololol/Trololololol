﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class BoneLeggings : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = 11010;
            item.rare = 2;
            item.defense = 4; //51
        }

    public override void SetStaticDefaults()
    {
        DisplayName.SetDefault("Dreaded Leggings");
      Tooltip.SetDefault("4% increased minion and magic damage");
    }


        public override void UpdateEquip(Player player)
        {
            player.minionDamage += 0.04f;
            player.magicDamage += 0.04f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Lens", 4);
            recipe.AddIngredient(null, "Teeth", 7);
            recipe.AddIngredient(null, "RippedRug", 18);
            recipe.AddTile(null, ("CryingBloodAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
