﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class BloomPlate : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 34;
            item.height = 22;

            item.value = Terraria.Item.sellPrice(0, 2, 0, 0);
            item.rare = 8;
            item.defense = 25;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Bloom Platemail");
      Tooltip.SetDefault("22% increased magic and minion damage\n22% increased magic and minion damage");
    }


        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.22f;
            player.minionDamage += 0.22f;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("PlanteraSkin"), 13);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
