using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class DarkGreaves : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = Terraria.Item.buyPrice(0, 3, 25, 0);
            item.rare = 10;
            item.defense = 25;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dark Greaves");
      Tooltip.SetDefault("10% increased movement speed\n10% increased movement speed");
    }


        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.10f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("DarkBar"), 8);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
