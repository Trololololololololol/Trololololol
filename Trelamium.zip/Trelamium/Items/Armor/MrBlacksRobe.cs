﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class MrBlacksRobe : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 34;
            item.height = 30;

            item.rare = 1;
            item.vanity = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Mr.Black's Robe");
      Tooltip.SetDefault("Great for impersonating devs!");
    }

    }
}
