﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class GarnetPlatemail : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 26;
            item.height = 18;

            item.value = Terraria.Item.sellPrice(0, 2, 50, 0);   
            item.rare = 7;
            item.defense = 7;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Garnet Platemail");
      Tooltip.SetDefault("Maximum health Increased by 15\nMaximum health Increased by 15");
    }


        public override void UpdateEquip(Player player)
        {
            player.statLifeMax2 += 15;
        }
        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Garnet"), 18);
            recipe.AddTile(null, ("GemBlaster"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
