using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class GarnetMask : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 28;

            item.value = Terraria.Item.sellPrice(0, 0, 23, 0);
            item.rare = 7;
            item.defense = 5;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Garnet Mask");
      Tooltip.SetDefault("12% increased melee damage\n12% increased melee damage");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("GarnetPlatmail") && legs.type == mod.ItemType("GarnetGreaves");  //put your Breastplate name and Leggings name
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "12% increased melee damage, critical strike and speed."; // the armor set bonus
            player.meleeDamage += 0.12f;
            player.meleeSpeed += 0.12f;
            player.meleeCrit += 6;
        }//player movement speed incresed 0.05f = 5%

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Garnet"), 7);
            recipe.AddTile(null, ("GemBlaster"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
