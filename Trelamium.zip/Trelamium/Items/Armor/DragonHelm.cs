using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class DragonHelm : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 26;
            item.height = 24;

            item.value = Terraria.Item.buyPrice(0, 0, 75, 0);
            item.rare = 8;
            item.defense = 13;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dragon Headgear");
      Tooltip.SetDefault("18% Increased melee damage.\n18% Increased melee damage.");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("DragonChest") && legs.type == mod.ItemType("DragonBoots");
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "you have been granted, Immunity to all fire debuffs, and a flaming shpere rotates around you";
            player.AddBuff(BuffID.Inferno, 2);
            player.buffImmune[BuffID.CursedInferno] = true;
            player.buffImmune[BuffID.OnFire] = true;
            player.buffImmune[BuffID.Burning] = true;
            player.buffImmune[BuffID.ShadowFlame] = true;
            player.buffImmune[mod.BuffType("DarkDebuff")] = true;
            player.buffImmune[mod.BuffType("DarkDebufff")] = true;
            player.buffImmune[mod.BuffType("TrelamiumDebuff")] = true;

        }
        public override void ArmorSetShadows(Player player)
        {
            player.armorEffectDrawShadow = true;
            player.armorEffectDrawOutlines = true;
        }

        public override void UpdateEquip(Player player)
        {
            player.meleeDamage += 0.18f;
        }
        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null,("DB"), 17);
            recipe.AddTile(TileID.AdamantiteForge);   //at work bench
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
