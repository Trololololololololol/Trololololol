using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class AlluviumBoots : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;


            item.value = Terraria.Item.sellPrice(0, 0, 23, 0);
            item.rare = 2;
            item.defense = 7;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Alluvium Boots");
      Tooltip.SetDefault("It's literally made from the dirt\n10% increased movement speed");
    }


        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.10f;  //player movement speed incresed 0.05f = 5%
        }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("AlluviumBar"), 12);
            recipe.AddTile(TileID.LivingLoom);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
