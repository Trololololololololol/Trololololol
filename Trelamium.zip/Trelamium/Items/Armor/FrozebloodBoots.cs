using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class FrozebloodBoots : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = Terraria.Item.sellPrice(0, 8, 23, 0);
            item.rare = 7;
            item.defense = 30;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Frostblood Cuisses");
      Tooltip.SetDefault("26% increased melee critical strike chance\n26% increased melee critical strike chance");
    }


        public override void UpdateEquip(Player player)
        {
            player.meleeCrit += 26;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("FrozebloodBar"), 25);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
