﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class PrimeFuryChest : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 18;

            item.value = 11010;
            item.rare = 8;
            item.defense = 22; //51
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Prime Steel Breastplate");
      Tooltip.SetDefault("8% increased melee critical strike chance!");
    }


        public override void UpdateEquip(Player player)
        {
            player.meleeCrit += 8;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "PrimeSteel", 18);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
