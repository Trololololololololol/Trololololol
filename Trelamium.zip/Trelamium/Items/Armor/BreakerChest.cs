﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class BreakerChest : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 34;
            item.height = 22;

            item.value = Terraria.Item.sellPrice(0, 4, 0, 0);
            item.rare = 5;
            item.defense = 11;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Breaker Chestplate");
      Tooltip.SetDefault("12% Increased damage\n12% Increased damage");
    }


        public override void UpdateEquip(Player player)
        {
            player.meleeDamage += 0.12f;
            player.rangedDamage += 0.12f;
            player.thrownDamage += 0.12f;
            player.magicDamage += 0.12f;
            player.minionDamage += 0.12f;
        }
    }
}
