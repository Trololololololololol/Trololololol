using System.Collections.Generic;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class MrBlacksMask : ModItem
    {

		public override void SetDefaults()
		{

			item.width = 28;
			item.height = 22;

			item.rare = 1;
			item.vanity = true;
		}

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Mr.Black's Mask");
      Tooltip.SetDefault("Great for impersonating devs!");
    }


		public override bool DrawHead()
		{
			return false;
		}
	}
}
