﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class EnchantedChest : ModItem
    {


        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 20;

            item.value = Terraria.Item.buyPrice(0, 0, 20, 0);
            item.rare = 1;
            item.defense = 4;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Enchanted Chainmail");
      Tooltip.SetDefault("Inreases your magic critical strike chance by 8");
    }


        public override void UpdateEquip(Player player)
        {
            player.magicCrit += 8;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("EnchantcianPrism"), 8);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
