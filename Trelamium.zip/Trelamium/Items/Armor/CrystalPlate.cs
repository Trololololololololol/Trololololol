﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class CrystalPlate : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 18;


            item.value = Terraria.Item.sellPrice(0, 1, 0, 0);
            item.rare = 6;
            item.defense = 14;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Crystal Plate Mail");
            Tooltip.SetDefault("+50 maximum mana\n+50 maximum life\n12% increased magic damage\n'Shimmering with pure light.'");
        }


        public override void UpdateEquip(Player player)
        {
            player.statLifeMax2 += 50;
            player.statManaMax2 += 50;
            player.magicDamage += 0.12f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.CrystalShard, 18);
            recipe.AddIngredient(ItemID.SoulofLight, 4);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}