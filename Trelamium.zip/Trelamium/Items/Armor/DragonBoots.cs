using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class DragonBoots : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = Terraria.Item.buyPrice(0, 0, 20, 0);
            item.rare = 8;
            item.defense = 18;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dragon Greaves");
      Tooltip.SetDefault("15% increased movement speed\n15% increased movement speed");
    }


        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.15f;  //player movement speed incresed 0.05f = 5%
        }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("DB"), 22);
            recipe.AddTile(TileID.AdamantiteForge);   //at work bench
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
