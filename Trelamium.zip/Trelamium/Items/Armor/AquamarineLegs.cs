﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    public class AquamarineLegs : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = 11010;
            item.rare = 2;
            item.defense = 4; //51
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aquamarine Leggings");
      Tooltip.SetDefault("5% increased minion damage");
    }


        public override void UpdateEquip(Player player)
        { 
            player.minionDamage += 0.05f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Aquamarine"), 19);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
