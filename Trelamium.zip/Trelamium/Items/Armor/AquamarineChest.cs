﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class AquamarineChest : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 24;

            item.value = 21010;
            item.rare = 5;
            item.defense = 5; //51
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aquamarine Breastplate");
      Tooltip.SetDefault("Increases max minions");
    }


        public override void UpdateEquip(Player player)
        {
            player.maxMinions++;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Aquamarine"), 23);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
