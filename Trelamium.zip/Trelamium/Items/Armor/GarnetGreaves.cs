using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class GarnetGreaves : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = Terraria.Item.sellPrice(0, 0, 23, 0);
            item.rare = 7;
            item.defense = 6;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Garnet Greaves");
      Tooltip.SetDefault("6% increased melee critical strike chance\n6% increased melee critical strike chance");
    }


        public override void UpdateEquip(Player player)
        {
            player.meleeCrit += 6;  //player movement speed incresed 0.05f = 5%
        }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Garnet"), 12);
            recipe.AddTile(null, ("GemBlaster"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
