﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class CrystalHelm : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 32;
            item.height = 26;


            item.value = Terraria.Item.sellPrice(0, 1, 0, 0);
            item.rare = 6;
            item.defense = 9;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Crystal Headgear");
      Tooltip.SetDefault("12% increased Magic damage and critical strike chance.\n'Pulsing with pure light.'");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("CrystalPlate") && legs.type == mod.ItemType("CrystalGreaves");
        }

        public override void ArmorSetShadows(Player player)
        {
            player.armorEffectDrawShadow = true;
            player.armorEffectDrawOutlines = true;
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "If you are under 50%, you have a small chance to gain a random buff";
            if (player.statLife <= (player.statLifeMax2 * 0.50f))
            {
                if (Main.rand.Next(14) == 0)
                {
                    player.AddBuff(BuffID.Thorns, 2);
                }
                if (Main.rand.Next(14) == 0)
                {
                    player.AddBuff(BuffID.Shine, 2);
                }
                if (Main.rand.Next(14) == 0)
                {
                    player.AddBuff(BuffID.Regeneration, 2);
                }
                if (Main.rand.Next(14) == 0)
                {
                    player.AddBuff(BuffID.ManaRegeneration, 2);
                }
                if (Main.rand.Next(14) == 0)
                {
                    player.AddBuff(BuffID.MagicPower, 2);
                }
                if (Main.rand.Next(14) == 0)
                {
                    player.AddBuff(BuffID.Ironskin, 2);
                }
                if (Main.rand.Next(14) == 0)
                {
                    player.AddBuff(BuffID.Swiftness, 2);
                }
                if (Main.rand.Next(14) == 0)
                {
                    player.AddBuff(BuffID.Spelunker, 2);
                }
                if (Main.rand.Next(14) == 0)
                {
                    player.AddBuff(BuffID.Battle, 2);
                }
            }
        }
        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.12f;
            player.magicCrit += 12;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.CrystalShard, 14);
            recipe.AddIngredient(ItemID.SoulofLight, 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
