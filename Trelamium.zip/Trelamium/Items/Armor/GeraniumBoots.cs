using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class GeraniumBoots : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 22;
            item.height = 18;

            item.value = Terraria.Item.sellPrice(0, 8, 0, 0);
            item.rare = 6;
            item.defense = 12;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Geranium Leggings");
      Tooltip.SetDefault("Increases your max minions\nIncreases your max minions");
    }


        public override void UpdateEquip(Player player)
        {
            player.maxMinions += 1;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("GeraniumElement"), 8);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
