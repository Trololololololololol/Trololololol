﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items.Armor;
namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class FadedHeadMelee : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = 10000;
            item.defense = 3; //15
            item.rare = 4;
            item.scale = 1.5f;
        }

    public override void SetStaticDefaults()
    {
        DisplayName.SetDefault("Faded War Helmet");
      Tooltip.SetDefault("5% increased melee damage.");
    }

        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("FadedChest") && legs.type == mod.ItemType("FadedLegs");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Increases defense and life regeneration!";
            player.lifeRegen = +2;
            player.statDefense++;
            player.statDefense++;
            player.statDefense++;
            player.statDefense++;

        }

        public override void UpdateEquip(Player player)
        {
            player.meleeDamage += 0.05f;

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("FadedSteel"), 21);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
