using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class WeldiniumLegs : ModItem
    {

        public override void SetDefaults()
        {

            item.width = 33;
            item.height = 27;

            item.value = Terraria.Item.sellPrice(0, 0, 64, 0);
            item.rare = 3;
            item.defense = 5;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Weldinium Greaves");
      Tooltip.SetDefault("10% Increased thrown Damage.");
    }


        public override void UpdateEquip(Player player)
        {
            player.thrownDamage += 0.10f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("WeldiniumBar"), 15);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
