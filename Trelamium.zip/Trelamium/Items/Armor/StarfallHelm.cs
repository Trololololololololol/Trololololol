using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class StarfallHelm : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 26;
            item.height = 22;

            item.value = Terraria.Item.sellPrice(0, 0, 90, 0);
            item.rare = 4;
            item.defense = 8;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Starfall Helemet");
      Tooltip.SetDefault("Crafted from the Rage of the fallen Angels.");
    }


        public override bool IsArmorSet(Terraria.Item head, Terraria.Item body, Terraria.Item legs)
        {
            return body.type == mod.ItemType("StarfallChest") && legs.type == mod.ItemType("StarfallLegs");  //put your Breastplate name and Leggings name
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "There is a small chance for stars to fall when hit."; // the armor set bonus
            player.AddBuff(BuffID.Ironskin, 2);

        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("StarfallBar"), 13);
            recipe.AddTile(TileID.SkyMill);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
