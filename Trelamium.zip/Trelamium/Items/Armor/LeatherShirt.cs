﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class LeatherShirt : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 20;

            item.value = Terraria.Item.buyPrice(0, 1, 75, 0);
            item.rare = 0;
            item.vanity = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Leather Jacket");
      Tooltip.SetDefault("From the designer's latest campaign");
    }

    }
}
