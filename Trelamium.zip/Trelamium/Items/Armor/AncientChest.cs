﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class AncientChest : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 38;
            item.height = 20;


            item.value = 10;
            item.rare = 3;
            item.defense = 3;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ancient Breastplate");
      Tooltip.SetDefault("The Ancient Chestplate.\n6% Increased Thrown Damage & Critical strike chance.");
    }


        public override void UpdateEquip(Player player)
        {
            player.thrownDamage += 0.06f;
            player.thrownCrit += 6;
        }
        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Sandstone, 25);
            recipe.AddIngredient(ItemID.HardenedSand, 10); //you need 10 Wood
            recipe.AddTile(TileID.Furnaces);   //at work bench
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
