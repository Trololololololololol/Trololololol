using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class PlanteraSkin : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;
            item.maxStack = 999;
            item.value = Terraria.Item.sellPrice(0, 0, 37, 0);
            item.rare = 8;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Plant Skin");
      Tooltip.SetDefault("");
    }

    }
}
