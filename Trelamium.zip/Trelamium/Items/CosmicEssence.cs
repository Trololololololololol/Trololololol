using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria.DataStructures;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class CosmicEssence : ModItem
    {
        public override void SetDefaults()
        {
            item.width = 24;
            item.height = 24;
            item.value = Terraria.Item.sellPrice(0, 3, 0, 0);
            item.value = 10000;
            item.rare = -11;
            item.maxStack = 999;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Nova Prism");
      Tooltip.SetDefault("");
      Main.RegisterItemAnimation(item.type, new DrawAnimationVertical(3, 11));
      ItemID.Sets.AnimatesAsSoul[item.type] = true;
      ItemID.Sets.ItemIconPulse[item.type] = true;
      ItemID.Sets.ItemNoGravity[item.type] = true;
    }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Hellstone, 1);
			recipe.AddIngredient(ItemID.Obsidian, 1);
			recipe.AddIngredient(ItemID.LunarOre, 1);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
