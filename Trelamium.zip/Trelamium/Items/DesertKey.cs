using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class DesertKey : ModItem
	{
		public override void SetDefaults()
		{

			item.width = 20;
			item.height = 20;
			item.maxStack = 999;
			item.rare = 8;
		}

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Desert Key");
      Tooltip.SetDefault("");
    }

	}
}
