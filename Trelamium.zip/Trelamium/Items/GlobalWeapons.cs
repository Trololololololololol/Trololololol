﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria.ID;
using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Items
{
	public class ExampleItem : GlobalItem
    {
        public override bool InstancePerEntity
        {
            get
            {
                return true;
            }
        }

        public override void SetDefaults(Item item)
        {
            if (item.type == ItemID.MoneyTrough)
            {
                item.value = Terraria.Item.buyPrice(0, 10, 0, 0);
            }
            if (item.type == ItemID.StoneBlock)
            {
                item.value = Terraria.Item.buyPrice(0, 0, 0, 30);
            }
            if (item.type == ItemID.EbonstoneBlock)
            {
                item.value = Terraria.Item.buyPrice(0, 0, 0, 80);
            }
            if (item.type == ItemID.CrimstoneBlock)
            {
                item.value = Terraria.Item.buyPrice(0, 0, 0, 85);
            }
            if (item.type == ItemID.PearlstoneBlock)
            {
                item.value = Terraria.Item.buyPrice(0, 0, 1, 0);
            }
            if (item.type == ItemID.Hellstone)
            {
                item.value = Terraria.Item.buyPrice(0, 0, 80, 0);
            }
            if (item.type == ItemID.Obsidian)
            {
                item.value = Terraria.Item.buyPrice(0, 0, 15, 0);
            }
        }
    }
}