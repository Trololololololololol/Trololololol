﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
using Trelamium.NPCs;

namespace Trelamium.Items
{
    public class ShieldBreak : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 28;
            item.height = 28;
            item.maxStack = 1;
            item.rare = 1;
            item.useAnimation = 45;
            item.useTime = 45;
            item.useStyle = 4;
            item.UseSound = SoundID.Item119;
            item.consumable = false;
        }
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Corrupted Cright Flare");
            Tooltip.SetDefault("'Breaks The Shield Protecting The World From The Ancients'");
        }
        public override bool CanUseItem(Player player)
        {
            return true;
        }

        public override bool UseItem(Player player)
        {
            {

                Main.NewText("The Army Can Reach The Planet", Color.Red.R, Color.Purple.G, Color.Blue.B);
                ModGlobalNPC.AncientInvasion = true;
            }
            return true;
        }
    }
}