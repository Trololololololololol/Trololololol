using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class RippedLeather : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 24;
            item.maxStack = 99;
            item.rare = -1;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ripped Leather");
      Tooltip.SetDefault("");
    }

    }
}
