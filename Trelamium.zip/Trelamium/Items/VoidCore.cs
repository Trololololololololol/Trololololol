using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class VoidCore : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 20;
            item.height = 16;
            item.maxStack = 99;
            item.value = 2500;
            item.rare = 6;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Void Chunk");
      Tooltip.SetDefault("");
    }

    }
}
