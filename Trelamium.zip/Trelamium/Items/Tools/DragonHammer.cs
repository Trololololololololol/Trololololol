using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class DragonHammer : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 63;
            item.melee = true;
            item.width = 64;
            item.height = 64;
            item.useTime = 25;
            item.useAnimation = 25;
            item.hammer = 110;   //hammer power
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = 100;
            item.rare = 8;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dragon Hammer");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("DB"), 14);
            recipe.AddTile(TileID.AdamantiteForge);   //at work bench
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
