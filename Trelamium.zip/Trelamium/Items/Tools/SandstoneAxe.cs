using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class SandstoneAxe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 8;
            item.melee = true;
            item.width = 34;
            item.height = 34;
            item.useTime = 20;
            item.useAnimation = 20;
            item.axe = 9;
            item.useStyle = 1;
            item.knockBack = 1;
            item.value = 10;
            item.rare = 3;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = false;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ancient Axe");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.HardenedSand, 25);
            recipe.AddIngredient(ItemID.Sandstone, 10);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);  
            recipe.AddRecipe();
        }
    }
}
