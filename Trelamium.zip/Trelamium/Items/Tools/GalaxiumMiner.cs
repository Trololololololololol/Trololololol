﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.DataStructures;
using System.Collections.Generic;
using System;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class GalaxiumMiner : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 55;
            item.melee = true;
            item.width = 46;
            item.height = 46;
            item.useTime = 1;

            item.useAnimation = 20;
            item.pick = 255;
            item.useStyle = 1;
            item.knockBack = 6;
            item.tileBoost += 10;
            item.value = Terraria.Item.buyPrice(5, 13, 0, 0);
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Galaxium Miner");
            Tooltip.SetDefault("Strong Enough To Break Lunatic Ore");
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine line2 in list)
            {
                if (line2.mod == "Terraria" && line2.Name == "ItemName")
                {
                    line2.overrideColor = new Color(155, 0, 78);
                }
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("SoulOfCright"), 15);
            recipe.AddIngredient(ItemID.Picksaw);
            recipe.AddRecipeGroup("LunarPickaxes");
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
