using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class DragonPickaxe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 34;
            item.melee = true;
            item.width = 46;
            item.height = 46;
            item.useTime = 20;
            item.useAnimation = 20;
            item.pick = 130;
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = 10;
            item.rare = 8;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dragon Pickaxe");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("DB"), 18);
            recipe.AddTile(TileID.AdamantiteForge);
            recipe.SetResult(this);  
            recipe.AddRecipe();
        }
    }
}
