using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class Dolodrill : ModItem
	{
		public override void SetDefaults()
		{

			item.damage = 22;          
			item.melee = true;
			item.width = 59;
			item.height = 18;

			item.useTime = 9;
			item.useAnimation = 25;
			item.channel = true;
			item.noUseGraphic = true;
			item.noMelee = true;
			item.pick = 70;
			item.tileBoost++;
			item.useStyle = 5;
			item.knockBack = 6;
            item.value = Terraria.Item.sellPrice(0, 2, 50, 0);
			item.rare = 2;
			item.UseSound = SoundID.Item23;
			item.autoReuse = true;
            item.shoot = mod.ProjectileType("DolodrillP");
			item.shootSpeed = 40f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Dolodrill");
      Tooltip.SetDefault("Can mine hellstone");
    }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Dolomite"), 48);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
