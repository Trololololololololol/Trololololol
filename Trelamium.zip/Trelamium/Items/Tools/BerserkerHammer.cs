using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class BerserkerHammer : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 26;

            item.width = 64;
            item.height = 64;
            item.useTime = 65;
            item.useAnimation = 65;

            item.hammer = 400;
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = Terraria.Item.buyPrice(0, 20, 0, 0);
            item.rare = 3;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.melee = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Berserker Hammer");
      Tooltip.SetDefault("The 1-Hit Hammer!");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("DB"), 14);
            recipe.AddTile(TileID.AdamantiteForge);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
