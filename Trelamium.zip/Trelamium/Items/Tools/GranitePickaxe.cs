using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.DataStructures;
using System.Collections.Generic;
using System;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class GranitePickaxe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 10;
            item.melee = true;
            item.width = 46;
            item.height = 46;
            item.useTime = 20;
            item.useAnimation = 20;
            item.pick = 40;
            item.useStyle = 1;
            item.knockBack = 6;
            item.tileBoost += 1;
            item.value = Terraria.Item.buyPrice(0, 0, 5, 0);
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.rare = 1;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Granite Pickaxe");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Granite, 25);
            recipe.AddTile(null, ("GraniteAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
