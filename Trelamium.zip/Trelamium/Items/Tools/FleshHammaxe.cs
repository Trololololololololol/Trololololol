using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class FleshHammaxe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 25;
            item.melee = true;
            item.width = 48;
            item.height = 44;
            item.useTime = 20;
            item.useAnimation = 20;
            item.axe = 50;
            item.hammer = 130;
            item.useStyle = 1;
            item.knockBack = 7;
            item.value = Terraria.Item.buyPrice(0, 8, 0, 0);
            item.rare = 4;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Flesh Hammaxe");
      Tooltip.SetDefault("");
    }


        public override void MeleeEffects(Player player, Rectangle hitbox)
        {
            if (Main.rand.Next(3) == 0)
            {
                int dust = Dust.NewDust(new Vector2(hitbox.X, hitbox.Y), hitbox.Width, hitbox.Height, 3);
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("PieceOfFlesh"), 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
