using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class AlluviumPickaxe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 22;
            item.melee = true;
            item.width = 32;
            item.height = 32;

            item.useTime = 20;
            item.useAnimation = 20;
            item.pick = 95;
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = Terraria.Item.sellPrice(0, 0, 23, 0);
            item.rare = 2;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Alluvium Pickaxe");
      Tooltip.SetDefault("It's literally made from the dirt");
    }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("AlluviumBar"), 15);
            recipe.AddTile(TileID.LivingLoom);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
