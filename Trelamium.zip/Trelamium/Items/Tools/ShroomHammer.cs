using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class ShroomHammer : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 16;
            item.width = 64;
            item.height = 64;
            item.useTime = 65;
            item.useAnimation = 65;
            item.hammer = 50;
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = Terraria.Item.buyPrice(0, 0, 0, 25);
            item.rare = 3;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.melee = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Mushroom Hammer");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Mushroom, 12);
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
