using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using System.Collections.Generic;

namespace Trelamium.Items.Tools
{
    public class FrozebloodHamaxe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 25;
            item.melee = true;
            item.width = 48;
            item.height = 44;
            item.useTime = 2;
            item.useAnimation = 20;
            item.axe = 100;
            item.hammer = 300;
            item.useStyle = 1;
            item.knockBack = 7;
            item.value = Terraria.Item.buyPrice(0, 13, 0, 0);
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Frostblood Hammaxe");
      Tooltip.SetDefault("");
    }


        public override void MeleeEffects(Player player, Rectangle hitbox)
        {
            if (Main.rand.Next(3) == 0)
            {
                int dust = Dust.NewDust(new Vector2(hitbox.X, hitbox.Y), hitbox.Width, hitbox.Height, 3);
            }
        }
        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine line2 in list)
            {
                if (line2.mod == "Terraria" && line2.Name == "ItemName")
                {
                    line2.overrideColor = new Color(155, 0, 78);
                }
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("FrozebloodBar"), 12);
            recipe.AddRecipeGroup("LunarHamaxes");
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
