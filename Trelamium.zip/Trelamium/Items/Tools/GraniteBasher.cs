using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class GraniteBasher : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 5;
            item.melee = true;
            item.width = 64;
            item.height = 64;
            item.useTime = 18;
            item.useAnimation = 18;
            item.hammer = 25;
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = Terraria.Item.buyPrice(0, 0, 4, 50);
            item.rare = 1;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Granite Basher");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Granite, 30);
            recipe.AddTile(null, ("GraniteAltar"));
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
