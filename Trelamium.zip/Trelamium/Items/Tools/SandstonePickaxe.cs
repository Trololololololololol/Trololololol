using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class SandstonePickaxe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 10;
            item.melee = true;
            item.width = 34;
            item.height = 34;
            item.useTime = 18;
            item.useAnimation = 18;
            item.pick = 45;
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = 10;
            item.rare = 3;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Ancient Pickaxe");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.HardenedSand, 25);
            recipe.AddIngredient(ItemID.Sandstone, 10);
            recipe.AddTile(TileID.Furnaces);
            recipe.SetResult(this);  
            recipe.AddRecipe();
        }
    }
}
