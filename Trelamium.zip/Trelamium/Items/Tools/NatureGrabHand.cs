﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class NatureGrabHand : ModItem
    {
        public override void SetDefaults()
        {
            //clone and modify the ones we want to copy
            item.CloneDefaults(ItemID.AmethystHook);
            item.shootSpeed = 20f; // how quickly the hook is shot.
            item.shoot = mod.ProjectileType("NatureGrabHandHook");
        }
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Nature Vine");
            Tooltip.SetDefault("'Be The Tarzan'");
        }
    }
}