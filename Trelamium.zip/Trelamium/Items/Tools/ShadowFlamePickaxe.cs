using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class ShadowFlamePickaxe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 12;
            item.melee = true;
            item.width = 32;
            item.height = 32;

            item.useTime = 10;
            item.useAnimation = 10;
            item.pick = 140;
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = 10;
            item.rare = 7;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Shadowflame Pickaxe");
      Tooltip.SetDefault("Cursed and Burning to the touch");
    }


        public override void MeleeEffects(Player player, Rectangle hitbox)
        {
            if (Main.rand.Next(1) == 0)
            {
                int dust = Dust.NewDust(new Vector2(hitbox.X, hitbox.Y), hitbox.Width, hitbox.Height, 227);
            }
        }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("ShadowFlameEssence"), 12); //you need 10 Wood
            recipe.AddTile(TileID.MythrilAnvil);   //at work bench
            recipe.SetResult(this);
        }
        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            target.AddBuff(BuffID.ShadowFlame, 400);
        }
    }
}
