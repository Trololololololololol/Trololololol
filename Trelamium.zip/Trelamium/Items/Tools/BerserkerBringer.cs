using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Tools
{
    public class BerserkerBringer : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 35;
            item.melee = true;
            item.width = 32;
            item.height = 32;
            item.useTime = 8;
            item.useAnimation = 8;
            item.pick = 105;
            item.useStyle = 1;
            item.knockBack = 4;
            item.value = Terraria.Item.buyPrice(0, 6, 0, 0);
            item.rare = 2;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Berserker Bringer");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.TissueSample, 17);
            recipe.AddIngredient(ItemID.HellstoneBar, 8);
            recipe.AddTile(TileID.Hellforge);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            target.AddBuff(mod.BuffType("HellFire"), 500);
        }
    }
}
