using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class SkyFlare : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 20;
            item.height = 20;

            item.maxStack = 999;
            item.value = Terraria.Item.sellPrice(0, 0, 17, 0);
            item.rare = 8;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Sky Flare");
        }
    }
}