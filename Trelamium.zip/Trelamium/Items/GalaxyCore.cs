using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class GalaxyCore : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 26;
            item.height = 26;
            item.maxStack = 99;
            item.value = 11100;
            item.rare = 9;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Galaxy Core");
      Tooltip.SetDefault("");
    }

    }
}
