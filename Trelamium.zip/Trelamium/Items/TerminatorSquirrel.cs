using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class TerminatorSquirrel : ModItem
	{
        public override void SetDefaults()
        {

            item.width = 16;
            item.height = 18;
            item.maxStack = 999;
            item.rare = 0;
            item.useAnimation = 25;
            item.useTime = 25;
            item.useStyle = 1;
            item.consumable = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Terminator Squirrel");
      Tooltip.SetDefault("");
    }

		public override bool UseItem(Player player)
		{
            NPC.SpawnOnPlayer(player.whoAmI, mod.NPCType("TerminatorSquirrel"));
			return true;
		}
	}
}
