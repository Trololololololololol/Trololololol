using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.DarkWING
{
    public class DarkBar : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Dark Bar");
        }
        public override void SetDefaults()
        {
            item.width = 30;
            item.height = 24;
            item.maxStack = 99;
            item.value = Terraria.Item.buyPrice(0, 8, 0, 0);
            item.rare = 10;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("DarkOre"), 4);
            recipe.AddIngredient(ItemID.SoulofFright, 1);
            recipe.AddIngredient(TileID.AdamantiteForge);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
