using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.DarkWING
{
    public class RosarioOfDarkWING : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Rosario of DarkWING");
            Tooltip.SetDefault("When Immune, you deal double damage");
        }
        public override void SetDefaults()
        {
            item.width = 58;
            item.height = 52;
            item.value = Terraria.Item.buyPrice(0, 30, 0, 0);
            item.rare = 10;
            item.accessory = true;
            item.expert = true;
        }
        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (player.immune)
            {
                player.meleeDamage *= 2f;
                player.rangedDamage *= 2f;
                player.minionDamage *= 2f;
                player.magicDamage *= 2f;
                player.meleeSpeed *= 2f;
                player.thrownDamage *= 2f;
            }
        }
    }
}