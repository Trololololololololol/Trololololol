﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class PrimeChunk : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;
            item.maxStack = 999;
            item.value = Terraria.Item.sellPrice(0, 0, 1, 0);
            item.rare = 8;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Prime Steel Chunk");
      Tooltip.SetDefault("");
    }


    }
}


