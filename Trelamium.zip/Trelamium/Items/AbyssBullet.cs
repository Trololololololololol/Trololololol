using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items;

namespace Trelamium.Items
{
    public class AbyssBullet : ModItem
	{
		public override void SetDefaults()
		{

			item.damage = 24;
			item.ranged = true;
			item.width = 8;
			item.height = 8;
			item.maxStack = 999;
			item.consumable = true;
			item.knockBack = 1.5f;
			item.value = 1250;
			item.rare = 8;
            item.shoot = mod.ProjectileType("AbyssBulletP");
			item.shootSpeed = 9f;
			item.ammo = 97;
		}

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Abyssal Round");
      Tooltip.SetDefault("");
    }


		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.MusketBall, 150);
			recipe.AddIngredient(null, "VoidCore");
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this, 150);
			recipe.AddRecipe();
		}
	}
}
