﻿using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.CrystalKing
{
    [AutoloadEquip(EquipType.Shield)]
    public class CristaliteShieldExpert : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 24;
            item.height = 28;


            item.value = Terraria.Item.sellPrice(2, 44, 75, 0);
            item.rare = -12;
            item.expert = true;
            item.accessory = true;
            item.defense = 10;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Cristalite Shield");
      Tooltip.SetDefault("Grants immunity to knockback\nWhen player is under 50% health, you gain 75 defense and 20% increased magic damage\nGrants 10% magic damage ");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.magicDamage += 0.10f;
            if (player.statLife <= (player.statLifeMax2 * 0.50f))
            {
                player.statDefense += 75;
                player.magicDamage += 0.20f;
            }
        }
    }
}
