﻿using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.CrystalKing
{
    public class CrystalBag : ModItem
    {
        public override void SetDefaults()
        {

            item.maxStack = 999;
            item.consumable = true;
            item.width = 32;
            item.height = 32;

            item.rare = -12;
            bossBagNPC = mod.NPCType("CrystalDigger_Head");
            item.expert = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Treasure Bag");
      Tooltip.SetDefault("Right Click to open");
    }

        public override bool CanRightClick()
        {
            return true;
        }

        public override void OpenBossBag(Player player)
        {
            player.TryGettingDevArmor();
            player.TryGettingDevArmor();
            int choice = Main.rand.Next(3);
            if (choice == 0)
            {
                player.QuickSpawnItem(mod.ItemType("Crist"));
            }
            if (choice == 1)
            {
                player.QuickSpawnItem(mod.ItemType("Cristalian"));
            }
            if (choice == 2)
            {
                player.QuickSpawnItem(mod.ItemType("CristaliteScythe"));
            }
            player.QuickSpawnItem(mod.ItemType("Crystal"), Main.rand.Next(2, 3));
            player.QuickSpawnItem(mod.ItemType("CristaliteShieldExpert"));
        }
    }
}
