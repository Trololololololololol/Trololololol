﻿using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.CrystalKing
{
    public class Crystal : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;

            item.height = 30;
            item.value = Terraria.Item.sellPrice(0, 5, 0, 0);
            item.rare = 10;
            item.maxStack = 99;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Nebular Cristalite");
      Tooltip.SetDefault("'Contains ancient crystal power'");
    }

    }
}
