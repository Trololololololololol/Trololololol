using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Glacier
{
    public class IcePike : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 50;
            item.melee = true;

            item.width = 36;
            item.height = 36;
            item.scale = 1.1f;
            item.maxStack = 1;
            item.useTime = 1;
            item.useAnimation = 16;
            item.knockBack = 4f;
            item.UseSound = SoundID.Item1;
            item.noMelee = true;
            item.noUseGraphic = true;
            item.useTurn = true;
            item.autoReuse = false;
            item.useStyle = 5;
            item.value = Terraria.Item.sellPrice(0, 52, 0, 0);
            item.rare = 8;
            item.shoot = mod.ProjectileType("IcePikeP");  //put your Spear projectile name
            item.shootSpeed = 15f;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Everfrost Lance");
      Tooltip.SetDefault("Fires 3 ice sickles at once");
    }

        public override void MeleeEffects(Player player, Rectangle hitbox)
        {
            if (Main.rand.Next(1) == 0)
            {
                int dust = Dust.NewDust(new Vector2(hitbox.X, hitbox.Y), hitbox.Width, hitbox.Height, 67);
            }
        }
    }
}
