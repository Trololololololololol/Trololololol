using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Glacier
{
    public class LightningRod : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 26;
            item.height = 28;

            item.value = Terraria.Item.sellPrice(0, 2, 0, 0);
            item.rare = 7;    
            item.accessory = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Lightning Rod");
      Tooltip.SetDefault("Grants immunity to cold effects, including Everfrostburn");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.buffImmune[BuffID.Frostburn] = true;
            player.buffImmune[BuffID.Frozen] = true;
            player.buffImmune[BuffID.Chilled] = true;
            player.buffImmune[mod.BuffType("Everfrostburn")] = true;
        }
    }
}
