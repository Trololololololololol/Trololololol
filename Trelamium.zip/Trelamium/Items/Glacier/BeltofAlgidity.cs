﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Glacier
{
    public class BeltofAlgidity : ModItem
    {
        public override void SetDefaults()
        {
            item.CloneDefaults(ItemID.Tabi);


            item.damage = 50;
            item.width = 30;
            item.height = 26;
            item.value = Terraria.Item.buyPrice(0, 17, 0, 0);
            item.rare = 7;
            item.accessory = true;
            item.expert = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Belt of Algidity");
            Tooltip.SetDefault("'It's Broken Curse'\nGrants double movement speed increase when under 50% of your max health");
        }

        public override void UpdateEquip(Player player)
        {
            if (player.statLife <= (player.statLifeMax2 * 0.5f))
            {
                player.moveSpeed += 1f;
            }
        }
    }
}
