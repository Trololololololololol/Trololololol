using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Glacier
{
    public class GlacierBag : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Treasure Bag");
            Tooltip.SetDefault("Right Click to open");
        }
        public override void SetDefaults()
        {
            item.maxStack = 999;
            item.consumable = true;
            item.width = 32;
            item.height = 32;
            item.rare = -12;
            bossBagNPC = mod.NPCType("GlacierRun2");
            item.expert = true;
        }
        public override bool CanRightClick()
        {
            return true;
        }

        public override void OpenBossBag(Player player)
        {
            player.TryGettingDevArmor();
            player.TryGettingDevArmor();
            int choice = Main.rand.Next(7);
            if (choice == 0)
            {
                player.QuickSpawnItem(mod.ItemType("IcePike"));      
            }
            if (choice == 1)
            {
                player.QuickSpawnItem(mod.ItemType("ShiverthornBook"));
            }
            if (choice == 2)
            {
                player.QuickSpawnItem(mod.ItemType("IceBow"));
            }
            if (choice == 3)
            {
                player.QuickSpawnItem(mod.ItemType("LightningRod"));
            }
            if (choice == 4)
            {
                player.QuickSpawnItem(mod.ItemType("IceSickle"));
            }
            if (choice == 5)
            {
                player.QuickSpawnItem(mod.ItemType("FrostClaymore"));
            }
            if (choice == 6)
            {
                player.QuickSpawnItem(mod.ItemType("IceBow"));
            }
            if (choice == 7)
            {
                player.QuickSpawnItem(mod.ItemType("IceHelm"));
                player.QuickSpawnItem(mod.ItemType("IcePlate"));
                player.QuickSpawnItem(mod.ItemType("IceGreaves"));
            }
            player.QuickSpawnItem(mod.ItemType("BeltofAlgidity"));
        }
    }
}
