using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Glacier   //where is located
{
    public class IcePickaxe : ModItem
    {
        public override void SetDefaults()
        {

            item.damage = 27;            //Sword damage
            item.melee = true;            //if it's melee
            item.width = 44;              //Sword width
            item.height = 44;             //Sword height
            item.useTime = 13;          //how fast 
            item.useAnimation = 13;
            item.useStyle = 1;
            item.pick = 195;//Style is how this item is used, 1 is the style of the sword    //Sword knockback
            item.value = Terraria.Item.sellPrice(0, 4, 0, 0);
            item.rare = 1;
            item.UseSound = SoundID.Item1;       //1 is the sound of the sword
            item.autoReuse = true;   //if it's capable of autoswing.
            item.useTurn = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Everfrost Pickaxe");
      Tooltip.SetDefault("");
    }

        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            target.AddBuff(BuffID.Frostburn, 400);  //400 is the buff time
        }
    }
}
