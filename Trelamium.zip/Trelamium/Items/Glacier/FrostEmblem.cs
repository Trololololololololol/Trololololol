using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Glacier
{
    public class FrostEmblem : ModItem
	{
        public override void SetDefaults()
        {

            item.width = 16;
            item.height = 18;
            item.maxStack = 20;

            item.rare = 3;
            item.useAnimation = 45;
            item.useTime = 45;
            item.useStyle = 4;
            item.UseSound = SoundID.Item44;
            item.consumable = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Lens Of algidity");
      Tooltip.SetDefault("Summons the beasts of Everfrost...");
    }

		public override bool CanUseItem(Player player)
		{
			return player.ZoneSnow && !Main.dayTime && !NPC.AnyNPCs(mod.NPCType("Glacier"));
		}

		public override bool UseItem(Player player)
		{
            NPC.SpawnOnPlayer(player.whoAmI, mod.NPCType("Glacier"));
			Main.PlaySound(SoundID.Roar, player.position, 0);
			return true;
		}

		public override void AddRecipes()
		{
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.IceBlock, 80);
            recipe.AddRecipeGroup("MythrilBars", 12);
            recipe.AddIngredient(ItemID.SoulofNight, 8);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
		}
	}
}
