using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria.DataStructures;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace Trelamium.Items.Pyron
{
    public class RedHotCore : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 55;
            item.height = 224;
            item.value = 100;
            item.rare = -12;
            item.maxStack = 99;
            ItemID.Sets.ItemNoGravity[item.type] = true;
            item.expert = true;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Pyro Core");
            Tooltip.SetDefault("");
            Main.RegisterItemAnimation(item.type, new DrawAnimationVertical(6, 4));
            ItemID.Sets.AnimatesAsSoul[item.type] = true;
            ItemID.Sets.ItemIconPulse[item.type] = true;
            ItemID.Sets.ItemNoGravity[item.type] = true;
        }
    }
}