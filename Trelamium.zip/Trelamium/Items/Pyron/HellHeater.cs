using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace Trelamium.Items.Pyron
{
    public class HellHeater : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 26;
            item.height = 22;

            item.value = Terraria.Item.buyPrice(0, 20, 0, 0);
            item.rare = 6;
            item.accessory = true;
            item.expert = true;

        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Hell-Fire Charm");
      Tooltip.SetDefault("every 5% percentages of health lost, your movement speed is increased by 10%");
    }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (player.statLife <= (player.statLifeMax2 * 0.95f))
            {
                player.moveSpeed += 0.1f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.9f))
            {
                player.moveSpeed += 0.5f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.85f))
            {
                player.moveSpeed += 0.2f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.8f))
            {
                player.moveSpeed += 0.25f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.75f))
            {
                player.moveSpeed += 0.3f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.7f))
            {
                player.moveSpeed += 0.35f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.65f))
            {
                player.moveSpeed += 0.4f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.6f))
            {
                player.moveSpeed += 0.45f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.55f))
            {
                player.moveSpeed += 0.5f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.5f))
            {
                player.moveSpeed += 0.55f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.45f))
            {
                player.moveSpeed += 0.6f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.4f))
            {
                player.moveSpeed += 0.65f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.35f))
            {
                player.moveSpeed += 0.7f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.3f))
            {
                player.moveSpeed += 0.8f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.25f))
            {
                player.moveSpeed += 0.9f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.2f))
            {
                player.moveSpeed += 1f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.15f))
            {
                player.moveSpeed += 1.1f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.1f))
            {
                player.moveSpeed += 1.2f;
            }
            if (player.statLife <= (player.statLifeMax2 * 0.05f))
            {
                player.moveSpeed += 1.3f;
            }

        }
    }
}
