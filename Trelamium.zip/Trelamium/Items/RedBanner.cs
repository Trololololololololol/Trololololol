﻿using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
namespace Trelamium.Items
{
    public class RedBanner : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 14;
            item.height = 24;
            item.value = Terraria.Item.sellPrice(0, 0, 20, 0);
            item.rare = 3;
            item.maxStack = 99;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Red Cloth");
      Tooltip.SetDefault("");
    }

    }
}
