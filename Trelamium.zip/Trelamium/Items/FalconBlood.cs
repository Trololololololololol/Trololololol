using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class FalconBlood : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 24;
            item.value = Terraria.Item.sellPrice(0, 5, 45, 0);
            item.rare = 8;
            item.maxStack = 999;
        }

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Falcon Blood");
            Tooltip.SetDefault("'gross'");
        }
    }
}