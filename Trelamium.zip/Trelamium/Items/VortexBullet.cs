using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.Items;

namespace Trelamium.Items
{
    public class VortexBullet : ModItem
	{
		public override void SetDefaults()
		{

			item.damage = 14;
			item.ranged = true;
			item.width = 18;
			item.height = 20;
			item.maxStack = 999;
			item.consumable = true;
			item.knockBack = 1.5f;
			item.value = Terraria.Item.sellPrice(0, 0, 50, 0);
			item.rare = 10;
            item.shoot = 616;
			item.shootSpeed = 15f;
			item.ammo = 97;
		}

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Vortex Bullet");
      Tooltip.SetDefault("");
    }


		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.MusketBall, 150);
            recipe.AddIngredient(ItemID.FragmentVortex, 4);
			recipe.AddTile(TileID.LunarCraftingStation);
			recipe.SetResult(this, 150);
			recipe.AddRecipe();
		}
	}
}
