﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class PrimeSteel : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 30;
            item.height = 24;
            item.maxStack = 999;
            item.value = Terraria.Item.sellPrice(0, 1, 10, 0);
            item.rare = 8;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Prime Steel Ingot");
      Tooltip.SetDefault("");
    }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "PrimeChunk", 5);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}


