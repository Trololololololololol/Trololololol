﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
	public class Cake : ModItem
	{
		public override void SetDefaults()
		{

			item.width = 28;
			item.height = 18;
			item.useTurn = true;
			item.maxStack = 30;

			item.healLife = 40;
			item.rare = 0;
			item.useAnimation = 17;
			item.useTime = 17;
			item.useStyle = 2;
			item.UseSound = SoundID.Item3;
			item.consumable = true;
			item.potion = true;
		}

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Slice of cake");
      Tooltip.SetDefault("Delicious!");
    }


		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Hay, 12);
			recipe.AddTile(TileID.Furnaces);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
