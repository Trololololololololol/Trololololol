﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class SunSpiritBracing : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 28;
            item.height = 22;
            item.maxStack = 999;
            item.value = Terraria.Item.sellPrice(0, 0, 10, 0);
            item.rare = 5;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Sun Spirit Bracing");
      Tooltip.SetDefault("");
    }

    }
}
