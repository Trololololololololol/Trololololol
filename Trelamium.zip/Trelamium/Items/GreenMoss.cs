using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class GreenMoss : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 20;
            item.height = 20;
            item.maxStack = 99;
            item.value = Terraria.Item.sellPrice(0, 0, 3, 0);
            item.rare = 2;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Green Moss");
      Tooltip.SetDefault("");
    }

    }
}
