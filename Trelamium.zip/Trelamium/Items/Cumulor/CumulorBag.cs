using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Cumulor
{
    public class CumulorBag : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Treasure Bag");
            Tooltip.SetDefault("Right Click to open");
        }
        public override void SetDefaults()
        {
            item.maxStack = 999;
            item.consumable = true;
            item.width = 32;
            item.height = 32;
            item.rare = -12;
            bossBagNPC = mod.NPCType("Cumulor");
            item.expert = true;
        }
        public override bool CanRightClick()
        {
            return true;
        }

        public override void OpenBossBag(Player player)
        {
            int choice = Main.rand.Next(4);
            if (choice == 0)
            {
                player.QuickSpawnItem(mod.ItemType("CloudGun"));      
            }
            if (choice == 1)
            {
                player.QuickSpawnItem(mod.ItemType("CloudBuster"));
            }
            if (choice == 2)
            {
                player.QuickSpawnItem(mod.ItemType("Altostratus"));
            }
            if (choice == 3)
            {
                player.QuickSpawnItem(mod.ItemType("NimbusStaff"));
            }
            player.QuickSpawnItem(mod.ItemType("FeatherfootBoots"));
        }
    }
}
