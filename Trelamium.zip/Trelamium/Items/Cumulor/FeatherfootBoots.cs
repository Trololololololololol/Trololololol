﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using System;

namespace Trelamium.Items.Cumulor
{
    public class FeatherfootBoots : ModItem
    {
        public override void SetDefaults()
        {


            item.width = 36;
            item.height = 32;
            item.value = Terraria.Item.buyPrice(0, 20, 0, 0);
            item.rare = 2;
            item.accessory = true;
            item.expert = true;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Featherfoot Boots");
      Tooltip.SetDefault("Grants immunity to fall damage\nAllows the wearer to run fast\nIncreases jump hieght\nMinor rocket boot boost");
    }


        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.accRunSpeed = 2.3f;
            player.noFallDmg = true;
            player.jumpBoost = true;
            player.rocketBoots = 2;
            player.moveSpeed += 0.35f;
        }
    }
}
