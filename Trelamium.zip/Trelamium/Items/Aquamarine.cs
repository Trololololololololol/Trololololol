﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items
{
    public class Aquamarine : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 18;
            item.height = 18;

            item.value = Terraria.Item.buyPrice(0, 0, 10, 0);
            item.rare = 1;
            item.maxStack = 99;
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aquamarine");
      Tooltip.SetDefault("'Very shiny'");
    }

        public override void AddRecipes()
        {

            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, ("Agate"), 5);
            recipe.AddTile(null, ("AquaAltar"));
            recipe.SetResult(this, 5);
            recipe.AddRecipe();
        }
    }
}
