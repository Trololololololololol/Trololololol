﻿using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Placeable
{
    public class CryingBloodAltar : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 28;
            item.height = 14;
            item.maxStack = 99;

            item.useTurn = true;
            item.autoReuse = true;
            item.useAnimation = 15;
            item.useTime = 10;
            item.useStyle = 1;
            item.consumable = true;
            item.value = 150;
            item.createTile = mod.TileType("CryingBloodAltar");
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Crying Blood Altar");
      Tooltip.SetDefault("'Stores the souls of the evils'");
    }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Lens", 5);
            recipe.AddIngredient(null, "Teeth");
            recipe.AddIngredient(null, "RippedRug", 11);
            recipe.AddRecipeGroup("PlatinumBars", 5);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
