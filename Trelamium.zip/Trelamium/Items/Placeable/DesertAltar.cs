﻿using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Placeable
{
    public class DesertAltar : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 52;
            item.height = 34;
            item.maxStack = 1;

            item.useTurn = true;
            item.autoReuse = true;
            item.useAnimation = 15;
            item.useTime = 10;
            item.useStyle = 1;
            item.consumable = true;
            item.value = 100050;
            item.createTile = mod.TileType("DesertAltarTile");
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Desert Altar");
      Tooltip.SetDefault("Creates powerfull gear from Various Materials!");
    }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddRecipeGroup("EvilBars", 10);
            recipe.AddIngredient(null, "SunSpiritBracing", 12);
            recipe.AddIngredient(null, "WarClaw", 10);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
