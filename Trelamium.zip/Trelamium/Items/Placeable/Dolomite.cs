using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Placeable
{
    public class Dolomite : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Dolomite");
            Tooltip.SetDefault("");
        }
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.maxStack = 999;
            item.useTurn = true;
            item.autoReuse = true;
            item.useAnimation = 15;
            item.useTime = 10;
            item.useStyle = 1;
            item.rare = 2;
            item.value = Terraria.Item.buyPrice(0, 0, 3, 0);
            item.consumable = true;
            item.createTile = mod.TileType("DolomiteTile"); //put your CustomBlock Tile name
        }
    }
}
