using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Placeable
{
    public class DeepDirtSeeds : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Dark Grass Seeds");
            Tooltip.SetDefault("");
        }
        public override void SetDefaults()
        {
            item.width = 22;
            item.height = 18;
            item.maxStack = 99;
            item.useTurn = true;
            item.autoReuse = true;
            item.useAnimation = 15;
            item.useTime = 10;
            item.useStyle = 1;
            item.rare = 0;
            item.consumable = true;
            item.value = Terraria.Item.buyPrice(0, 0, 5, 0);
            item.createTile = mod.TileType("DeepDirt"); //put your CustomBlock Tile name
        }
    }
}
