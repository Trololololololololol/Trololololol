﻿using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Placeable
{ 
    public class SoundConversator : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 54;
            item.height = 56;
            item.maxStack = 1;

            item.useTurn = true;
            item.autoReuse = true;
            item.useAnimation = 15;
            item.useTime = 10;
            item.useStyle = 1;
            item.consumable = true;
            item.value = 100050;
            item.createTile = mod.TileType("SoundConversatorTile");
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Sound Conversator");
      Tooltip.SetDefault("'Creates powerful weapons and armor from the sound cores'");
    }

    
    public override void AddRecipes()
    {
        ModRecipe recipe = new ModRecipe(mod);
        recipe.AddRecipeGroup("EvilBars", 10);
        recipe.AddRecipeGroup("PlatinumBars", 15);
        recipe.AddRecipeGroup("SilverBars", 10);
            recipe.AddIngredient(null, "SoundPrism", 20);
            recipe.AddTile(TileID.Anvils);
        recipe.SetResult(this);
        recipe.AddRecipe();
    }
}}
