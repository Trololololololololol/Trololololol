using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Placeable
{
    public class PanktoniumAnvil : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Panktonium Anvil");
            Tooltip.SetDefault("");
        }
        public override void SetDefaults()
        {
            item.width = 48;
            item.height = 30;
            item.maxStack = 99;
            item.useTurn = true;
            item.autoReuse = true;
            item.useAnimation = 15;
            item.useTime = 10;
            item.rare = 6;
            item.useStyle = 1;
            item.consumable = true;
            item.value = Terraria.Item.sellPrice(0, 1, 0, 0);
            item.createTile = mod.TileType("PanktoniumAnvil");
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null,("PanktoniumBar"), 8);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}