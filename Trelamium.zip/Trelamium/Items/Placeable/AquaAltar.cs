﻿using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Items.Placeable
{
    public class AquaAltar : ModItem
    {
        public override void SetDefaults()
        {

            item.width = 28;
            item.height = 14;
            item.maxStack = 99;

            item.useTurn = true;
            item.autoReuse = true;
            item.useAnimation = 15;
            item.useTime = 10;
            item.useStyle = 1;
            item.consumable = true;
            item.value = 150;
            item.createTile = mod.TileType("AquaAltar");
        }

    public override void SetStaticDefaults()
    {
      DisplayName.SetDefault("Aquatic Altar");
      Tooltip.SetDefault("Turns Azurite into Aquamarine.\nIt's magical!");
    }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.WorkBench);
            recipe.AddIngredient(null, "Agate", 20);
            recipe.AddTile(TileID.Anvils);
            recipe.AddRecipeGroup("PlatinumBars", 8);
            recipe.AddRecipeGroup("EvilBars", 10);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
