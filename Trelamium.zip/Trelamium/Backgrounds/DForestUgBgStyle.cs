using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Backgrounds
{
	public class DForestUgBgStyle : ModUgBgStyle
	{
		public override bool ChooseBgStyle()
		{
			return Main.player[Main.myPlayer].GetModPlayer<MyPlayer>(mod).ZoneDForest;
		}

		public override void FillTextureArray(int[] textureSlots)
		{
			textureSlots[0] = mod.GetBackgroundSlot("Backgrounds/DForestBiomeUG0");
            textureSlots[1] = mod.GetBackgroundSlot("Backgrounds/DForestBiomeUG1");
            textureSlots[2] = mod.GetBackgroundSlot("Backgrounds/DForestBiomeUG2");
            textureSlots[3] = mod.GetBackgroundSlot("Backgrounds/DForestBiomeUG3");
		}
	}
}