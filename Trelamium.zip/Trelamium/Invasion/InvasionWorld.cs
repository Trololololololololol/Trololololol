﻿using System.Collections.Generic;
using System.IO;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using Terraria.World.Generation;

namespace Trelamium.Invasion
{
    public class InvasionWorld : ModWorld
    {
        private const int saveVersion = 0;
        public static int BlightedPoints = 0;
        public static int BlightedPoints1;
        public static bool Blighted;
        public override void ModifyWorldGenTasks(List<GenPass> tasks, ref float totalWeight)
        {

        }

        public override void PostWorldGen()
        {

        }

        public override void Initialize()
        {
            BlightedPoints1 = 0;
            Blighted = false;
        }

        public override void TileCountsAvailable(int[] tileCounts)
        {

        }

        /*public override void SaveCustomData(BinaryWriter writer)
		{
			writer.Write(saveVersion);
			writer.Write(Blighted);
			writer.Write(BlightedPoints1);
		} */

        public override TagCompound Save()
        {
            TagCompound save_data = new TagCompound();
            save_data.Add("Blighted", Blighted);
            save_data.Add("BlightedPoints1", BlightedPoints1);
            return save_data;
        }

        public override void NetSend(BinaryWriter writer)
        {
            writer.Write(Blighted);
            writer.Write(BlightedPoints1);
        }

        public override void NetReceive(BinaryReader reader)
        {
            BitsByte flags = reader.ReadByte();
            flags[0] = Blighted;
            BlightedPoints1 = reader.ReadInt32();
        }

        int num;
        public override void Load(TagCompound tag)
        {
            Blighted = tag.GetBool("Blighted");
            BlightedPoints1 = tag.GetInt("BlightedPoints1");
        }

        public override void LoadLegacy(BinaryReader reader)
        {
            int loadVersion = reader.ReadInt32();
            if (loadVersion == 0)
            {
                BitsByte flags = reader.ReadByte();
                Blighted = flags[0];
                BlightedPoints1 = reader.ReadInt32();
            }
            else
            {
                ErrorLogger.Log("Trelamium: Unknown loadVersion: " + loadVersion);
            }
        }
    }
}
