﻿using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Buffs
{
    public class WyvernTime : ModBuff
	{
		public override void SetDefaults()
		{
            DisplayName.SetDefault("Ride the dragon!");
            Description.SetDefault("It's Wyvern time!");
			Main.buffNoTimeDisplay[Type] = true;
			Main.buffNoSave[Type] = true;
		}
		
		public override void Update(Player player, ref int buffIndex)
		{
            MyPlayer modPlayer = player.GetModPlayer<MyPlayer>(mod);
			if (player.ownedProjectileCounts[mod.ProjectileType("WyvernHead")] > 0)
			{
				modPlayer.Wyvern = true;
			}
            if (!modPlayer.Wyvern)
			{
				player.DelBuff(buffIndex);
				buffIndex--;
			}
			else
			{
				player.buffTime[buffIndex] = 18000;
			}
		}
	}
}