﻿using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Buffs
{
    public class BlueSlimeBuff : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Blue Slime!");
            Description.SetDefault("A Blue Slime will fight for you.");
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;

        }


        public override void Update(Player player, ref int buffIndex)
        {
            MyPlayer modPlayer = (MyPlayer)player.GetModPlayer(mod, "MyPlayer");
            if (player.ownedProjectileCounts[mod.ProjectileType("BlueSlime")] > 0)
            {
                modPlayer.BlueSlimeBuff = true;
            }
            if (!modPlayer.BlueSlimeBuff)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
            {
                player.buffTime[buffIndex] = 18000;
            }
        }
    }
}