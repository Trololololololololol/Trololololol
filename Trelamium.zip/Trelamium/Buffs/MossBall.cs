using System;
using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Buffs
{
    public class MossBall : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Furry little friend");
            Description.SetDefault("A Moss Ball will hop and shoot at enemies!");
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;

        }

        public override void Update(Player player, ref int buffIndex)
        {
            MyPlayer modPlayer = (MyPlayer)player.GetModPlayer(mod, "MyPlayer");
            if (player.ownedProjectileCounts[mod.ProjectileType("MossBallMinion")] > 0)
            {
                modPlayer.mossMinion = true;
            }
            if (!modPlayer.mossMinion)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
            {
                player.buffTime[buffIndex] = 18000;
            }
        }
    }
}