﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.NPCs;

namespace Trelamium.Buffs
{
    public class DesertCurse : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Relic Flames");
            Description.SetDefault("Ancient powers are tearing you apart");
            Main.debuff[Type] = true;   //Tells the game if this is a buf or not.
            Main.pvpBuff[Type] = true;  //Tells the game if pvp buff or not. 
            Main.buffNoSave[Type] = true;
            longerExpertDebuff = true;
        }
        public override void Update(Player player, ref int buffIndex)
        {
            player.GetModPlayer<MyPlayer>(mod).DesertCurse = true;
        }

        public override void Update(NPC npc, ref int buffIndex)
        {
            npc.GetGlobalNPC<TrelamiumGlobalNPC>(mod).DesertCurse = true;
        }
    }
}
