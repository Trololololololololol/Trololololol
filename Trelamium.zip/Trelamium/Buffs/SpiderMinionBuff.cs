using System;
using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Buffs
{
    public class SpiderMinionBuff : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Creepers Jeepers");
            Description.SetDefault("A Recluse will fight for you!");
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;

        }

        public override void Update(Player player, ref int buffIndex)
        {
            MyPlayer modPlayer = (MyPlayer)player.GetModPlayer(mod, "MyPlayer");
            if (player.ownedProjectileCounts[mod.ProjectileType("RecluseMinion")] > 0)
            {
                modPlayer.spiderMinion = true;
            }
            if (!modPlayer.spiderMinion)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
            {
                player.buffTime[buffIndex] = 18000;
            }
        }
    }
}