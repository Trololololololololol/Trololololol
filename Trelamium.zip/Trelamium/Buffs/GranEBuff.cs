﻿using System;
using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Buffs
{
    public class GranEBuff : ModBuff
	{
		public override void SetDefaults()
		{
            DisplayName.SetDefault("The Annoying floaty guy");
            Description.SetDefault("A Granite elemental will attack enemies for you");
            Main.buffNoSave[Type] = true;
            Main.debuff[Type] = false;
            Main.buffNoTimeDisplay[Type] = true;
		}
		
		public override void Update(Player player, ref int buffIndex)
		{
            MyPlayer modPlayer = (MyPlayer)player.GetModPlayer(mod, "MyPlayer");
            if (player.ownedProjectileCounts[mod.ProjectileType("GraniteEMinion")] > 0)
			{
				modPlayer.gMinion = true;
			}
            if (!modPlayer.gMinion)
			{
				player.DelBuff(buffIndex);
				buffIndex--;
			}
			else
			{
				player.buffTime[buffIndex] = 18000;
			}
		}
	}
}