using System;
using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Buffs
{
    public class EaterBuff : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Eater of souls");
            Description.SetDefault("An eater will devourer your enemies");
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;
            Main.debuff[Type] = false;

        }

        public override void Update(Player player, ref int buffIndex)
        {
            MyPlayer modPlayer = (MyPlayer)player.GetModPlayer(mod, "MyPlayer");
            if (player.ownedProjectileCounts[mod.ProjectileType("EaterMinion")] > 0)
            {
                modPlayer.eaterMinion = true;
            }
            if (!modPlayer.eaterMinion)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
            {
                player.buffTime[buffIndex] = 18000;
            }
        }
    }
}