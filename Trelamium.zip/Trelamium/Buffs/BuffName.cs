using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Trelamium.Buffs
{
    public class BuffName : ModBuff
    {
        public override void SetDefaults()
        {
            Main.buffNoTimeDisplay[Type] = false;
            DisplayName.SetDefault("Siphon");
            Description.SetDefault("Rapidly regenerates life");
        }
        public override void Update(Player player, ref int buffIndex)
        {
            player.lifeRegen = +8;
        }
    }
}