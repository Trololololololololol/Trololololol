using System;
using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Buffs
{
    public class BabyMushroom : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("I Think its on Shro--, a diet.");
            Description.SetDefault("A Floating mass of mushy stuff will fight for you!");
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;

        }

        public override void Update(Player player, ref int buffIndex)
        {
            MyPlayer modPlayer = (MyPlayer)player.GetModPlayer(mod, "MyPlayer");
            if (player.ownedProjectileCounts[mod.ProjectileType("MushroomMinion")] > 0)
            {
                modPlayer.mushMinion = true;
            }
            if (!modPlayer.mushMinion)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
            {
                player.buffTime[buffIndex] = 18000;
            }
        }
    }
}