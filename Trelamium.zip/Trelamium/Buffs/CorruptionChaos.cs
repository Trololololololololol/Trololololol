﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.NPCs;

namespace Trelamium.Buffs
{
    public class CorruptionChaos : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Corrupted Chaos");
            Description.SetDefault("Grants you a huge damage boost");
            Main.debuff[Type] = true;   //Tells the game if this is a buf or not.
            Main.buffNoSave[Type] = true;
            longerExpertDebuff = true;
        }
        public override void Update(Player player, ref int buffIndex)
        {
            player.GetModPlayer<MyPlayer>(mod).CorruptionChaos = true;
        }
    }
}
