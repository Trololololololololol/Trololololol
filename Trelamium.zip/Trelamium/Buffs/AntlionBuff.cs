using System;
using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Buffs
{
    public class AntlionBuff : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Antlion Swarmer");
            Description.SetDefault("An Antlion Swarmer will fight for you.");
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;
            Main.debuff[Type] = false;

        }

        public override void Update(Player player, ref int buffIndex)
        {
            MyPlayer modPlayer = (MyPlayer)player.GetModPlayer(mod, "MyPlayer");
            if (player.ownedProjectileCounts[mod.ProjectileType("AntlionMinion")] > 0)
            {
                modPlayer.antMinion = true;
            }
            if (!modPlayer.antMinion)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
            {
                player.buffTime[buffIndex] = 18000;
            }
        }
    }
}