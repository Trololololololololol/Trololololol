﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.NPCs;

namespace Trelamium.Buffs
{
    public class CrightChaos : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Cright Chaos");
            Description.SetDefault("Grants you a massive damage boost");
            Main.debuff[Type] = true;   //Tells the game if this is a buf or not.
            Main.buffNoSave[Type] = true;
            longerExpertDebuff = true;
        }
        public override void Update(Player player, ref int buffIndex)
        {
            player.GetModPlayer<MyPlayer>(mod).CrightChaos = true;
        }
    }
}
