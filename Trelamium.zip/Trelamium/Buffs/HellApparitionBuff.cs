﻿
using System;
using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Buffs
{
    public class HellApparitionBuff : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("It Burns!");
            Description.SetDefault("A Flame Apparition will fight for you.");
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;

        }

        public override void Update(Player player, ref int buffIndex)
        {
            MyPlayer modPlayer = (MyPlayer)player.GetModPlayer(mod, "MyPlayer");
            if (player.ownedProjectileCounts[mod.ProjectileType("FireAntlionMinion")] > 0)
            {
                modPlayer.hMinion = true;
            }
            if (!modPlayer.hMinion)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
            {
                player.buffTime[buffIndex] = 18000;
            }
        }
    }
}