using System;
using Terraria;
using Terraria.ModLoader;

namespace Trelamium.Buffs
{
    public class CloudBuff : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Puffy Baby");
            Description.SetDefault("One of Cumulor's servants will fight for you.");
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;

        }

        public override void Update(Player player, ref int buffIndex)
        {
            MyPlayer modPlayer = (MyPlayer)player.GetModPlayer(mod, "MyPlayer");
            if (player.ownedProjectileCounts[mod.ProjectileType("RoyalCloudMinion")] > 0)
            {
                modPlayer.cloudMinion = true;
            }
            if (!modPlayer.cloudMinion)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
            {
                player.buffTime[buffIndex] = 18000;
            }
        }
    }
}