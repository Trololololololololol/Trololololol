﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Trelamium.NPCs;

namespace Trelamium.Buffs
{
    public class DarkDebufff : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Dark Flames");
            Description.SetDefault("Your insides are corrupting and roasted");
            Main.debuff[Type] = true;   //Tells the game if this is a buf or not.
            Main.pvpBuff[Type] = true;  //Tells the game if pvp buff or not. 
            Main.buffNoSave[Type] = true;
            longerExpertDebuff = true;
        }
        public override void Update(Player player, ref int buffIndex)
        {
            player.GetModPlayer<MyPlayer>(mod).DarkDebufff = true;
        }

        public override void Update(NPC npc, ref int buffIndex)
        {
            npc.GetGlobalNPC<TrelamiumGlobalNPC>(mod).DarkDebufff = true;
        }
    }
}
